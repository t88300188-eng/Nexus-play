// Demo "Cuadrados": cada jugador es un cuadrado. La posición se sincroniza con nexus.setState,
// los saludos viajan como eventos (nexus.send) y el color del fondo es un valor compartido
// que solo puede cambiar el anfitrión (nexus.setShared).
(function () {
  'use strict';
  var canvas = document.getElementById('c');
  var ctx = canvas.getContext('2d');
  var dotEl = document.getElementById('dot');
  var statusEl = document.getElementById('status');
  var bannerEl = document.getElementById('banner');
  var waveBtn = document.getElementById('wave');
  var themeBtn = document.getElementById('theme');

  var THEMES = ['#0a0a0b', '#0b1220', '#1a0b16', '#0b1a12', '#1a1608'];
  var me = { x: 0.5, y: 0.5 };           // posición local en unidades de arena (0..1)
  var vis = {};                          // posición suavizada de los demás
  var waves = {};                        // id -> instante del último saludo
  var nexus = null;
  var theme = 0;
  var keys = {};
  var pointer = null;
  var lastSent = 0;
  var lastSentPos = { x: -1, y: -1 };
  var W = 0, H = 0;

  function resize() {
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener('resize', resize);
  resize();

  function arena() {
    var s = Math.max(120, Math.min(W, H) - 90);
    return { x: (W - s) / 2, y: (H - s) / 2 + 8, s: s };
  }
  function hue(id) {
    var h = 0;
    for (var i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
    return h % 360;
  }
  function clamp(v) { return Math.max(0.03, Math.min(0.97, v)); }

  // ---- Entrada ----
  window.addEventListener('keydown', function (e) {
    if (e.code === 'Space') { e.preventDefault(); wave(); return; }
    keys[e.code] = true;
  });
  window.addEventListener('keyup', function (e) { keys[e.code] = false; });
  canvas.addEventListener('pointerdown', function (e) { pointer = { x: e.clientX, y: e.clientY }; canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener('pointermove', function (e) { if (pointer) pointer = { x: e.clientX, y: e.clientY }; });
  canvas.addEventListener('pointerup', function () { pointer = null; });
  canvas.addEventListener('pointercancel', function () { pointer = null; });
  waveBtn.addEventListener('click', wave);
  themeBtn.addEventListener('click', function () {
    if (!nexus) return;
    var next = (theme + 1) % THEMES.length;
    try { nexus.setShared('tema', next); } catch (e) { showBanner(e.message); }
  });

  function wave() {
    waves[nexus ? nexus.me.id : 'yo'] = Date.now();
    if (nexus) { try { nexus.send('saludo', { t: Date.now() }); } catch (e) { /* demasiado rápido */ } }
  }

  function showBanner(text) {
    bannerEl.textContent = text;
    bannerEl.hidden = !text;
  }

  function setStatus(kind, text) {
    dotEl.className = kind;
    statusEl.textContent = text;
  }

  function updateStatus() {
    if (!nexus) return;
    var online = nexus.players.filter(function (p) { return p.online; }).length;
    var base = nexus.room.name + ' · ' + online + ' conectado' + (online === 1 ? '' : 's') + (nexus.isHost ? ' · eres el anfitrión' : '');
    if (nexus.connection === 'connected') setStatus('ok', base);
    else if (nexus.connection === 'reconnecting') setStatus('warn', 'Reconectando…');
    else setStatus('bad', 'Desconectado');
    themeBtn.hidden = !nexus.isHost;
  }

  // ---- Movimiento ----
  function step(dt) {
    var a = arena();
    var dx = 0, dy = 0;
    if (keys.ArrowLeft || keys.KeyA) dx -= 1;
    if (keys.ArrowRight || keys.KeyD) dx += 1;
    if (keys.ArrowUp || keys.KeyW) dy -= 1;
    if (keys.ArrowDown || keys.KeyS) dy += 1;
    if (pointer) {
      var px = a.x + me.x * a.s, py = a.y + me.y * a.s;
      var vx = pointer.x - px, vy = pointer.y - py;
      var d = Math.sqrt(vx * vx + vy * vy);
      if (d > 14) { dx += vx / d; dy += vy / d; }
    }
    var len = Math.sqrt(dx * dx + dy * dy);
    if (len > 0) {
      me.x = clamp(me.x + (dx / len) * 0.45 * dt);
      me.y = clamp(me.y + (dy / len) * 0.45 * dt);
    }
  }

  function publish(now) {
    if (!nexus || !nexus.connected) return;
    var moved = Math.abs(me.x - lastSentPos.x) > 0.002 || Math.abs(me.y - lastSentPos.y) > 0.002;
    if ((moved && now - lastSent > 50) || now - lastSent > 1500) {
      lastSent = now;
      lastSentPos = { x: me.x, y: me.y };
      try { nexus.setState({ x: +me.x.toFixed(4), y: +me.y.toFixed(4) }); } catch (e) { /* aún no listo */ }
    }
  }

  // ---- Dibujo ----
  function drawSquare(a, id, name, x, y, host, faded, isMe, now) {
    var size = Math.max(18, a.s * 0.06);
    var cx = a.x + x * a.s, cy = a.y + y * a.s;
    var h = hue(id);
    ctx.globalAlpha = faded ? 0.35 : 1;
    ctx.fillStyle = 'hsl(' + h + ',75%,55%)';
    ctx.fillRect(cx - size / 2, cy - size / 2, size, size);
    if (isMe) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.strokeRect(cx - size / 2 - 3, cy - size / 2 - 3, size + 6, size + 6); }
    ctx.fillStyle = '#f2f2f3';
    ctx.font = '12px system-ui,sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText((host ? '★ ' : '') + name + (faded ? ' (desconectado)' : ''), cx, cy - size / 2 - 8);
    var w = waves[id];
    if (w && now - w < 1800) {
      ctx.font = '22px system-ui,sans-serif';
      ctx.fillText('👋', cx, cy - size / 2 - 26 - Math.min(10, (now - w) / 120));
    }
    ctx.globalAlpha = 1;
  }

  var prev = performance.now();
  function frame(t) {
    var dt = Math.min(0.05, (t - prev) / 1000);
    prev = t;
    step(dt);
    publish(t);
    var now = Date.now();
    ctx.fillStyle = THEMES[theme];
    ctx.fillRect(0, 0, W, H);
    var a = arena();
    ctx.strokeStyle = '#26262a';
    ctx.lineWidth = 1;
    ctx.strokeRect(a.x, a.y, a.s, a.s);
    for (var i = 1; i < 8; i++) {
      ctx.beginPath(); ctx.moveTo(a.x + (a.s * i) / 8, a.y); ctx.lineTo(a.x + (a.s * i) / 8, a.y + a.s);
      ctx.moveTo(a.x, a.y + (a.s * i) / 8); ctx.lineTo(a.x + a.s, a.y + (a.s * i) / 8); ctx.stroke();
    }
    if (nexus) {
      var states = nexus.getStates();
      nexus.players.forEach(function (p) {
        if (p.id === nexus.me.id) return;
        var s = states[p.id];
        if (!s) return;
        var v = vis[p.id] || (vis[p.id] = { x: s.x, y: s.y });
        v.x += (s.x - v.x) * 0.3; v.y += (s.y - v.y) * 0.3;
        drawSquare(a, p.id, p.name, v.x, v.y, p.host, !p.online, false, now);
      });
      drawSquare(a, nexus.me.id, nexus.me.name, me.x, me.y, nexus.isHost, false, true, now);
    } else {
      drawSquare(a, 'yo', 'Tú', me.x, me.y, false, false, true, now);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // ---- Conexión con NEXUS PLAY ----
  if (typeof NexusPlay === 'undefined' || !NexusPlay.isEmbedded()) {
    setStatus('warn', 'Modo solo (fuera de una sala de NEXUS PLAY)');
    return;
  }
  NexusPlay.connect().then(function (n) {
    nexus = n;
    me = { x: 0.2 + Math.random() * 0.6, y: 0.2 + Math.random() * 0.6 };
    var th = n.getShared().tema;
    if (typeof th === 'number') theme = th % THEMES.length;
    n.on('players', updateStatus);
    n.on('room', updateStatus);
    n.on('connection', function (status) {
      updateStatus();
      showBanner(status === 'reconnecting' ? 'Reconectando con la sala…' : '');
    });
    n.on('player:leave', function (p) { delete vis[p.id]; });
    n.on('event:saludo', function (_d, from) { waves[from.id] = Date.now(); });
    n.on('shared', function (key, value) { if (key === 'tema' && typeof value === 'number') theme = value % THEMES.length; });
    n.on('closed', function (reason) {
      setStatus('bad', reason === 'kicked' ? 'El anfitrión te expulsó' : 'La sala se cerró');
    });
    n.on('error', function (err) { showBanner(err.message); setTimeout(function () { showBanner(''); }, 2500); });
    updateStatus();
    n.ready();
    n.setState({ x: me.x, y: me.y });
  }).catch(function (e) {
    setStatus('bad', e.message);
  });
})();
