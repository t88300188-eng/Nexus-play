# NEXUS PLAY

Plataforma web para **subir un juego HTML o ZIP, publicarlo, crear salas privadas con código/enlace de invitación y jugar en tiempo real** desde navegadores de Android y PC. Pensada para correr en un celular con **Termux** (Node, sin módulos nativos) y presupuesto 0.

> **Estado honesto (v0.2.0):** funciona y está probada con 102 pruebas automáticas + 39 comprobaciones en navegador real (Chromium, PC y móvil *emulado*). **Falta** la prueba física Android + PC en tu red y la prueba en tu Termux. Ver [docs/TESTING.md](docs/TESTING.md).

## Inicio rápido
```bash
npm install
npm start
```
Abre la dirección `Red:` que imprime (ej. `http://192.168.1.20:3000`) en el celular y en el PC (misma Wi-Fi). Guía completa para Termux: [docs/TERMUX.md](docs/TERMUX.md).

## Qué incluye
- **Biblioteca:** HTML o ZIP, versiones inmutables, miniatura, editar, publicar/despublicar, eliminar con confirmación, volver a una versión anterior.
- **Salas privadas:** código `XXXX-XXXX-XXXX` o enlace, revocar/regenerar/caducar, expulsar, capacidad, cambio automático de anfitrión, estados `waiting → starting → playing → closing → closed`.
- **Tiempo real (WebSocket):** eventos, estado por jugador, estado compartido del anfitrión, presencia, latencia, reconexión automática.
- **SDK** (`public/sdk/nexus-sdk.js`) y juego demo multijugador.
- **Asistente de integración:** analiza (heurístico), propone, y al aplicar crea una **versión nueva** conservando la original.
- **Diagnóstico** con informe copiable sin secretos.
- **Seguridad:** juegos aislados en iframe sandbox, validación estricta de ZIP, límites, tickets de un solo uso, sin cookies.
- **Copias de seguridad:** `npm run backup` / `npm run restore`.

## Qué NO hace (no lo prometemos)
- **No vuelve multijugador automáticamente cualquier juego.** El SDK da herramientas; el juego debe usarlas. El asistente solo inyecta el SDK y sugiere.
- Sin cuentas ni contraseñas: sesiones de invitado (ver [SECURITY](docs/SECURITY.md)).
- Sin HTTPS propio (usa un túnel o proxy si lo expones a Internet; ver [DEPLOYMENT](docs/DEPLOYMENT.md)).

## Documentación
[ARCHITECTURE](docs/ARCHITECTURE.md) · [API](docs/API.md) · [MULTIPLAYER_PROTOCOL](docs/MULTIPLAYER_PROTOCOL.md) · [SDK_GUIDE](docs/SDK_GUIDE.md) · [SECURITY](docs/SECURITY.md) · [DEPLOYMENT](docs/DEPLOYMENT.md) · [TERMUX](docs/TERMUX.md) · [TESTING](docs/TESTING.md) · [ROADMAP](docs/ROADMAP.md) · [CHANGELOG](docs/CHANGELOG.md)

Configuración: [.env.example](.env.example). Pruebas: `npm test`.
