// Copia de seguridad: node scripts/backup.js   (o: npm run backup)
// Copia la carpeta de datos (db.json, juegos, miniaturas, .secret) a backups/<fecha>/.
// Se puede ejecutar con el servidor encendido: db.json se escribe de forma atómica.
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig } from '../server/config.js';

const cfg = loadConfig();
const outRoot = path.resolve(process.env.BACKUP_DIR || path.join(cfg.rootDir, 'backups'));
const keep = Number(process.env.BACKUP_KEEP || 10);

if (!fs.existsSync(path.join(cfg.dataDir, 'db.json')) && !fs.existsSync(path.join(cfg.dataDir, 'games'))) {
  console.error(`✖ No hay datos que respaldar en ${cfg.dataDir}`);
  process.exit(1);
}
const stamp = new Date().toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
const dest = path.join(outRoot, stamp);
fs.mkdirSync(dest, { recursive: true });
const skip = new Set(['tmp', '.lock']);
let files = 0; let bytes = 0;
fs.cpSync(cfg.dataDir, dest, {
  recursive: true,
  filter: (src) => {
    const rel = path.relative(cfg.dataDir, src);
    if (rel && skip.has(rel.split(path.sep)[0])) return false;
    if (rel && fs.statSync(src).isFile()) { files++; bytes += fs.statSync(src).size; }
    return true;
  },
});
console.log(`✔ Copia creada: ${dest}\n  ${files} archivos, ${(bytes / 1048576).toFixed(2)} MB`);

// Conserva solo las últimas N copias
const all = fs.readdirSync(outRoot).filter((d) => /^\d{4}-\d{2}-\d{2}_/.test(d)).sort();
for (const old of all.slice(0, Math.max(0, all.length - keep))) {
  fs.rmSync(path.join(outRoot, old), { recursive: true, force: true });
  console.log(`  (copia antigua eliminada: ${old})`);
}
