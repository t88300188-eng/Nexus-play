// Restaurar: node scripts/restore.js <carpeta-de-copia>   (ej.: npm run restore -- backups/2026-10-27_20-00-00)
// Sin argumentos lista las copias disponibles. Requiere el servidor APAGADO.
// Los datos actuales NO se borran: se mueven a data.before-restore-<fecha>.
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig } from '../server/config.js';

const cfg = loadConfig();
const root = path.resolve(process.env.BACKUP_DIR || path.join(cfg.rootDir, 'backups'));
const arg = process.argv[2];

if (!arg) {
  const list = fs.existsSync(root) ? fs.readdirSync(root).filter((d) => /^\d{4}-\d{2}-\d{2}_/.test(d)).sort() : [];
  console.log(list.length ? `Copias disponibles en ${root}:\n  ${list.join('\n  ')}\n\nUso: npm run restore -- <nombre-o-ruta>` : `No hay copias en ${root}. Crea una con: npm run backup`);
  process.exit(list.length ? 0 : 1);
}
const src = fs.existsSync(arg) ? path.resolve(arg) : path.join(root, arg);
if (!fs.existsSync(path.join(src, 'db.json')) && !fs.existsSync(path.join(src, 'games'))) {
  console.error(`✖ "${src}" no parece una copia de NEXUS PLAY (falta db.json).`);
  process.exit(1);
}
if (path.resolve(src) === cfg.dataDir) { console.error('✖ La copia y los datos son la misma carpeta.'); process.exit(1); }

try {
  const pid = Number(fs.readFileSync(path.join(cfg.dataDir, '.lock'), 'utf8'));
  if (pid) {
    let alive = true;
    try { process.kill(pid, 0); } catch (e) { alive = e.code === 'EPERM'; }
    if (alive) { console.error(`✖ El servidor está encendido (PID ${pid}). Deténlo con Ctrl+C y vuelve a intentarlo.`); process.exit(1); }
  }
} catch { /* sin .lock: no hay servidor */ }

const stamp = new Date().toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
if (fs.existsSync(cfg.dataDir)) {
  const old = `${cfg.dataDir}.before-restore-${stamp}`;
  fs.renameSync(cfg.dataDir, old);
  console.log(`  Datos actuales guardados en: ${old}`);
}
fs.cpSync(src, cfg.dataDir, { recursive: true });
fs.mkdirSync(path.join(cfg.dataDir, 'tmp'), { recursive: true });
console.log(`✔ Restaurado desde ${src}\n  Ya puedes iniciar: npm start`);
