import { EventEmitter } from 'node:events';
import { UserError } from './errors.js';
import { cleanText, randId, randCode, formatCode, normalizeCode } from './util.js';

export const TRANSITIONS = {
  waiting: ['starting', 'closing'],
  starting: ['playing', 'closing'],
  playing: ['waiting', 'closing'],
  closing: ['closed'],
  closed: [],
};
export const STATE_LABEL = { waiting: 'esperando', starting: 'iniciando', playing: 'jugando', closing: 'cerrando', closed: 'cerrada' };

const OFFLINE_GRACE_MS = 45_000;       // en espera, un jugador desconectado libera su sitio
const HOST_GRACE_MS = 90_000;          // si el anfitrión no vuelve, pasa el rol a otro conectado

/**
 * Salas privadas. Los datos que deben sobrevivir a un reinicio (sala, invitación, miembros)
 * están en el almacén; la presencia, el estado compartido y los temporizadores solo en memoria.
 *
 * Eventos: 'players'(roomId, change) · 'room'(roomId) · 'evict'(roomId, userId, reason) · 'closed'(roomId)
 */
export class RoomService extends EventEmitter {
  constructor({ store, config, log, games, now = Date.now }) {
    super();
    this.store = store;
    this.cfg = config;
    this.log = log;
    this.games = games;
    this.now = now;
    this.online = new Map();
    this.offlineSince = new Map();
    this.ready = new Map();
    this.shared = new Map();
    this.states = new Map();
    this.timers = new Map();
    this.codeIndex = new Map();
    this.startTimeoutMs = config.startTimeoutMs ?? 8000;
    games.roomGuard = this;

    const t = now();
    for (const r of Object.values(this.rooms)) {
      // Tras un reinicio nadie está conectado: se normalizan los estados transitorios.
      if (r.state === 'starting') r.state = 'waiting';
      if (r.state === 'closing') { r.state = 'closed'; r.closedAt = t; }
      if (r.state !== 'closed') {
        r.lastActivity = t;
        for (const uid of Object.keys(r.members)) this.offlineSince.set(`${r.id}:${uid}`, t);
      }
      if (r.invite?.code) this.codeIndex.set(r.invite.code, r.id);
    }
    store.save();
  }

  get rooms() { return this.store.data.rooms; }

  // ---------- Consultas ----------
  isOnline(roomId, userId) { return this.online.get(roomId)?.has(userId) ?? false; }

  players(r) {
    const rd = this.ready.get(r.id);
    return Object.entries(r.members)
      .sort((a, b) => (a[0] === r.hostId ? -1 : b[0] === r.hostId ? 1 : a[1].joinedAt - b[1].joinedAt))
      .map(([id, m]) => ({ id, name: m.name, host: id === r.hostId, online: this.isOnline(r.id, id), ready: !!rd?.has(id) }));
  }

  publicRoom(r) {
    return { id: r.id, name: r.name, state: r.state, max: r.max, hostId: r.hostId, gameId: r.gameId, version: r.version, expiresAt: r.expiresAt };
  }

  view(r, user) {
    const g = this.games.games[r.gameId];
    const v = g && this.games.versionOf(g, r.version);
    const isHost = r.hostId === user.id;
    const out = {
      ...this.publicRoom(r),
      createdAt: r.createdAt,
      isHost,
      players: this.players(r),
      game: g && v ? { id: g.id, title: g.title, version: v.n, playUrl: this.games.playUrl(g, v) } : null,
    };
    if (isHost && r.state !== 'closed') {
      out.invite = {
        code: formatCode(r.invite.code),
        revoked: !!r.invite.revoked,
        expiresAt: r.invite.expiresAt,
        expired: !!(r.invite.expiresAt && this.now() >= r.invite.expiresAt),
      };
    }
    return out;
  }

  #get(roomId) {
    const r = this.rooms[roomId];
    if (!r) throw new UserError('Esa sala no existe.', 404, 'not_found');
    return r;
  }

  #member(user, roomId) {
    const r = this.rooms[roomId];
    // Para quien no es miembro, la sala "no existe": no se confirma que el identificador sea válido.
    if (!r || !r.members[user.id]) throw new UserError('Esa sala no existe o no tienes acceso.', 404, 'not_found');
    return r;
  }

  #host(user, roomId) {
    const r = this.#member(user, roomId);
    if (r.hostId !== user.id) throw new UserError('Solo el anfitrión puede hacer esto.', 403, 'forbidden');
    return r;
  }

  #open(r) {
    if (r.state === 'closed') throw new UserError('La sala ya está cerrada.', 410, 'room_closed');
    return r;
  }

  getFor(user, roomId) {
    return this.view(this.#member(user, roomId), user);
  }

  listFor(user) {
    return Object.values(this.rooms)
      .filter((r) => r.members[user.id] && r.state !== 'closed')
      .sort((a, b) => b.createdAt - a.createdAt)
      .map((r) => this.view(r, user));
  }

  hasActiveRoom(gameId, version) {
    return Object.values(this.rooms).some((r) => r.state !== 'closed' && r.gameId === gameId && (version === undefined || r.version === version));
  }

  stats() {
    const byState = { waiting: 0, starting: 0, playing: 0, closing: 0, closed: 0 };
    let playersOnline = 0;
    for (const r of Object.values(this.rooms)) {
      byState[r.state] = (byState[r.state] || 0) + 1;
      if (r.state !== 'closed') playersOnline += this.online.get(r.id)?.size ?? 0;
    }
    return { byState, playersOnline, active: Object.values(byState).reduce((a, b) => a + b, 0) - byState.closed };
  }

  /** Resumen de salas para diagnóstico (sin códigos de invitación). */
  summary(user) {
    return Object.values(this.rooms).filter((r) => r.members[user.id] && r.state !== 'closed').map((r) => ({
      id: r.id, name: r.name, state: r.state, players: Object.keys(r.members).length, online: this.online.get(r.id)?.size ?? 0, max: r.max,
    }));
  }

  // ---------- Acciones ----------
  create(user, { gameId, name, max, inviteTtlMin }) {
    const g = this.games.games[gameId];
    if (!g || (!g.published && g.ownerId !== user.id)) throw new UserError('Ese juego no existe o no está publicado.', 404, 'not_found');
    const ver = this.games.versionOf(g);
    if (!ver) throw new UserError('El juego no tiene versiones.', 409, 'no_version');
    const hosted = Object.values(this.rooms).filter((r) => r.hostId === user.id && r.state !== 'closed').length;
    if (hosted >= this.cfg.maxHostedRooms) {
      throw new UserError(`Ya tienes ${hosted} salas activas (máximo ${this.cfg.maxHostedRooms}). Cierra alguna.`, 409, 'too_many_rooms');
    }
    name = cleanText(name || `Sala de ${user.name}`, { min: 2, max: 40, field: 'El nombre de la sala' });
    max = max === undefined ? 4 : Number(max);
    if (!Number.isInteger(max) || max < 2 || max > this.cfg.maxRoomPlayers) {
      throw new UserError(`El máximo de jugadores debe estar entre 2 y ${this.cfg.maxRoomPlayers}.`);
    }
    let inviteExp = null;
    if (inviteTtlMin !== undefined && inviteTtlMin !== null && inviteTtlMin !== '') {
      const m = Number(inviteTtlMin);
      if (!Number.isFinite(m) || m < 1 || m > 7 * 1440) throw new UserError('La duración de la invitación no es válida.');
      inviteExp = this.now() + m * 60_000;
    }
    const t = this.now();
    const r = {
      id: randId('r_', 6), name, gameId: g.id, version: ver.n, hostId: user.id, max, state: 'waiting',
      createdAt: t, expiresAt: t + this.cfg.roomTtlMs, lastActivity: t, closedAt: null,
      invite: { code: this.#newCode(), revoked: false, expiresAt: inviteExp },
      members: { [user.id]: { name: user.name, joinedAt: t } }, kicked: [],
    };
    this.rooms[r.id] = r;
    this.codeIndex.set(r.invite.code, r.id);
    this.store.save();
    this.log.info('room.created', { room: r.id, game: g.id, max });
    return this.view(r, user);
  }

  #newCode() {
    for (;;) {
      const c = randCode(12);
      if (!this.codeIndex.has(c)) return c;
    }
  }

  join(user, codeRaw) {
    const code = normalizeCode(codeRaw);
    const rid = code.length === 12 ? this.codeIndex.get(code) : undefined;
    const r = rid && this.rooms[rid];
    if (!r) throw new UserError('Código de invitación no válido.', 404, 'invalid_code');
    if (r.state === 'closed') throw new UserError('La sala ya fue cerrada.', 410, 'room_closed');
    const t = this.now();
    if (r.members[user.id]) return this.view(r, user); // ya es miembro: reentrada (recarga, reconexión)
    if (r.kicked.includes(user.id)) throw new UserError('El anfitrión te expulsó de esta sala.', 403, 'kicked');
    if (t >= r.expiresAt) throw new UserError('La sala expiró.', 410, 'room_expired');
    if (r.invite.revoked) throw new UserError('Esa invitación fue revocada por el anfitrión.', 403, 'invite_revoked');
    if (r.invite.expiresAt && t >= r.invite.expiresAt) throw new UserError('Esa invitación expiró.', 403, 'invite_expired');
    if (r.state !== 'waiting') throw new UserError('La partida ya empezó; la sala no admite más jugadores.', 409, 'room_started');
    if (Object.keys(r.members).length >= r.max) throw new UserError('La sala está llena.', 409, 'room_full');
    r.members[user.id] = { name: user.name, joinedAt: t };
    r.lastActivity = t;
    this.offlineSince.set(`${r.id}:${user.id}`, t);
    this.store.save();
    this.log.info('room.joined', { room: r.id, user: user.id });
    this.emit('players', r.id, { type: 'join', id: user.id });
    return this.view(r, user);
  }

  #removeMember(r, userId, reason) {
    delete r.members[userId];
    this.online.get(r.id)?.delete(userId);
    this.ready.get(r.id)?.delete(userId);
    this.states.get(r.id)?.delete(userId);
    this.offlineSince.delete(`${r.id}:${userId}`);
    this.emit('evict', r.id, userId, reason);
    if (!Object.keys(r.members).length) { this.#apply(r, 'closing', true); return; }
    if (r.hostId === userId) this.#transferHost(r, true);
    this.emit('players', r.id, { type: reason === 'kicked' ? 'kick' : 'leave', id: userId });
  }

  #transferHost(r, force = false) {
    const ids = Object.keys(r.members).sort((a, b) => r.members[a].joinedAt - r.members[b].joinedAt);
    const next = ids.find((id) => this.isOnline(r.id, id)) ?? (force ? ids[0] : undefined);
    if (!next || next === r.hostId) return false;
    r.hostId = next;
    this.log.info('room.host_changed', { room: r.id, host: next });
    this.store.save();
    this.emit('room', r.id);
    return true;
  }

  leave(user, roomId) {
    const r = this.#member(user, roomId);
    if (r.state === 'closed') return;
    this.#removeMember(r, user.id, 'left');
    this.store.save();
  }

  kick(user, roomId, targetId) {
    const r = this.#open(this.#host(user, roomId));
    if (typeof targetId !== 'string' || !r.members[targetId]) throw new UserError('Ese jugador no está en la sala.', 404, 'not_found');
    if (targetId === user.id) throw new UserError('No puedes expulsarte a ti mismo; usa "Salir".', 400);
    r.kicked.push(targetId);
    this.#removeMember(r, targetId, 'kicked');
    this.store.save();
    this.log.info('room.kicked', { room: r.id, user: targetId });
    return this.view(r, user);
  }

  rotateInvite(user, roomId, { action, ttlMin } = {}) {
    const r = this.#open(this.#host(user, roomId));
    if (action === 'revoke') {
      r.invite.revoked = true;
    } else if (action === 'regenerate') {
      this.codeIndex.delete(r.invite.code);
      let exp = null;
      if (ttlMin !== undefined && ttlMin !== null && ttlMin !== '') {
        const m = Number(ttlMin);
        if (!Number.isFinite(m) || m < 1 || m > 7 * 1440) throw new UserError('La duración de la invitación no es válida.');
        exp = this.now() + m * 60_000;
      }
      r.invite = { code: this.#newCode(), revoked: false, expiresAt: exp };
      this.codeIndex.set(r.invite.code, r.id);
    } else {
      throw new UserError('Acción de invitación no válida.');
    }
    this.store.save();
    this.log.info('room.invite', { room: r.id, action });
    return this.view(r, user);
  }

  settings(user, roomId, { name, max }) {
    const r = this.#open(this.#host(user, roomId));
    if (name !== undefined) r.name = cleanText(name, { min: 2, max: 40, field: 'El nombre de la sala' });
    if (max !== undefined) {
      const m = Number(max);
      if (!Number.isInteger(m) || m < 2 || m > this.cfg.maxRoomPlayers) throw new UserError(`El máximo debe estar entre 2 y ${this.cfg.maxRoomPlayers}.`);
      if (m < Object.keys(r.members).length) throw new UserError('Hay más jugadores en la sala que ese máximo.', 409);
      r.max = m;
    }
    this.store.save();
    this.emit('room', r.id);
    return this.view(r, user);
  }

  setState(user, roomId, next) {
    const r = this.#host(user, roomId);
    this.#open(r);
    if (!Object.hasOwn(TRANSITIONS, next)) throw new UserError('Estado de sala desconocido.');
    if (!TRANSITIONS[r.state].includes(next)) {
      throw new UserError(`No se puede pasar de "${STATE_LABEL[r.state]}" a "${STATE_LABEL[next]}".`, 409, 'bad_transition');
    }
    if (next === 'starting' && !this.games.versionOf(this.games.games[r.gameId] || { versions: [] }, r.version)) {
      throw new UserError('La versión del juego de esta sala ya no existe.', 409, 'no_version');
    }
    this.#apply(r, next);
    return this.view(r, user);
  }

  #after(roomId, ms, fn) {
    this.#clearTimer(roomId);
    const t = setTimeout(() => { this.timers.delete(roomId); try { fn(); } catch (e) { this.log.error('room.timer_failed', { message: e.message }); } }, ms);
    t.unref?.();
    this.timers.set(roomId, t);
  }

  #clearTimer(roomId) {
    const t = this.timers.get(roomId);
    if (t) { clearTimeout(t); this.timers.delete(roomId); }
  }

  #apply(r, next, immediate = false) {
    const prev = r.state;
    r.state = next;
    r.lastActivity = this.now();
    if (next === 'starting') {
      this.ready.set(r.id, new Set());
      this.#after(r.id, this.startTimeoutMs, () => { if (r.state === 'starting') this.#apply(r, 'playing'); });
    } else if (next === 'playing') {
      this.#clearTimer(r.id);
      this.ready.delete(r.id);
    } else if (next === 'waiting') {
      this.#clearTimer(r.id);
      this.ready.delete(r.id);
      this.shared.delete(r.id);
      this.states.delete(r.id);
    } else if (next === 'closing') {
      this.#clearTimer(r.id);
      this.ready.delete(r.id);
      if (immediate) { this.#apply(r, 'closed'); return; }
      this.#after(r.id, this.cfg.closeDelayMs, () => { if (r.state === 'closing') this.#apply(r, 'closed'); });
    } else if (next === 'closed') {
      this.#clearTimer(r.id);
      r.closedAt = this.now();
      this.online.delete(r.id);
      this.shared.delete(r.id);
      this.states.delete(r.id);
      for (const k of [...this.offlineSince.keys()]) if (k.startsWith(`${r.id}:`)) this.offlineSince.delete(k);
    }
    this.store.save();
    this.log.info('room.state', { room: r.id, from: prev, to: next });
    this.emit('room', r.id);
    if (next === 'closed') this.emit('closed', r.id);
  }

  // ---------- Presencia y estado en tiempo real ----------
  markReady(roomId, userId) {
    const r = this.rooms[roomId];
    if (!r || r.state !== 'starting' || !r.members[userId]) return;
    this.ready.get(r.id)?.add(userId);
    this.emit('players', r.id, { type: 'ready', id: userId });
    this.#checkAllReady(r);
  }

  #checkAllReady(r) {
    if (r.state !== 'starting') return;
    const rd = this.ready.get(r.id);
    const on = [...(this.online.get(r.id) ?? [])];
    if (on.length && on.every((id) => rd?.has(id))) this.#apply(r, 'playing');
  }

  setOnline(roomId, userId, isOnline) {
    const r = this.rooms[roomId];
    if (!r || !r.members[userId] || r.state === 'closed') return;
    let set = this.online.get(roomId);
    if (!set) { set = new Set(); this.online.set(roomId, set); }
    const was = set.has(userId);
    if (isOnline) { set.add(userId); this.offlineSince.delete(`${roomId}:${userId}`); }
    else { set.delete(userId); this.offlineSince.set(`${roomId}:${userId}`, this.now()); }
    r.lastActivity = this.now();
    if (was !== isOnline) {
      this.emit('players', roomId, { type: isOnline ? 'online' : 'offline', id: userId });
      if (!isOnline) this.#checkAllReady(r);
    }
  }

  touch(roomId) {
    const r = this.rooms[roomId];
    if (r) r.lastActivity = this.now();
  }

  sharedOf(roomId) { return Object.fromEntries(this.shared.get(roomId) ?? []); }
  statesOf(roomId) { return Object.fromEntries(this.states.get(roomId) ?? []); }

  setPlayerState(roomId, userId, data) {
    let m = this.states.get(roomId);
    if (!m) { m = new Map(); this.states.set(roomId, m); }
    m.set(userId, data);
  }

  /** value === null borra la clave. Devuelve false si supera el tamaño total permitido. */
  setShared(roomId, key, value) {
    let m = this.shared.get(roomId);
    if (!m) { m = new Map(); this.shared.set(roomId, m); }
    if (value === null) { m.delete(key); return true; }
    const prev = m.get(key);
    m.set(key, value);
    let total = 0;
    for (const [k, v] of m) total += k.length + Buffer.byteLength(JSON.stringify(v));
    if (total > this.cfg.wsMaxSharedTotalBytes) {
      if (prev === undefined) m.delete(key); else m.set(key, prev);
      return false;
    }
    return true;
  }

  renameUser(user) {
    for (const r of Object.values(this.rooms)) {
      if (r.members[user.id] && r.state !== 'closed') {
        r.members[user.id].name = user.name;
        this.emit('players', r.id, { type: 'rename', id: user.id });
      }
    }
    this.store.save();
  }

  // ---------- Mantenimiento periódico ----------
  sweep() {
    const t = this.now();
    let changed = false;
    for (const r of Object.values(this.rooms)) {
      if (r.state === 'closed') {
        if (r.closedAt && t - r.closedAt > this.cfg.closedRoomKeepMs) {
          delete this.rooms[r.id];
          this.codeIndex.delete(r.invite?.code);
          changed = true;
        }
        continue;
      }
      if (t >= r.expiresAt) { this.log.info('room.expired', { room: r.id }); this.#apply(r, 'closing', true); continue; }
      const onlineCount = this.online.get(r.id)?.size ?? 0;
      if (!onlineCount && t - r.lastActivity > this.cfg.roomIdleMs) {
        this.log.info('room.idle_closed', { room: r.id });
        this.#apply(r, 'closing', true);
        continue;
      }
      for (const uid of Object.keys(r.members)) {
        if (this.isOnline(r.id, uid)) continue;
        const since = this.offlineSince.get(`${r.id}:${uid}`) ?? t;
        if (uid === r.hostId) {
          if (t - since > HOST_GRACE_MS && this.#transferHost(r)) changed = true;
        } else if (r.state === 'waiting' && t - since > OFFLINE_GRACE_MS) {
          this.#removeMember(r, uid, 'timeout');
          changed = true;
        }
      }
    }
    if (changed) this.store.save();
  }

  shutdown() {
    for (const id of [...this.timers.keys()]) this.#clearTimer(id);
  }
}
