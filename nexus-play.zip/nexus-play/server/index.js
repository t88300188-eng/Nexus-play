import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createServer } from './app.js';
import { loadConfig } from './config.js';

const cfg = loadConfig();

// Un solo servidor por carpeta de datos: dos procesos escribiendo db.json la corromperían.
function acquireLock(dir) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, '.lock');
  try {
    const pid = Number(fs.readFileSync(file, 'utf8'));
    if (pid && pid !== process.pid) {
      let alive = true;
      try { process.kill(pid, 0); } catch (e) { alive = e.code === 'EPERM'; }
      if (alive) return { ok: false, pid };
    }
  } catch { /* no existe o ilegible: se toma */ }
  fs.writeFileSync(file, String(process.pid));
  return { ok: true, file };
}

const lock = acquireLock(cfg.dataDir);
if (!lock.ok) {
  console.error(`\n✖ Ya hay un servidor NEXUS PLAY usando esta carpeta de datos (PID ${lock.pid}).`);
  console.error('  Ciérralo primero (Ctrl+C en su sesión) o usa otra carpeta con DATA_DIR=...\n');
  process.exit(1);
}

let s;
try {
  s = await createServer();
  const addr = await s.start();
  const lan = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  console.log('\n  NEXUS PLAY', cfg.version);
  console.log(`  Local:  http://localhost:${addr.port}`);
  for (const ip of lan) console.log(`  Red:    http://${ip}:${addr.port}   <- comparte esta dirección con tus amigos (misma red Wi-Fi)`);
  console.log(`  Datos:  ${cfg.dataDir}`);
  if (cfg.uploadKey) console.log('  Subidas protegidas con UPLOAD_KEY.');
  console.log('  Ctrl+C para detener.\n');
} catch (e) {
  fs.rmSync(path.join(cfg.dataDir, '.lock'), { force: true });
  if (e.code === 'EADDRINUSE') console.error(`\n✖ El puerto ${cfg.port} ya está en uso. Usa otro: PORT=3001 npm start\n`);
  else console.error('\n✖ No se pudo iniciar:', e.message, '\n');
  process.exit(1);
}

let stopping = false;
async function shutdown(code = 0) {
  if (stopping) return;
  stopping = true;
  try { await s.stop(); } catch (e) { console.error('Error al detener:', e.message); }
  fs.rmSync(path.join(cfg.dataDir, '.lock'), { force: true });
  process.exit(code);
}
process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));
process.on('SIGHUP', () => shutdown(0));
process.on('uncaughtException', (e) => { s.log.error('uncaught', { message: e.message, stack: String(e.stack).split('\n').slice(0, 4).join(' | ') }); shutdown(1); });
process.on('unhandledRejection', (e) => { s.log.error('unhandled_rejection', { message: String(e?.message ?? e) }); });
