// Registro de eventos en memoria (anillo) + consola. Nunca guarda secretos.
const SECRET_KEY = /token|ticket|secret|password|authorization|invite|cookie|^code$|^key$/i;

function redact(value, depth = 0) {
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') return value.length > 200 ? value.slice(0, 200) + '…' : value;
  if (typeof value !== 'object') return value;
  if (depth > 3) return '[…]';
  if (Array.isArray(value)) return value.slice(0, 20).map((v) => redact(v, depth + 1));
  const out = {};
  for (const [k, v] of Object.entries(value)) {
    out[k] = SECRET_KEY.test(k) ? '[oculto]' : redact(v, depth + 1);
  }
  return out;
}

export function createLogger({ quiet = false, max = 400 } = {}) {
  const buf = [];
  function add(level, event, data = {}) {
    const entry = { ts: Date.now(), level, event, data: redact(data) };
    buf.push(entry);
    if (buf.length > max) buf.shift();
    if (!quiet) {
      const extra = Object.keys(entry.data).length ? ' ' + JSON.stringify(entry.data) : '';
      const line = `[${new Date(entry.ts).toISOString()}] ${level.toUpperCase()} ${event}${extra}`;
      (level === 'error' ? console.error : console.log)(line);
    }
  }
  return {
    info: (e, d) => add('info', e, d),
    warn: (e, d) => add('warn', e, d),
    error: (e, d) => add('error', e, d),
    recent(n = 100, filter = () => true) {
      return buf.filter(filter).slice(-n);
    },
  };
}
