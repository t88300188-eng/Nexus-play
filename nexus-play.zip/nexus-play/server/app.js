import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import express from 'express';
import { loadConfig } from './config.js';
import { createLogger } from './log.js';
import { Store } from './store.js';
import { Auth } from './auth.js';
import { GameService, receiveUpload } from './games.js';
import { RoomService } from './rooms.js';
import { Realtime } from './realtime.js';
import { UserError } from './errors.js';
import { RateLimiter } from './ratelimit.js';
import { clientIp, safeEqual, mb } from './util.js';
import { extOf } from './zipsafe.js';

const GAME_CSP = "sandbox allow-scripts allow-pointer-lock allow-modals allow-forms; frame-ancestors 'self'";
const PANEL_CSP = [
  "default-src 'self'", "script-src 'self'", "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:", "connect-src 'self' ws: wss:", "frame-src 'self'",
  "frame-ancestors 'none'", "base-uri 'none'", "object-src 'none'", "form-action 'self'",
].join('; ');

const bodyOf = (req) => {
  const b = req.body;
  if (b === undefined) return {};
  if (b === null || typeof b !== 'object' || Array.isArray(b)) throw new UserError('El cuerpo de la petición debe ser un objeto JSON.');
  return b;
};

export async function createServer(overrides = {}) {
  const config = loadConfig(overrides);
  const log = createLogger({ quiet: config.quiet });
  fs.mkdirSync(config.dataDir, { recursive: true });

  const store = new Store({ dir: config.dataDir, log });
  const auth = new Auth({ store, config, log });
  const games = new GameService({ store, config, log, auth });
  const rooms = new RoomService({ store, config, log, games });
  const realtime = new Realtime({ config, log, rooms, auth });
  if (config.seedDemo !== false) games.seedDemo();

  const startedAt = Date.now();
  const apiLimiter = new RateLimiter({ max: config.httpRatePerMin, windowMs: 60_000 });
  const uploadLimiter = new RateLimiter({ max: config.uploadsPer10Min, windowMs: 600_000 });
  const joinLimiter = new RateLimiter({ max: 30, windowMs: 600_000 });

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);
  const ipOf = (req) => clientIp(req, config.trustProxy);

  app.use((req, res, next) => {
    res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' });
    next();
  });

  // ---------- Archivos de los juegos (contenido NO confiable) ----------
  const gameHeaders = (res, cache) => res.set({
    'Content-Security-Policy': GAME_CSP,
    'Access-Control-Allow-Origin': '*',
    'Cross-Origin-Resource-Policy': 'cross-origin',
    'Cache-Control': cache,
  });
  const sendGameFile = (res, f, cache) => {
    gameHeaders(res, cache);
    res.set('Content-Type', f.type);
    res.sendFile(f.abs, { dotfiles: 'allow', cacheControl: false, headers: {} });
  };
  const relOf = (req) => [].concat(req.params.path ?? []).join('/');

  app.get('/g/:gid/:ver/*path', (req, res) => {
    const f = games.resolvePublic(req.params.gid, req.params.ver, relOf(req));
    if (!f) return res.status(404).type('text').send('No encontrado');
    sendGameFile(res, f, 'public, max-age=3600');
  });
  app.get('/gp/:token/*path', (req, res) => {
    const f = games.resolvePreview(req.params.token, relOf(req));
    if (!f) return res.status(404).type('text').send('No encontrado');
    sendGameFile(res, f, 'no-store');
  });

  // ---------- Panel ----------
  app.use((req, res, next) => {
    res.set({
      'Content-Security-Policy': PANEL_CSP,
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
      'X-Frame-Options': 'DENY',
    });
    next();
  });

  app.use('/api', (req, res, next) => {
    if (!apiLimiter.hit(ipOf(req))) {
      res.set('Retry-After', String(apiLimiter.retryAfterSec(ipOf(req))));
      throw new UserError('Demasiadas peticiones. Espera un momento.', 429, 'rate_limited');
    }
    next();
  });
  app.use('/api', express.json({ limit: '32kb' }));

  const requireUser = (req, _res, next) => {
    const u = auth.fromRequest(req);
    if (!u) throw new UserError('Tu sesión no es válida. Vuelve a entrar.', 401, 'unauthorized');
    req.user = u;
    next();
  };
  const requireUploadKey = (req) => {
    if (!config.uploadKey) return;
    const k = req.headers['x-upload-key'];
    if (typeof k !== 'string' || !safeEqual(k, config.uploadKey)) {
      throw new UserError('Este servidor pide una clave de subida.', 401, 'upload_key_required');
    }
  };
  const uploadGate = (req) => {
    requireUploadKey(req);
    if (!uploadLimiter.hit(req.user.id)) throw new UserError('Demasiadas subidas seguidas. Espera unos minutos.', 429, 'rate_limited');
  };
  const checkLength = (req, cap, msg) => {
    const len = Number(req.headers['content-length']);
    if (Number.isFinite(len) && len > cap) throw new UserError(msg, 413, 'too_big');
  };

  // ---------- Estado y sesión ----------
  app.get('/api/health', (_req, res) => {
    res.set('Cache-Control', 'no-store').json({
      ok: true, name: 'NEXUS PLAY', version: config.version, time: Date.now(),
      uploadKeyRequired: !!config.uploadKey,
      limits: {
        maxHtmlMb: mb(config.maxHtmlBytes), maxZipMb: mb(config.maxZipBytes), maxUnzippedMb: mb(config.maxUnzippedBytes),
        maxUserMb: mb(config.maxUserBytes), maxRoomPlayers: config.maxRoomPlayers, maxVersions: config.maxVersionsPerGame,
      },
    });
  });

  app.post('/api/session', (req, res) => {
    const { name } = bodyOf(req);
    res.status(201).json(auth.createSession(name, ipOf(req)));
  });
  app.get('/api/me', requireUser, (req, res) => res.json({ user: auth.publicUser(req.user) }));
  app.patch('/api/me', requireUser, (req, res) => {
    const user = auth.rename(req.user, bodyOf(req).name);
    rooms.renameUser(req.user);
    res.json({ user });
  });

  // ---------- Juegos ----------
  app.get('/api/games', requireUser, (req, res) => res.json({ games: games.list(req.user) }));
  app.get('/api/games/:id', requireUser, (req, res) => res.json({ game: games.get(req.user, req.params.id, { detail: true }) }));

  app.get('/api/games/:id/thumbnail', (req, res) => {
    const t = games.thumbnail(req.params.id);
    if (!t) return res.status(404).type('text').send('Sin miniatura');
    res.set({ 'Content-Type': t.type, 'Cache-Control': 'public, max-age=300', 'Cross-Origin-Resource-Policy': 'same-origin' });
    res.sendFile(t.abs, { dotfiles: 'allow', cacheControl: false });
  });

  app.post('/api/games', requireUser, async (req, res) => {
    uploadGate(req);
    const filename = String(req.query.filename ?? '');
    const ext = extOf(filename);
    if (!['zip', 'html', 'htm'].includes(ext)) throw new UserError('Solo se admiten archivos .html o .zip.', 400, 'bad_type');
    const cap = games.maxUploadBytes(filename);
    const msg = `El archivo supera el máximo de ${mb(cap)} MB para ${ext === 'zip' ? 'ZIP' : 'HTML'}.`;
    checkLength(req, cap, msg);
    const upload = await receiveUpload(req, games.tmpDir, cap, msg);
    const game = await games.createGame(req.user, { title: req.query.title, description: req.query.description, upload, filename });
    res.status(201).json({ game });
  });

  app.post('/api/games/:id/versions', requireUser, async (req, res) => {
    uploadGate(req);
    const filename = String(req.query.filename ?? '');
    const ext = extOf(filename);
    if (!['zip', 'html', 'htm'].includes(ext)) throw new UserError('Solo se admiten archivos .html o .zip.', 400, 'bad_type');
    const cap = games.maxUploadBytes(filename);
    const msg = `El archivo supera el máximo de ${mb(cap)} MB para ${ext === 'zip' ? 'ZIP' : 'HTML'}.`;
    checkLength(req, cap, msg);
    const upload = await receiveUpload(req, games.tmpDir, cap, msg);
    res.status(201).json({ game: await games.addVersion(req.user, req.params.id, { upload, filename, note: req.query.note }) });
  });

  app.put('/api/games/:id/thumbnail', requireUser, async (req, res) => {
    requireUploadKey(req);
    checkLength(req, games.thumbMax, 'La miniatura supera 512 KB.');
    const upload = await receiveUpload(req, games.tmpDir, games.thumbMax, 'La miniatura supera 512 KB.');
    res.json({ game: await games.setThumbnail(req.user, req.params.id, upload) });
  });
  app.delete('/api/games/:id/thumbnail', requireUser, (req, res) => res.json({ game: games.removeThumbnail(req.user, req.params.id) }));

  app.patch('/api/games/:id', requireUser, (req, res) => {
    const b = bodyOf(req);
    res.json({ game: games.update(req.user, req.params.id, { title: b.title, description: b.description, published: b.published }) });
  });
  app.delete('/api/games/:id', requireUser, (req, res) => { games.deleteGame(req.user, req.params.id); res.json({ ok: true }); });
  app.post('/api/games/:id/current', requireUser, (req, res) => res.json({ game: games.setCurrent(req.user, req.params.id, bodyOf(req).version) }));
  app.delete('/api/games/:id/versions/:n', requireUser, (req, res) => res.json({ game: games.deleteVersion(req.user, req.params.id, req.params.n) }));

  app.get('/api/games/:id/preview', requireUser, (req, res) => {
    const { token, entry } = games.previewToken(req.user, req.params.id, req.query.version === undefined ? undefined : Number(req.query.version));
    res.set('Cache-Control', 'no-store').json({ url: `/gp/${token}/${entry}`, expiresInMs: 2 * 3600_000 });
  });
  app.get('/api/games/:id/analysis', requireUser, (req, res) => {
    res.json({ analysis: games.analysis(req.user, req.params.id, req.query.version === undefined ? undefined : Number(req.query.version)) });
  });
  app.post('/api/games/:id/integrate', requireUser, (req, res) => {
    const b = bodyOf(req);
    res.status(201).json({ game: games.integrate(req.user, req.params.id, { version: b.version, accept: b.accept }) });
  });

  // ---------- Salas ----------
  app.get('/api/rooms', requireUser, (req, res) => res.json({ rooms: rooms.listFor(req.user) }));
  app.post('/api/rooms', requireUser, (req, res) => {
    const b = bodyOf(req);
    res.status(201).json({ room: rooms.create(req.user, { gameId: b.gameId, name: b.name, max: b.max, inviteTtlMin: b.inviteTtlMin }) });
  });
  app.post('/api/rooms/join', requireUser, (req, res) => {
    if (!joinLimiter.hit(ipOf(req))) {
      res.set('Retry-After', String(joinLimiter.retryAfterSec(ipOf(req))));
      throw new UserError('Demasiados intentos con códigos. Espera unos minutos.', 429, 'rate_limited');
    }
    res.json({ room: rooms.join(req.user, bodyOf(req).code) });
  });
  app.get('/api/rooms/:id', requireUser, (req, res) => res.json({ room: rooms.getFor(req.user, req.params.id) }));
  app.post('/api/rooms/:id/leave', requireUser, (req, res) => { rooms.leave(req.user, req.params.id); res.json({ ok: true }); });
  app.post('/api/rooms/:id/state', requireUser, (req, res) => res.json({ room: rooms.setState(req.user, req.params.id, bodyOf(req).state) }));
  app.post('/api/rooms/:id/invite', requireUser, (req, res) => {
    const b = bodyOf(req);
    res.json({ room: rooms.rotateInvite(req.user, req.params.id, { action: b.action, ttlMin: b.ttlMin }) });
  });
  app.post('/api/rooms/:id/kick', requireUser, (req, res) => res.json({ room: rooms.kick(req.user, req.params.id, bodyOf(req).userId) }));
  app.post('/api/rooms/:id/settings', requireUser, (req, res) => {
    const b = bodyOf(req);
    res.json({ room: rooms.settings(req.user, req.params.id, { name: b.name, max: b.max }) });
  });
  app.post('/api/rooms/:id/ticket', requireUser, (req, res) => {
    res.set('Cache-Control', 'no-store').json(realtime.issueTicket(req.user, req.params.id));
  });

  // ---------- Diagnóstico ----------
  app.get('/api/diagnostics', requireUser, (req, res) => {
    let writable = false;
    try {
      const probe = path.join(config.dataDir, `.probe-${process.pid}`);
      fs.writeFileSync(probe, 'ok');
      fs.rmSync(probe);
      writable = true;
    } catch { /* writable=false */ }
    let freeMb = null;
    try { const s = fs.statfsSync(config.dataDir); freeMb = Math.round((Number(s.bavail) * Number(s.bsize)) / 1048576); } catch { /* no disponible */ }
    const mem = process.memoryUsage();
    res.set('Cache-Control', 'no-store').json({
      generatedAt: Date.now(),
      server: {
        version: config.version, node: process.version, platform: process.platform, arch: process.arch,
        uptimeSec: Math.round((Date.now() - startedAt) / 1000), rssMb: Math.round(mem.rss / 1048576),
        heapMb: Math.round(mem.heapUsed / 1048576),
      },
      storage: { dataDirWritable: writable, gamesMb: mb(games.diskBytes()), freeMb, ...store.status() },
      realtime: realtime.stats(),
      rooms: { ...rooms.stats(), mine: rooms.summary(req.user) },
      games: { ...games.stats(), mineMb: mb(games.userBytes(req.user.id)), quotaMb: mb(config.maxUserBytes), recentErrors: games.errors.slice(-10) },
      limits: {
        wsMessageBytes: config.wsMaxMessageBytes, wsRatePerSec: config.wsRatePerSec, wsBurst: config.wsBurst,
        wsMaxConnections: config.wsMaxConnections, roomTtlMin: Math.round(config.roomTtlMs / 60000),
      },
      logs: log.recent(60),
    });
  });

  app.use('/api', (_req, _res, next) => next(new UserError('Ruta de API no encontrada.', 404, 'not_found')));

  // ---------- Archivos estáticos del panel ----------
  app.use(express.static(path.join(config.rootDir, 'public'), { dotfiles: 'ignore', index: 'index.html', maxAge: '5m' }));

  // ---------- Errores ----------
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, _next) => {
    if (!req.complete) res.set('Connection', 'close');
    let status = 500;
    let body = { error: { code: 'internal', message: 'Error interno del servidor.' } };
    if (err instanceof UserError) {
      status = err.status;
      body = { error: { code: err.code, message: err.message } };
    } else if (err?.type === 'entity.too.large') {
      status = 413;
      body = { error: { code: 'too_big', message: 'La petición es demasiado grande.' } };
    } else if (err?.type === 'entity.parse.failed' || err instanceof SyntaxError) {
      status = 400;
      body = { error: { code: 'bad_json', message: 'El cuerpo no es JSON válido.' } };
    } else {
      log.error('http.unhandled', { path: req.path, message: err?.message });
    }
    if (res.headersSent) { res.destroy(); return; }
    res.status(status).json(body);
  });

  // ---------- Ciclo de vida ----------
  const server = http.createServer(app);
  realtime.attach(server);
  let sweepTimer = null;
  let pruneCount = 0;

  const api = {
    config, app, server, store, auth, games, rooms, realtime, log,
    start() {
      return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(config.port, config.host, () => {
          server.off('error', reject);
          sweepTimer = setInterval(() => {
            try {
              rooms.sweep();
              if (++pruneCount % 120 === 0) auth.prune();
            } catch (e) { log.error('sweep.failed', { message: e.message }); }
          }, config.sweepMs);
          sweepTimer.unref?.();
          resolve(server.address());
        });
      });
    },
    async stop() {
      clearInterval(sweepTimer);
      rooms.shutdown();
      realtime.shutdown();
      await new Promise((r) => { server.close(() => r()); server.closeAllConnections?.(); });
      store.close();
    },
    url() {
      const a = server.address();
      return `http://127.0.0.1:${a.port}`;
    },
  };
  return api;
}
