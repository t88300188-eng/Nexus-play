import crypto from 'node:crypto';
import { UserError } from './errors.js';

export const sha256 = (data) => crypto.createHash('sha256').update(data).digest('hex');
export const randId = (prefix, bytes = 6) => prefix + crypto.randomBytes(bytes).toString('hex');
export const randToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');

// 32 símbolos (sin I ni O) => cada byte aporta 5 bits sin sesgo. 12 símbolos = 60 bits.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function randCode(len = 12) {
  const b = crypto.randomBytes(len);
  let s = '';
  for (let i = 0; i < len; i++) s += ALPHABET[b[i] & 31];
  return s;
}
export const formatCode = (c) => (c.match(/.{1,4}/g) || []).join('-');
export const normalizeCode = (s) => String(s ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');

export function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  if (x.length !== y.length) return false;
  return crypto.timingSafeEqual(x, y);
}

/** Valida y limpia texto de entrada del usuario. */
export function cleanText(v, { min = 0, max = 100, field = 'El campo', multiline = false } = {}) {
  if (v === undefined || v === null) v = '';
  if (typeof v !== 'string') throw new UserError(`${field} no es válido.`);
  let s = v.normalize('NFC');
  s = multiline
    ? s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
    : s.replace(/[\u0000-\u001f\u007f]/g, ' ');
  s = s.trim();
  if (s.length < min) throw new UserError(`${field} debe tener al menos ${min} caracteres.`);
  if (s.length > max) throw new UserError(`${field} admite como máximo ${max} caracteres.`);
  return s;
}

/** Comprueba profundidad y número de nodos de un valor JSON recibido. */
export function jsonDepthOk(v, maxDepth = 6, maxNodes = 5000) {
  let nodes = 0;
  const walk = (x, d) => {
    if (d > maxDepth || ++nodes > maxNodes) return false;
    if (x && typeof x === 'object') {
      for (const k of Object.keys(x)) {
        if (k === '__proto__') return false;
        if (!walk(x[k], d + 1)) return false;
      }
    }
    return true;
  };
  return walk(v, 1);
}

export const jsonBytes = (v) => Buffer.byteLength(JSON.stringify(v) ?? '');

export function clientIp(req, trustProxy = false) {
  if (trustProxy) {
    const xff = req.headers['x-forwarded-for'];
    if (typeof xff === 'string' && xff) return xff.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || 'desconocida';
}

export const mb = (bytes) => Math.round((bytes / 1048576) * 10) / 10;
