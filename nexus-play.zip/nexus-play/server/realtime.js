import { WebSocketServer } from 'ws';
import { UserError } from './errors.js';
import { randToken, jsonDepthOk, clientIp } from './util.js';
import { RateLimiter, TokenBucket } from './ratelimit.js';

// Códigos de cierre propios (4000-4999). Ver docs/MULTIPLAYER_PROTOCOL.md
export const CLOSE = {
  ROOM_CLOSED: 4001, NOT_MEMBER: 4002, REPLACED: 4003, BAD_TICKET: 4004,
  KICKED: 4005, LEFT: 4006, RATE_LIMIT: 4008, BAD_ORIGIN: 4010,
};

const EVENT_NAME = /^[A-Za-z0-9_.:-]{1,32}$/;
const SHARED_KEY = /^[A-Za-z0-9_.-]{1,32}$/;
const LIVE_STATES = new Set(['waiting', 'starting', 'playing']);

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

export class Realtime {
  constructor({ config, log, rooms, auth, now = Date.now }) {
    this.cfg = config;
    this.log = log;
    this.rooms = rooms;
    this.auth = auth;
    this.now = now;
    this.wss = new WebSocketServer({ noServer: true, maxPayload: config.wsMaxPayload, perMessageDeflate: false });
    this.byRoom = new Map();   // roomId -> Map(userId -> conn)
    this.conns = new Set();
    this.perIp = new Map();
    this.tickets = new Map();
    this.ticketLimiter = new RateLimiter({ max: 60, windowMs: 60_000, now });
    this.counters = { accepted: 0, rejected: 0, messagesIn: 0, invalid: 0, rateLimited: 0, closedByServer: 0 };
    this.lastErrors = [];

    rooms.on('players', (roomId, change) => this.#onPlayers(roomId, change));
    rooms.on('room', (roomId) => this.#onRoom(roomId));
    rooms.on('evict', (roomId, userId, reason) => this.#onEvict(roomId, userId, reason));
    rooms.on('closed', (roomId) => this.#onClosed(roomId));

    this.heartbeat = setInterval(() => this.#beat(), config.wsHeartbeatMs);
    this.heartbeat.unref?.();
  }

  // ---------- Tickets (credencial de un solo uso para abrir el WebSocket) ----------
  issueTicket(user, roomId) {
    if (!this.ticketLimiter.hit(user.id)) throw new UserError('Demasiados intentos de conexión. Espera un momento.', 429, 'rate_limited');
    const r = this.rooms.rooms[roomId];
    if (!r || !r.members[user.id]) throw new UserError('Esa sala no existe o no tienes acceso.', 404, 'not_found');
    if (r.state === 'closed') throw new UserError('La sala ya está cerrada.', 410, 'room_closed');
    const t = this.now();
    if (this.tickets.size > 2000) for (const [k, v] of this.tickets) if (v.exp < t) this.tickets.delete(k);
    const ticket = randToken(24);
    this.tickets.set(ticket, { userId: user.id, roomId, exp: t + this.cfg.ticketTtlMs });
    return { ticket, expiresInMs: this.cfg.ticketTtlMs };
  }

  // ---------- Conexión ----------
  attach(httpServer) {
    httpServer.on('upgrade', (req, socket, head) => {
      let url;
      try { url = new URL(req.url, 'http://localhost'); } catch { socket.destroy(); return; }
      if (url.pathname !== '/ws') { socket.destroy(); return; }
      this.wss.handleUpgrade(req, socket, head, (ws) => this.#onConnection(ws, req, url));
    });
  }

  #originOk(req) {
    const o = req.headers.origin;
    if (!o) return true; // clientes que no son navegadores
    try { return new URL(o).host === req.headers.host; } catch { return false; }
  }

  #reject(ws, code, reason) {
    this.counters.rejected++;
    try { ws.close(code, reason); } catch { /* ya cerrado */ }
  }

  #onConnection(ws, req, url) {
    const ip = clientIp(req, this.cfg.trustProxy);
    ws.on('error', (e) => this.#noteError('ws_error', e.message));
    if (!this.#originOk(req)) return this.#reject(ws, CLOSE.BAD_ORIGIN, 'origin');
    if (this.conns.size >= this.cfg.wsMaxConnections || (this.perIp.get(ip) ?? 0) >= this.cfg.wsMaxPerIp) {
      return this.#reject(ws, 1013, 'busy');
    }
    const key = url.searchParams.get('t') || '';
    const tk = this.tickets.get(key);
    this.tickets.delete(key); // un solo uso, exista o no
    if (!tk || tk.exp < this.now()) return this.#reject(ws, CLOSE.BAD_TICKET, 'ticket');
    const room = this.rooms.rooms[tk.roomId];
    const user = this.auth.users[tk.userId];
    if (!room || !user || room.state === 'closed') return this.#reject(ws, CLOSE.ROOM_CLOSED, 'closed');
    if (!room.members[user.id]) return this.#reject(ws, CLOSE.NOT_MEMBER, 'not_member');

    const c = {
      ws, ip, userId: user.id, roomId: room.id, name: user.name,
      bucket: new TokenBucket(this.cfg.wsRatePerSec, this.cfg.wsBurst, this.now),
      bad: 0, drops: 0, lastRateErr: 0, alive: true,
    };
    let map = this.byRoom.get(room.id);
    if (!map) { map = new Map(); this.byRoom.set(room.id, map); }
    const old = map.get(user.id);
    map.set(user.id, c);
    this.conns.add(c);
    this.perIp.set(ip, (this.perIp.get(ip) ?? 0) + 1);
    this.counters.accepted++;
    if (old) {
      this.#send(old, { t: 'bye', reason: 'replaced' });
      try { old.ws.close(CLOSE.REPLACED, 'replaced'); } catch { /* ignorar */ }
    }

    ws.on('pong', () => { c.alive = true; });
    ws.on('message', (data, isBinary) => this.#onMessage(c, data, isBinary));
    ws.on('close', () => this.#onClose(c));

    this.rooms.setOnline(room.id, user.id, true);
    this.#send(c, {
      t: 'hello', v: 1, serverTime: this.now(),
      you: { id: user.id, name: user.name, host: room.hostId === user.id },
      room: this.rooms.publicRoom(room),
      players: this.rooms.players(room),
      states: this.rooms.statesOf(room.id),
      shared: this.rooms.sharedOf(room.id),
    });
    this.log.info('ws.connected', { room: room.id, user: user.id });
  }

  #onClose(c) {
    this.conns.delete(c);
    const n = (this.perIp.get(c.ip) ?? 1) - 1;
    if (n <= 0) this.perIp.delete(c.ip); else this.perIp.set(c.ip, n);
    const map = this.byRoom.get(c.roomId);
    if (map?.get(c.userId) === c) {
      map.delete(c.userId);
      if (!map.size) this.byRoom.delete(c.roomId);
      this.rooms.setOnline(c.roomId, c.userId, false);
      this.log.info('ws.disconnected', { room: c.roomId, user: c.userId });
    }
  }

  // ---------- Mensajes entrantes ----------
  #noteError(kind, message) {
    this.lastErrors.push({ ts: this.now(), kind, message });
    if (this.lastErrors.length > 30) this.lastErrors.shift();
  }

  #bad(c, code, message) {
    this.counters.invalid++;
    c.bad++;
    this.#send(c, { t: 'err', code, message });
    if (c.bad >= 20) {
      this.#noteError('too_many_invalid', c.userId);
      this.#send(c, { t: 'bye', reason: 'too_many_errors' });
      try { c.ws.close(CLOSE.RATE_LIMIT, 'too_many_errors'); } catch { /* ignorar */ }
    }
  }

  #onMessage(c, data, isBinary) {
    this.counters.messagesIn++;
    if (isBinary) { this.#bad(c, 'binary_not_allowed', 'Solo se aceptan mensajes de texto JSON.'); return; }
    if (!c.bucket.take()) {
      this.counters.rateLimited++;
      c.drops++;
      const t = this.now();
      if (t - c.lastRateErr > 2000) {
        c.lastRateErr = t;
        this.#send(c, { t: 'err', code: 'rate_limited', message: 'Estás enviando demasiados mensajes.' });
      }
      if (c.drops > 200) {
        this.#noteError('flood', c.userId);
        try { c.ws.close(CLOSE.RATE_LIMIT, 'rate_limited'); } catch { /* ignorar */ }
      }
      return;
    }
    const raw = Buffer.isBuffer(data) ? data : Buffer.concat(Array.isArray(data) ? data : [Buffer.from(data)]);
    if (raw.length > this.cfg.wsMaxMessageBytes) { this.#bad(c, 'too_large', `Mensaje demasiado grande (máximo ${this.cfg.wsMaxMessageBytes} bytes).`); return; }
    let m;
    try { m = JSON.parse(raw.toString('utf8')); } catch { this.#bad(c, 'bad_json', 'El mensaje no es JSON válido.'); return; }
    if (!isPlainObject(m) || typeof m.t !== 'string') { this.#bad(c, 'bad_message', 'Formato de mensaje no válido.'); return; }
    if (m.v !== undefined && m.v !== 1) { this.#bad(c, 'bad_version', 'Versión de protocolo no soportada.'); return; }

    const room = this.rooms.rooms[c.roomId];
    if (!room || room.state === 'closed') return;

    switch (m.t) {
      case 'ping':
        if (typeof m.ts !== 'number' || !Number.isFinite(m.ts)) return this.#bad(c, 'bad_ping', 'Ping no válido.');
        this.#send(c, { t: 'pong', ts: m.ts });
        return;
      case 'ready':
        this.rooms.markReady(c.roomId, c.userId);
        return;
      case 'ev':
        return this.#onEvent(c, room, m);
      case 'st':
        return this.#onState(c, room, m);
      case 'sh':
        return this.#onShared(c, room, m);
      default:
        this.#bad(c, 'unknown_type', 'Tipo de mensaje desconocido.');
    }
  }

  #onEvent(c, room, m) {
    if (!LIVE_STATES.has(room.state)) return this.#bad(c, 'bad_state', 'La sala no admite eventos ahora.');
    if (typeof m.n !== 'string' || !EVENT_NAME.test(m.n)) return this.#bad(c, 'bad_event_name', 'Nombre de evento no válido (1-32 caracteres: letras, números, _ . : -).');
    if (m.d !== undefined && !jsonDepthOk(m.d, 6, 2000)) return this.#bad(c, 'bad_data', 'Los datos del evento son demasiado complejos.');
    const msg = { t: 'ev', n: m.n, d: m.d ?? null, from: c.userId };
    this.rooms.touch(c.roomId);
    if (m.to !== undefined && m.to !== null) {
      if (typeof m.to !== 'string' || m.to === c.userId || !room.members[m.to]) return this.#bad(c, 'bad_target', 'Destinatario no válido.');
      const target = this.byRoom.get(c.roomId)?.get(m.to);
      if (target) this.#send(target, msg);
      return;
    }
    this.#sendAll(c.roomId, msg, c.userId);
  }

  #onState(c, room, m) {
    if (!LIVE_STATES.has(room.state)) return this.#bad(c, 'bad_state', 'La sala no admite estados ahora.');
    if (!isPlainObject(m.d) || !jsonDepthOk(m.d, 5, 500)) return this.#bad(c, 'bad_data', 'El estado debe ser un objeto simple.');
    if (Buffer.byteLength(JSON.stringify(m.d)) > this.cfg.wsMaxStateBytes) return this.#bad(c, 'state_too_large', `El estado supera ${this.cfg.wsMaxStateBytes} bytes.`);
    this.rooms.setPlayerState(c.roomId, c.userId, m.d);
    this.rooms.touch(c.roomId);
    this.#sendAll(c.roomId, { t: 'st', from: c.userId, d: m.d }, c.userId);
  }

  #onShared(c, room, m) {
    if (!LIVE_STATES.has(room.state)) return this.#bad(c, 'bad_state', 'La sala no admite cambios ahora.');
    if (room.hostId !== c.userId) return this.#bad(c, 'forbidden', 'Solo el anfitrión puede modificar el estado compartido.');
    if (typeof m.k !== 'string' || !SHARED_KEY.test(m.k)) return this.#bad(c, 'bad_key', 'Clave no válida (1-32 caracteres: letras, números, _ . -).');
    const d = m.d === undefined ? null : m.d;
    if (d !== null) {
      if (!jsonDepthOk(d, 5, 1000)) return this.#bad(c, 'bad_data', 'Valor demasiado complejo.');
      if (Buffer.byteLength(JSON.stringify(d)) > this.cfg.wsMaxSharedValueBytes) return this.#bad(c, 'value_too_large', `El valor supera ${this.cfg.wsMaxSharedValueBytes} bytes.`);
    }
    if (!this.rooms.setShared(c.roomId, m.k, d)) return this.#bad(c, 'shared_full', 'El estado compartido de la sala está lleno.');
    this.rooms.touch(c.roomId);
    this.#sendAll(c.roomId, { t: 'sh', k: m.k, d });
  }

  // ---------- Salida ----------
  #send(c, obj) {
    const ws = c.ws;
    if (ws.readyState !== 1) return;
    if (ws.bufferedAmount > 2 * 1048576) { // cliente demasiado lento
      this.#noteError('slow_client', c.userId);
      ws.terminate();
      return;
    }
    ws.send(JSON.stringify(obj));
  }

  #sendAll(roomId, obj, exceptUserId) {
    const map = this.byRoom.get(roomId);
    if (!map) return;
    const payload = JSON.stringify(obj);
    for (const [uid, c] of map) {
      if (uid === exceptUserId || c.ws.readyState !== 1) continue;
      if (c.ws.bufferedAmount > 2 * 1048576) { this.#noteError('slow_client', uid); c.ws.terminate(); continue; }
      c.ws.send(payload);
    }
  }

  #onPlayers(roomId, change) {
    const r = this.rooms.rooms[roomId];
    if (!r) return;
    this.#sendAll(roomId, { t: 'players', list: this.rooms.players(r), change });
  }

  #onRoom(roomId) {
    const r = this.rooms.rooms[roomId];
    if (!r) return;
    this.#sendAll(roomId, { t: 'room', room: this.rooms.publicRoom(r), players: this.rooms.players(r) });
  }

  #onEvict(roomId, userId, reason) {
    const c = this.byRoom.get(roomId)?.get(userId);
    if (!c) return;
    this.#send(c, { t: 'bye', reason });
    const code = reason === 'kicked' ? CLOSE.KICKED : CLOSE.LEFT;
    this.counters.closedByServer++;
    try { c.ws.close(code, reason); } catch { /* ignorar */ }
  }

  #onClosed(roomId) {
    const map = this.byRoom.get(roomId);
    if (!map) return;
    for (const c of map.values()) {
      this.#send(c, { t: 'bye', reason: 'room_closed' });
      this.counters.closedByServer++;
      try { c.ws.close(CLOSE.ROOM_CLOSED, 'room_closed'); } catch { /* ignorar */ }
    }
  }

  #beat() {
    for (const c of this.conns) {
      c.bad = Math.max(0, c.bad - 5);
      if (!c.alive) { c.ws.terminate(); continue; }
      c.alive = false;
      try { c.ws.ping(); } catch { /* ignorar */ }
    }
  }

  stats() {
    return {
      connections: this.conns.size,
      rooms: this.byRoom.size,
      pendingTickets: this.tickets.size,
      ...this.counters,
      lastErrors: this.lastErrors.slice(-10),
    };
  }

  shutdown() {
    clearInterval(this.heartbeat);
    for (const c of this.conns) {
      try { c.ws.close(1001, 'server_shutdown'); } catch { /* ignorar */ }
    }
    this.wss.close();
  }
}
