/**
 * Limitador de ventana deslizante por clave (IP, usuario...). En memoria.
 * hit() devuelve true si la acción está permitida y la cuenta.
 */
export class RateLimiter {
  constructor({ max, windowMs, now = Date.now }) {
    this.max = max;
    this.windowMs = windowMs;
    this.now = now;
    this.hits = new Map();
    this.lastSweep = now();
  }

  hit(key) {
    const t = this.now();
    this.#sweep(t);
    const arr = (this.hits.get(key) || []).filter((x) => t - x < this.windowMs);
    if (arr.length >= this.max) {
      this.hits.set(key, arr);
      return false;
    }
    arr.push(t);
    this.hits.set(key, arr);
    return true;
  }

  retryAfterSec(key) {
    const arr = this.hits.get(key);
    if (!arr?.length) return 1;
    return Math.max(1, Math.ceil((arr[0] + this.windowMs - this.now()) / 1000));
  }

  #sweep(t) {
    if (t - this.lastSweep < this.windowMs) return;
    this.lastSweep = t;
    for (const [k, arr] of this.hits) {
      if (!arr.length || t - arr[arr.length - 1] >= this.windowMs) this.hits.delete(k);
    }
  }
}

/** Cubeta de tokens para un flujo continuo (mensajes WebSocket). */
export class TokenBucket {
  constructor(ratePerSec, burst, now = Date.now) {
    this.rate = ratePerSec;
    this.burst = burst;
    this.now = now;
    this.tokens = burst;
    this.last = now();
  }

  take() {
    const t = this.now();
    this.tokens = Math.min(this.burst, this.tokens + ((t - this.last) / 1000) * this.rate);
    this.last = t;
    if (this.tokens < 1) return false;
    this.tokens -= 1;
    return true;
  }
}
