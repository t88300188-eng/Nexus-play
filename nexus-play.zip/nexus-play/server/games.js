import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { UserError } from './errors.js';
import { cleanText, randId, mb, safeEqual } from './util.js';
import { extractZip, extOf, mimeFor } from './zipsafe.js';
import { analyzeProject, injectScripts } from './analyzer.js';

const THUMB_MAX = 512 * 1024;

function sniffImage(buf) {
  if (buf.length > 12 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'png';
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length > 12 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return 'webp';
  return null;
}

/** Guarda el cuerpo de la petición en un archivo temporal, contando bytes y calculando SHA-256. */
export async function receiveUpload(req, tmpDir, maxBytes, tooBigMessage) {
  const file = path.join(tmpDir, randId('up_', 8));
  const hash = crypto.createHash('sha256');
  let n = 0;
  const counter = new Transform({
    transform(chunk, _enc, cb) {
      n += chunk.length;
      if (n > maxBytes) { cb(new UserError(tooBigMessage, 413, 'too_big')); return; }
      hash.update(chunk);
      cb(null, chunk);
    },
  });
  try {
    await pipeline(req, counter, fs.createWriteStream(file, { mode: 0o600 }));
  } catch (e) {
    fs.rmSync(file, { force: true });
    if (e instanceof UserError) throw e;
    throw new UserError('La subida se interrumpió. Inténtalo de nuevo.', 400, 'upload_aborted');
  }
  if (n === 0) {
    fs.rmSync(file, { force: true });
    throw new UserError('No se recibió ningún archivo.', 400, 'empty_upload');
  }
  return { file, size: n, sha256: hash.digest('hex') };
}

export class GameService {
  constructor({ store, config, log, auth }) {
    this.store = store;
    this.cfg = config;
    this.log = log;
    this.auth = auth;
    this.gamesDir = path.join(config.dataDir, 'games');
    this.tmpDir = path.join(config.dataDir, 'tmp');
    fs.mkdirSync(this.gamesDir, { recursive: true });
    fs.rmSync(this.tmpDir, { recursive: true, force: true });
    fs.mkdirSync(this.tmpDir, { recursive: true });
    this.secret = this.#loadSecret();
    this.roomGuard = { hasActiveRoom: () => false };
    this.sdkDir = path.join(config.rootDir, 'public', 'sdk');
    this.errors = [];            // últimos errores de carga/publicación (para diagnóstico)
    this.diskCache = { at: 0, bytes: 0 };
    this.limits = {
      maxZipFiles: config.maxZipFiles, maxDepth: config.maxZipDepth,
      maxUnzippedBytes: config.maxUnzippedBytes, maxFileBytes: config.maxFileBytes,
    };
  }

  get games() { return this.store.data.games; }

  #loadSecret() {
    const f = path.join(this.cfg.dataDir, '.secret');
    try {
      const s = fs.readFileSync(f, 'utf8').trim();
      if (s.length >= 32) return s;
    } catch { /* se crea abajo */ }
    const s = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(f, s, { mode: 0o600 });
    return s;
  }

  noteError(kind, message, extra = {}) {
    this.errors.push({ ts: Date.now(), kind, message, ...extra });
    if (this.errors.length > 50) this.errors.shift();
    this.log.warn('games.error', { kind, message });
  }

  // ---------- Vistas ----------
  #ownerName(g) { return this.store.data.users[g.ownerId]?.name || 'Desconocido'; }

  versionOf(g, n = g.currentVersion) { return g.versions.find((v) => v.n === Number(n)) || null; }

  playUrl(g, v) {
    return `/g/${g.id}/${v.n}/${v.entry.split('/').map(encodeURIComponent).join('/')}`;
  }

  canSee(g, user) { return g && (g.published || g.ownerId === user.id); }

  view(g, user, { detail = false } = {}) {
    const cur = this.versionOf(g);
    const mine = g.ownerId === user.id;
    const out = {
      id: g.id, title: g.title, description: g.description, published: g.published, mine,
      ownerName: this.#ownerName(g), createdAt: g.createdAt, updatedAt: g.updatedAt,
      version: g.currentVersion, versionsCount: g.versions.length,
      kind: cur?.kind, size: cur?.size ?? 0, files: cur?.files ?? 0, entry: cur?.entry,
      integrated: !!cur?.integratedFrom,
      thumbUrl: g.thumb ? `/api/games/${g.id}/thumbnail?r=${g.thumb.rev}` : null,
      playUrl: g.published && cur ? this.playUrl(g, cur) : null,
    };
    if (detail && mine) {
      out.versions = g.versions.map((v) => ({
        n: v.n, createdAt: v.createdAt, kind: v.kind, entry: v.entry, size: v.size, files: v.files,
        sha256: v.sha256, note: v.note, integratedFrom: v.integratedFrom ?? null,
        current: v.n === g.currentVersion,
        inUse: this.roomGuard.hasActiveRoom(g.id, v.n),
      }));
    }
    return out;
  }

  list(user) {
    return Object.values(this.games)
      .filter((g) => this.canSee(g, user))
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .map((g) => this.view(g, user));
  }

  get(user, id, opts) {
    const g = this.games[id];
    if (!g || !this.canSee(g, user)) throw new UserError('Ese juego no existe.', 404, 'not_found');
    return this.view(g, user, opts);
  }

  #own(user, id) {
    const g = this.games[id];
    if (!g || !this.canSee(g, user)) throw new UserError('Ese juego no existe.', 404, 'not_found');
    if (g.ownerId !== user.id) throw new UserError('Solo el propietario puede hacer esto.', 403, 'forbidden');
    return g;
  }

  userBytes(userId) {
    let b = 0;
    for (const g of Object.values(this.games)) if (g.ownerId === userId) for (const v of g.versions) b += v.size;
    return b;
  }

  stats() {
    const all = Object.values(this.games);
    return { total: all.length, published: all.filter((g) => g.published).length };
  }

  diskBytes() {
    const now = Date.now();
    if (now - this.diskCache.at < 60_000) return this.diskCache.bytes;
    const walk = (d) => {
      let t = 0;
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) t += walk(p);
        else if (e.isFile()) t += fs.statSync(p).size;
      }
      return t;
    };
    let bytes = 0;
    try { bytes = walk(this.gamesDir); } catch { /* ignorar */ }
    this.diskCache = { at: now, bytes };
    return bytes;
  }

  // ---------- Subida ----------
  /** Valida el archivo subido y lo deja listo en una carpeta de preparación. */
  async #stage(upload, filename) {
    const ext = extOf(String(filename || ''));
    const stage = path.join(this.tmpDir, randId('stage_', 8));
    try {
      if (ext === 'zip') {
        const head = Buffer.alloc(4);
        const fd = fs.openSync(upload.file, 'r');
        try { fs.readSync(fd, head, 0, 4, 0); } finally { fs.closeSync(fd); }
        if (head.toString('latin1', 0, 2) !== 'PK') throw new UserError('El archivo no es un ZIP válido.', 400, 'zip_invalid');
        const r = await extractZip(upload.file, stage, this.limits);
        return { kind: 'zip', stage, entry: r.entry, files: r.files.length, total: r.total, skipped: r.skipped.length, sha256: upload.sha256 };
      }
      if (ext === 'html' || ext === 'htm') {
        const buf = fs.readFileSync(upload.file);
        if (buf.includes(0)) throw new UserError('El archivo parece binario, no HTML.', 400, 'html_invalid');
        const text = buf.toString('utf8');
        if (!/<\s*(!doctype|html|head|body|script|canvas|div|a-scene)\b/i.test(text)) {
          throw new UserError('El archivo no parece contener HTML.', 400, 'html_invalid');
        }
        fs.mkdirSync(stage, { recursive: true });
        fs.writeFileSync(path.join(stage, 'index.html'), buf, { mode: 0o644 });
        return { kind: 'html', stage, entry: 'index.html', files: 1, total: buf.length, skipped: 0, sha256: upload.sha256 };
      }
      throw new UserError('Solo se admiten archivos .html o .zip.', 400, 'bad_type');
    } catch (e) {
      fs.rmSync(stage, { recursive: true, force: true });
      this.noteError('upload', e.message);
      throw e;
    } finally {
      fs.rmSync(upload.file, { force: true });
    }
  }

  maxUploadBytes(filename) {
    return extOf(String(filename || '')) === 'zip' ? this.cfg.maxZipBytes : this.cfg.maxHtmlBytes;
  }

  #commit(g, user, stage, meta = {}) {
    // Todo lo de aquí es síncrono: no hay carreras entre comprobar cuota y escribir.
    try {
      if (g.versions.length >= this.cfg.maxVersionsPerGame) {
        throw new UserError(`Este juego ya tiene ${g.versions.length} versiones (máximo ${this.cfg.maxVersionsPerGame}). Elimina alguna antigua.`, 409, 'too_many_versions');
      }
      if (this.userBytes(user.id) + stage.total > this.cfg.maxUserBytes) {
        throw new UserError(`Superarías tu espacio (${mb(this.cfg.maxUserBytes)} MB). Elimina juegos o versiones antiguas.`, 413, 'quota');
      }
      const n = g.nextVersion;
      const gdir = path.join(this.gamesDir, g.id);
      fs.mkdirSync(gdir, { recursive: true });
      const dest = path.join(gdir, `v${n}`);
      if (fs.existsSync(dest)) throw new UserError('Conflicto al guardar la versión. Inténtalo de nuevo.', 409, 'conflict');
      fs.renameSync(stage.stage, dest);
      const version = {
        n, createdAt: Date.now(), kind: meta.kind || stage.kind, entry: stage.entry, size: stage.total,
        files: stage.files, sha256: stage.sha256, note: meta.note || '',
      };
      if (meta.integratedFrom) version.integratedFrom = meta.integratedFrom;
      g.versions.push(version);
      g.nextVersion = n + 1;
      g.currentVersion = n;
      g.updatedAt = Date.now();
      this.diskCache.at = 0;
      this.store.save();
      return version;
    } catch (e) {
      fs.rmSync(stage.stage, { recursive: true, force: true });
      throw e;
    }
  }

  async createGame(user, { title, description, upload, filename }) {
    try {
      title = cleanText(title, { min: 2, max: 60, field: 'El título' });
      description = cleanText(description, { max: 400, multiline: true, field: 'La descripción' });
    } catch (e) {
      fs.rmSync(upload.file, { force: true });
      this.noteError('upload', e.message);
      throw e;
    }
    const mine = Object.values(this.games).filter((g) => g.ownerId === user.id).length;
    if (mine >= this.cfg.maxGamesPerUser) {
      fs.rmSync(upload.file, { force: true });
      throw new UserError(`Alcanzaste el máximo de ${this.cfg.maxGamesPerUser} juegos.`, 409, 'too_many_games');
    }
    const stage = await this.#stage(upload, filename);
    const g = {
      id: randId('g_', 6), ownerId: user.id, title, description, published: false,
      createdAt: Date.now(), updatedAt: Date.now(), currentVersion: 0, nextVersion: 1, versions: [], thumb: null,
    };
    this.games[g.id] = g;
    try {
      this.#commit(g, user, stage, { note: 'Versión inicial' });
    } catch (e) {
      delete this.games[g.id];
      fs.rmSync(path.join(this.gamesDir, g.id), { recursive: true, force: true });
      this.noteError('upload', e.message);
      throw e;
    }
    this.log.info('game.created', { id: g.id, kind: stage.kind, files: stage.files });
    return this.view(g, user, { detail: true });
  }

  async addVersion(user, id, { upload, filename, note }) {
    let g;
    try { g = this.#own(user, id); } catch (e) { fs.rmSync(upload.file, { force: true }); throw e; }
    try { note = cleanText(note, { max: 120, field: 'La nota' }); } catch (e) { fs.rmSync(upload.file, { force: true }); throw e; }
    const stage = await this.#stage(upload, filename);
    try {
      this.#commit(g, user, stage, { note: note || 'Nueva versión' });
    } catch (e) {
      this.noteError('upload', e.message);
      throw e;
    }
    this.log.info('game.version_added', { id: g.id, version: g.currentVersion });
    return this.view(g, user, { detail: true });
  }

  update(user, id, patch) {
    const g = this.#own(user, id);
    if (patch.title !== undefined) g.title = cleanText(patch.title, { min: 2, max: 60, field: 'El título' });
    if (patch.description !== undefined) g.description = cleanText(patch.description, { max: 400, multiline: true, field: 'La descripción' });
    if (patch.published !== undefined) {
      if (typeof patch.published !== 'boolean') throw new UserError('El campo "published" debe ser verdadero o falso.');
      if (patch.published && !this.versionOf(g)) throw new UserError('El juego no tiene ninguna versión que publicar.', 409);
      g.published = patch.published;
    }
    g.updatedAt = Date.now();
    this.store.save();
    this.log.info('game.updated', { id: g.id, published: g.published });
    return this.view(g, user, { detail: true });
  }

  setCurrent(user, id, n) {
    const g = this.#own(user, id);
    const v = this.versionOf(g, n);
    if (!v) throw new UserError('Esa versión no existe.', 404, 'not_found');
    g.currentVersion = v.n;
    g.updatedAt = Date.now();
    this.store.save();
    return this.view(g, user, { detail: true });
  }

  deleteVersion(user, id, n) {
    const g = this.#own(user, id);
    const v = this.versionOf(g, n);
    if (!v) throw new UserError('Esa versión no existe.', 404, 'not_found');
    if (v.n === g.currentVersion) throw new UserError('No puedes eliminar la versión actual. Elige otra como actual primero.', 409, 'current_version');
    if (this.roomGuard.hasActiveRoom(g.id, v.n)) throw new UserError('Hay una sala activa usando esa versión.', 409, 'in_use');
    g.versions = g.versions.filter((x) => x.n !== v.n);
    this.#rmDir(path.join(this.gamesDir, g.id, `v${v.n}`));
    g.updatedAt = Date.now();
    this.diskCache.at = 0;
    this.store.save();
    return this.view(g, user, { detail: true });
  }

  deleteGame(user, id) {
    const g = this.#own(user, id);
    if (this.roomGuard.hasActiveRoom(g.id)) {
      throw new UserError('Hay salas activas con este juego. Ciérralas antes de eliminarlo.', 409, 'in_use');
    }
    delete this.games[g.id];
    for (const [rid, r] of Object.entries(this.store.data.rooms)) if (r.gameId === g.id) delete this.store.data.rooms[rid];
    this.#rmDir(path.join(this.gamesDir, g.id));
    this.diskCache.at = 0;
    this.store.save();
    this.log.info('game.deleted', { id: g.id });
  }

  #rmDir(dir) {
    const root = path.resolve(this.gamesDir) + path.sep;
    const abs = path.resolve(dir);
    if (!abs.startsWith(root)) throw new Error('ruta fuera del almacenamiento');
    fs.rmSync(abs, { recursive: true, force: true });
  }

  // ---------- Miniatura ----------
  async setThumbnail(user, id, upload) {
    let g;
    try {
      g = this.#own(user, id);
      const buf = fs.readFileSync(upload.file);
      const type = sniffImage(buf);
      if (!type) throw new UserError('La miniatura debe ser PNG, JPG o WebP.', 400, 'bad_image');
      const gdir = path.join(this.gamesDir, g.id);
      fs.mkdirSync(gdir, { recursive: true });
      for (const old of fs.readdirSync(gdir).filter((x) => x.startsWith('thumb.'))) fs.rmSync(path.join(gdir, old), { force: true });
      fs.writeFileSync(path.join(gdir, `thumb.${type}`), buf, { mode: 0o644 });
      g.thumb = { ext: type, rev: Date.now() };
      g.updatedAt = Date.now();
      this.store.save();
      return this.view(g, user, { detail: true });
    } finally {
      fs.rmSync(upload.file, { force: true });
    }
  }

  removeThumbnail(user, id) {
    const g = this.#own(user, id);
    if (g.thumb) {
      fs.rmSync(path.join(this.gamesDir, g.id, `thumb.${g.thumb.ext}`), { force: true });
      g.thumb = null;
      this.store.save();
    }
    return this.view(g, user, { detail: true });
  }

  thumbnail(id) {
    const g = this.games[id];
    if (!g?.thumb) return null;
    const abs = path.join(this.gamesDir, g.id, `thumb.${g.thumb.ext}`);
    return fs.existsSync(abs) ? { abs, type: g.thumb.ext === 'jpg' ? 'image/jpeg' : `image/${g.thumb.ext}` } : null;
  }

  get thumbMax() { return THUMB_MAX; }

  // ---------- Servir archivos de juegos ----------
  #sign(payload) {
    return crypto.createHmac('sha256', this.secret).update(payload).digest('base64url');
  }

  previewToken(user, id, n) {
    const g = this.#own(user, id);
    const v = this.versionOf(g, n ?? g.currentVersion);
    if (!v) throw new UserError('Esa versión no existe.', 404, 'not_found');
    const exp = Date.now() + 2 * 3600_000;
    const payload = `${g.id}.${v.n}.${exp}`;
    return { token: `${payload}.${this.#sign(payload)}`, entry: v.entry.split('/').map(encodeURIComponent).join('/') };
  }

  /** Resuelve una petición pública /g/:gid/:ver/... a un archivo real (o null). */
  resolvePublic(gid, ver, rel) {
    const g = this.games[gid];
    if (!g) return null;
    const v = this.versionOf(g, ver);
    if (!v) return null;
    if (!g.published && !this.roomGuard.hasActiveRoom(g.id, v.n)) return null;
    return this.#file(g, v, rel);
  }

  /** Resuelve /gp/:token/... (vista previa del propietario). */
  resolvePreview(token, rel) {
    const parts = String(token).split('.');
    if (parts.length !== 4) return null;
    const [gid, ver, exp, sig] = parts;
    if (!safeEqual(this.#sign(`${gid}.${ver}.${exp}`), sig)) return null;
    if (Number(exp) < Date.now()) return null;
    const g = this.games[gid];
    const v = g && this.versionOf(g, ver);
    return v ? this.#file(g, v, rel) : null;
  }

  #file(g, v, rel) {
    if (!rel || rel.includes('\0') || rel.includes('\\')) return null;
    const segs = rel.split('/');
    if (segs.some((s) => s === '' || s === '.' || s === '..' || s.startsWith('.'))) return null;
    const root = path.resolve(this.gamesDir, g.id, `v${v.n}`);
    const abs = path.resolve(root, rel);
    if (!abs.startsWith(root + path.sep)) return null;
    try {
      const st = fs.lstatSync(abs);
      if (!st.isFile()) return null;
      return { abs, size: st.size, type: mimeFor(rel) };
    } catch { return null; }
  }

  // ---------- Asistente de integración ----------
  analysis(user, id, n) {
    const g = this.#own(user, id);
    const v = this.versionOf(g, n ?? g.currentVersion);
    if (!v) throw new UserError('Esa versión no existe.', 404, 'not_found');
    const dir = path.join(this.gamesDir, g.id, `v${v.n}`);
    const a = analyzeProject(dir, v.entry);
    let patchPreview = null;
    if (a.changes.some((c) => c.id === 'inject-sdk')) {
      const html = fs.readFileSync(path.join(dir, v.entry), 'utf8');
      const r = injectScripts(html, ['nexus-sdk.js', 'nexus-hud.js']);
      patchPreview = { file: v.entry, where: r.where, tags: r.tags, before: r.preview.before, after: r.preview.after };
    }
    return { version: v.n, ...a, patchPreview };
  }

  /** Crea una NUEVA versión con el SDK añadido. La versión original no se toca. */
  integrate(user, id, { version, accept }) {
    const g = this.#own(user, id);
    const v = this.versionOf(g, version ?? g.currentVersion);
    if (!v) throw new UserError('Esa versión no existe.', 404, 'not_found');
    const accepted = new Set(Array.isArray(accept) ? accept : []);
    if (!accepted.has('inject-sdk')) throw new UserError('Debes aceptar al menos "Añadir el SDK" para integrar.', 400, 'nothing_to_apply');
    const src = path.join(this.gamesDir, g.id, `v${v.n}`);
    const a = analyzeProject(src, v.entry);
    if (a.alreadyIntegrated) throw new UserError('Este proyecto ya contiene el SDK.', 409, 'already_integrated');
    if (!a.changes.some((c) => c.id === 'inject-sdk')) throw new UserError('No puedo integrar automáticamente este proyecto.', 409, 'cannot_integrate');
    const stage = path.join(this.tmpDir, randId('stage_', 8));
    try {
      fs.cpSync(src, stage, { recursive: true, errorOnExist: true, verbatimSymlinks: true });
      const scripts = ['nexus-sdk.js'];
      fs.copyFileSync(path.join(this.sdkDir, 'nexus-sdk.js'), path.join(stage, 'nexus-sdk.js'));
      if (accepted.has('inject-hud')) {
        fs.copyFileSync(path.join(this.sdkDir, 'nexus-hud.js'), path.join(stage, 'nexus-hud.js'));
        scripts.push('nexus-hud.js');
      }
      const entryAbs = path.join(stage, v.entry);
      const r = injectScripts(fs.readFileSync(entryAbs, 'utf8'), scripts);
      fs.writeFileSync(entryAbs, r.html);
      const files = [];
      let total = 0;
      const walk = (d, base = '') => {
        for (const e of fs.readdirSync(path.join(d, base), { withFileTypes: true })) {
          const rel = base ? `${base}/${e.name}` : e.name;
          if (e.isDirectory()) walk(d, rel);
          else { files.push(rel); total += fs.statSync(path.join(d, rel)).size; }
        }
      };
      walk(stage);
      const sha = crypto.createHash('sha256').update(r.html).digest('hex');
      this.#commit(g, user, { stage, kind: 'integrated', entry: v.entry, files: files.length, total, sha256: sha },
        { kind: 'integrated', note: `Integración NEXUS SDK (a partir de v${v.n})`, integratedFrom: v.n });
    } catch (e) {
      fs.rmSync(stage, { recursive: true, force: true });
      this.noteError('integrate', e.message);
      throw e;
    }
    this.log.info('game.integrated', { id: g.id, from: v.n, to: g.currentVersion });
    return this.view(g, user, { detail: true });
  }

  // ---------- Juego de demostración ----------
  seedDemo() {
    if (Object.keys(this.games).length) return null;
    const src = path.join(this.cfg.rootDir, 'examples', 'demo-cuadrados');
    if (!fs.existsSync(path.join(src, 'index.html'))) return null;
    const owner = this.auth.ensureSystemUser('NEXUS PLAY');
    const stage = path.join(this.tmpDir, randId('stage_', 8));
    fs.cpSync(src, stage, { recursive: true });
    fs.copyFileSync(path.join(this.sdkDir, 'nexus-sdk.js'), path.join(stage, 'nexus-sdk.js'));
    const files = fs.readdirSync(stage);
    let total = 0;
    for (const f of files) total += fs.statSync(path.join(stage, f)).size;
    const g = {
      id: randId('g_', 6), ownerId: owner.id, title: 'Cuadrados (demo multijugador)',
      description: 'Demo oficial: mueve tu cuadrado y mira cómo se mueven los de los demás en tiempo real. Usa el SDK de NEXUS PLAY.',
      published: true, createdAt: Date.now(), updatedAt: Date.now(), currentVersion: 0, nextVersion: 1, versions: [], thumb: null,
    };
    this.games[g.id] = g;
    this.#commit(g, owner, { stage, kind: 'zip', entry: 'index.html', files: files.length, total, sha256: 'demo' }, { note: 'Demo incluida' });
    this.log.info('game.demo_seeded', { id: g.id });
    return g;
  }
}
