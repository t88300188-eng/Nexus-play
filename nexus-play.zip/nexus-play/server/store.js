import fs from 'node:fs';
import path from 'node:path';

const SHAPE = () => ({ meta: { schema: 1, createdAt: Date.now() }, users: {}, games: {}, rooms: {} });

function validShape(d) {
  return d && typeof d === 'object' && d.users && d.games && d.rooms
    && typeof d.users === 'object' && typeof d.games === 'object' && typeof d.rooms === 'object';
}

/**
 * Base de datos de metadatos en un archivo JSON con escritura atómica:
 *   db.json.tmp -> fsync -> db.json (y copia previa en db.json.bak).
 * Los archivos de los juegos NO viven aquí: están en data/games/.
 */
export class Store {
  constructor({ dir, log, debounceMs = 150 }) {
    this.dir = dir;
    this.log = log;
    this.debounceMs = debounceMs;
    this.file = path.join(dir, 'db.json');
    this.bak = path.join(dir, 'db.json.bak');
    this.timer = null;
    this.dirty = false;
    this.lastSaveAt = null;
    this.lastError = null;
    this.saves = 0;
    this.recovered = null;
    fs.mkdirSync(dir, { recursive: true });
    this.data = this.#load();
  }

  #read(file) {
    const raw = fs.readFileSync(file, 'utf8');
    const d = JSON.parse(raw);
    if (!validShape(d)) throw new Error('estructura inesperada');
    return d;
  }

  #load() {
    if (!fs.existsSync(this.file) && !fs.existsSync(this.bak)) return SHAPE();
    try {
      return this.#read(this.file);
    } catch (e) {
      this.log.error('store.corrupt', { file: 'db.json', reason: e.message });
    }
    // db.json dañado o ausente: se conserva como evidencia y se intenta la copia previa.
    try {
      if (fs.existsSync(this.file)) {
        fs.renameSync(this.file, path.join(this.dir, `db.corrupt-${Date.now()}.json`));
      }
    } catch { /* no crítico */ }
    try {
      const d = this.#read(this.bak);
      this.recovered = 'bak';
      this.log.warn('store.recovered', { from: 'db.json.bak' });
      return d;
    } catch (e) {
      this.log.error('store.unrecoverable', { reason: e.message });
      this.recovered = 'empty';
      return SHAPE();
    }
  }

  save() {
    this.dirty = true;
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.flush();
    }, this.debounceMs);
    this.timer.unref?.();
  }

  flush() {
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    if (!this.dirty) return true;
    const tmp = this.file + '.tmp';
    try {
      const json = JSON.stringify(this.data);
      const fd = fs.openSync(tmp, 'w', 0o600);
      try {
        fs.writeSync(fd, json);
        fs.fsyncSync(fd);
      } finally {
        fs.closeSync(fd);
      }
      if (fs.existsSync(this.file)) fs.copyFileSync(this.file, this.bak);
      fs.renameSync(tmp, this.file);
      this.dirty = false;
      this.lastSaveAt = Date.now();
      this.lastError = null;
      this.saves++;
      return true;
    } catch (e) {
      this.lastError = { at: Date.now(), message: e.message };
      this.log.error('store.save_failed', { message: e.message });
      return false;
    }
  }

  close() {
    return this.flush();
  }

  status() {
    let bytes = 0;
    try { bytes = fs.statSync(this.file).size; } catch { /* aún no existe */ }
    return {
      ok: !this.lastError,
      lastSaveAt: this.lastSaveAt,
      lastError: this.lastError,
      pendingWrite: this.dirty,
      saves: this.saves,
      dbBytes: bytes,
      recoveredFrom: this.recovered,
    };
  }
}
