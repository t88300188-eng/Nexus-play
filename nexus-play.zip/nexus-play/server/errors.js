// Error "esperado": se muestra al usuario tal cual (mensaje en español) con su código HTTP.
export class UserError extends Error {
  constructor(message, status = 400, code = 'bad_request') {
    super(message);
    this.name = 'UserError';
    this.status = status;
    this.code = code;
  }
}
