import fs from 'node:fs';
import path from 'node:path';
import { extOf } from './zipsafe.js';

const MAX_SCAN_BYTES = 3 * 1048576;     // total de texto que se analiza
const MAX_FILE_SCAN = 1.5 * 1048576;    // por archivo

const LIBS = [
  ['Three.js', /\bTHREE\.|three(\.module)?(\.min)?\.js/],
  ['Phaser', /\bPhaser\.(Game|Scene)|phaser(\.min)?\.js/],
  ['PixiJS', /\bPIXI\.|pixi(\.min)?\.js/],
  ['Babylon.js', /\bBABYLON\.|babylon(\.min)?\.js/],
  ['p5.js', /\bcreateCanvas\s*\(|p5(\.min)?\.js/],
  ['Kaboom/Kaplay', /\bkaboom\s*\(|\bkaplay\s*\(/],
  ['Matter.js', /\bMatter\.(Engine|Bodies)/],
  ['Cannon.js', /\bCANNON\./],
  ['Howler', /\bnew Howl\s*\(|howler(\.min)?\.js/],
  ['A-Frame', /<a-scene|aframe(\.min)?\.js/],
  ['Socket.IO', /\bio\s*\(\s*['"`]|socket\.io/],
  ['Godot (export web)', /Godot|\.pck\b/],
  ['Unity WebGL', /UnityLoader|createUnityInstance/],
];

const STATE_NAMES = /\b(player|players|jugador|jugadores|hero|heroe|ship|nave|me|enemies|enemigos|bullets|balas|score|puntos|puntaje|lives|vidas|health|hp|level|nivel|gameState|estado|turn|turno|board|tablero)\b/gi;

function read(file) {
  try {
    const st = fs.statSync(file);
    if (st.size > MAX_FILE_SCAN) return null;
    return fs.readFileSync(file, 'utf8');
  } catch { return null; }
}

function listFiles(dir, base = '') {
  const out = [];
  for (const d of fs.readdirSync(path.join(dir, base), { withFileTypes: true })) {
    const rel = base ? `${base}/${d.name}` : d.name;
    if (d.isDirectory()) out.push(...listFiles(dir, rel));
    else if (d.isFile()) out.push({ path: rel, size: fs.statSync(path.join(dir, rel)).size });
  }
  return out;
}

function lineOf(text, index) {
  return text.slice(0, index).split('\n').length;
}

/**
 * Análisis HEURÍSTICO de un proyecto ya guardado. No ejecuta nada del juego:
 * solo lee texto. Un resultado "compatible" significa "probablemente integrable",
 * no una garantía.
 */
export function analyzeProject(dir, entry) {
  const files = listFiles(dir);
  const byType = {};
  let totalSize = 0;
  for (const f of files) {
    const e = extOf(f.path) || 'otros';
    byType[e] = (byType[e] || 0) + 1;
    totalSize += f.size;
  }

  const texts = [];
  let scanned = 0;
  const textFiles = files.filter((f) => ['html', 'htm', 'js', 'mjs'].includes(extOf(f.path)));
  textFiles.sort((a, b) => (a.path === entry ? -1 : b.path === entry ? 1 : a.size - b.size));
  for (const f of textFiles) {
    if (scanned >= MAX_SCAN_BYTES) break;
    const t = read(path.join(dir, f.path));
    if (t === null) continue;
    scanned += t.length;
    texts.push({ path: f.path, text: t });
  }
  const html = texts.find((t) => t.path === entry)?.text ?? '';
  const all = texts.map((t) => t.text).join('\n');

  const findings = [];     // cosas detectadas
  const warnings = [];     // cosas que pueden romper el juego dentro de NEXUS PLAY
  const changes = [];      // qué habría que modificar
  const syncCandidates = []; // posibles puntos de sincronización

  // --- Ya integrado
  const alreadyIntegrated = /NexusPlay\b/.test(all) || files.some((f) => /nexus-sdk(\.[\w-]+)?\.js$/i.test(f.path));

  // --- Dependencias externas
  const externals = new Set();
  for (const m of all.matchAll(/(?:src|href)\s*=\s*["'](https?:)?\/\/([^"'\s>]+)/gi)) externals.add((m[1] || 'https:') + '//' + m[2].split(/[?#]/)[0]);
  for (const m of all.matchAll(/@import\s+(?:url\()?["']?(https?:\/\/[^"')\s;]+)/gi)) externals.add(m[1]);
  for (const m of all.matchAll(/\bimport\s*(?:[^'"]*from\s*)?["'](https?:\/\/[^"']+)/g)) externals.add(m[1]);
  const externalList = [...externals].slice(0, 20);
  if (externalList.length) {
    warnings.push({
      id: 'external-deps',
      text: `Usa ${externalList.length} recurso(s) externo(s) (CDN). Necesitan internet en todos los dispositivos; para jugar sin conexión (red local) descárgalos y súbelos dentro del proyecto.`,
    });
  }

  // --- Librerías
  const libs = LIBS.filter(([, re]) => re.test(all)).map(([n]) => n);
  if (libs.includes('Socket.IO')) {
    warnings.push({ id: 'socketio', text: 'Ya tiene lógica de red con Socket.IO. Necesitaría su propio servidor; NEXUS PLAY no lo ejecuta. Lo habitual es reemplazar esas llamadas por el SDK.' });
  }
  if (libs.includes('Unity WebGL') || libs.includes('Godot (export web)')) {
    warnings.push({ id: 'engine', text: 'Es una exportación de un motor (Unity/Godot). Se puede alojar, pero integrar multijugador requiere puentes específicos del motor; este asistente no los genera.' });
  }

  // --- Patrones del juego
  const usesCanvas = /getContext\s*\(\s*['"](2d|webgl2?|experimental-webgl)['"]/.test(all) || /<canvas\b/i.test(html);
  const usesRAF = /requestAnimationFrame\s*\(/.test(all);
  const usesInterval = /setInterval\s*\(/.test(all);
  const inputs = [];
  if (/addEventListener\s*\(\s*['"]key(down|up)['"]|onkey(down|up)\s*=/.test(all)) inputs.push('teclado');
  if (/addEventListener\s*\(\s*['"](pointer\w+|mouse\w+|click)['"]|onmouse\w+\s*=|onclick\s*=/.test(all)) inputs.push('ratón/puntero');
  if (/addEventListener\s*\(\s*['"]touch\w+['"]|ontouch\w+\s*=/.test(all)) inputs.push('táctil');
  if (/getGamepads\s*\(/.test(all)) inputs.push('mando');
  const hasTouch = inputs.includes('táctil') || /pointer/.test(inputs.join()) || all.includes('pointerdown');
  if (usesCanvas && !hasTouch) {
    warnings.push({ id: 'touch', text: 'No detecté controles táctiles. En Android el juego podría no poder jugarse sin teclado.' });
  }

  // --- Limitaciones del aislamiento (sandbox sin allow-same-origin)
  const sandbox = [];
  if (/\blocalStorage\b|\bsessionStorage\b/.test(all)) {
    sandbox.push('Usa localStorage/sessionStorage: dentro de NEXUS PLAY está bloqueado (el juego corre aislado). Si no lo envuelve en try/catch puede fallar al iniciar.');
  }
  if (/\bindexedDB\b/.test(all)) sandbox.push('Usa IndexedDB: está bloqueado en el aislamiento. Guarda el progreso con el servidor o en memoria.');
  if (/document\.cookie/.test(all)) sandbox.push('Usa cookies: no están disponibles dentro del aislamiento.');
  if (/\b(window\.)?(top|parent)\.(location|document)/.test(all)) sandbox.push('Accede a window.top/parent: está bloqueado por el aislamiento.');
  if (/\bwindow\.open\s*\(/.test(all)) sandbox.push('Abre ventanas nuevas: los pop-ups están bloqueados.');
  if (/navigator\.(serviceWorker|mediaDevices|geolocation|clipboard)/.test(all)) sandbox.push('Usa APIs del navegador (service worker, cámara/micrófono, ubicación o portapapeles) que pueden estar restringidas dentro del aislamiento.');
  if (/\b(eval\s*\(|new Function\s*\()/.test(all)) sandbox.push('Usa eval/new Function: funciona, pero es una mala práctica y dificulta el análisis.');
  const netCalls = [...all.matchAll(/\b(fetch\s*\(|new XMLHttpRequest|new WebSocket\s*\(|new EventSource\s*\()/g)].length;
  if (netCalls) findings.push(`Hace ${netCalls} llamada(s) de red (fetch/XHR/WebSocket). Las que apunten a rutas relativas del propio proyecto funcionan; las demás dependen de CORS.`);
  for (const s of sandbox) warnings.push({ id: 'sandbox', text: s });

  // --- Candidatos de sincronización (heurística por nombres)
  const counts = new Map();
  for (const t of texts) {
    for (const m of t.text.matchAll(STATE_NAMES)) {
      const k = m[0].toLowerCase();
      counts.set(k, (counts.get(k) || 0) + 1);
    }
  }
  const names = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  for (const t of texts) {
    if (syncCandidates.length >= 6) break;
    const re = /\b(?:let|var|const)\s+(player|jugador|hero|heroe|ship|nave|me)\w*\s*=\s*\{/gi;
    for (const m of t.text.matchAll(re)) {
      syncCandidates.push({
        kind: 'jugador',
        file: t.path,
        line: lineOf(t.text, m.index),
        name: m[0].replace(/\s*=\s*\{$/, '').replace(/^(let|var|const)\s+/, ''),
        hint: 'Objeto que parece representar al jugador local. Sus campos (posición, vida, puntos) son los candidatos a enviar con nexus.setState(...).',
      });
      if (syncCandidates.length >= 6) break;
    }
  }
  const loops = [];
  if (usesRAF) loops.push('requestAnimationFrame');
  if (usesInterval) loops.push('setInterval');
  if (loops.length) {
    syncCandidates.push({ kind: 'bucle', file: entry, line: null, name: loops.join(' / '), hint: 'Bucle principal del juego. Es el sitio natural para publicar tu estado cada 50–100 ms y para dibujar a los demás jugadores.' });
  }

  // --- Funciones ya hechas
  if (usesCanvas) findings.push('Dibuja en <canvas>.');
  if (loops.length) findings.push(`Bucle de juego con ${loops.join(' y ')}.`);
  if (inputs.length) findings.push(`Entradas detectadas: ${inputs.join(', ')}.`);
  if (libs.length) findings.push(`Librerías/motores detectados: ${libs.join(', ')}.`);
  if (names.length) findings.push(`Nombres de estado frecuentes: ${names.map(([n, c]) => `${n} (${c})`).join(', ')}.`);
  if (/\bdocument\.write\s*\(/.test(all)) warnings.push({ id: 'docwrite', text: 'Usa document.write: la inserción automática del SDK podría no funcionar bien.' });

  // --- Cambios propuestos
  const hasHead = /<\/head>/i.test(html);
  const hasBody = /<body[^>]*>/i.test(html);
  const canInject = !alreadyIntegrated && /\.html?$/i.test(entry) && html.length > 0;
  if (canInject) {
    changes.push({
      id: 'inject-sdk',
      auto: true,
      title: 'Añadir el SDK de NEXUS PLAY',
      detail: `Copia nexus-sdk.js al proyecto y lo carga en ${entry}${hasHead ? ' (antes de </head>)' : hasBody ? ' (al empezar <body>)' : ' (al inicio del archivo)'}. No altera tu lógica.`,
      file: entry,
    });
    changes.push({
      id: 'inject-hud',
      auto: true,
      title: 'Añadir un indicador de sala (jugadores y conexión)',
      detail: 'Carga nexus-hud.js: una pequeña barra superpuesta con los jugadores conectados y el estado de la conexión. Es opcional y se puede quitar borrando una línea.',
      file: entry,
    });
  }
  const manual = [];
  if (!alreadyIntegrated) {
    manual.push({
      id: 'sync-state',
      title: 'Sincronizar el estado de cada jugador (a mano)',
      detail: 'Este paso depende de cómo esté programado tu juego y no se puede hacer automáticamente. Ejemplo:',
      code: [
        'const nexus = await NexusPlay.connect();',
        '// En tu bucle principal (cada ~80 ms):',
        'nexus.setState({ x: player.x, y: player.y });',
        '// Para dibujar a los demás:',
        'nexus.on("state", (id, s) => { remotos[id] = s; });',
        'nexus.on("player:leave", (p) => delete remotos[p.id]);',
      ].join('\n'),
    });
    manual.push({
      id: 'sync-events',
      title: 'Enviar eventos puntuales (disparos, chat, turnos)',
      detail: 'Usa eventos para acciones discretas:',
      code: ['nexus.send("disparo", { x, y, dir });', 'nexus.on("event", (name, data, from) => { /* reaccionar */ });'].join('\n'),
    });
  }

  // --- Veredicto honesto
  let level;
  let summary;
  if (alreadyIntegrated) {
    level = 'integrado';
    summary = 'Este proyecto ya usa el SDK de NEXUS PLAY.';
  } else if (libs.includes('Unity WebGL') || libs.includes('Godot (export web)')) {
    level = 'dificil';
    summary = 'Se puede alojar, pero el multijugador requiere trabajo específico del motor.';
  } else if (usesCanvas && (loops.length || syncCandidates.length)) {
    level = 'posible';
    summary = 'Parece un juego de tiempo real. La integración básica (SDK + indicador de sala) es automática; sincronizar posiciones y eventos requiere editar tu código.';
  } else if (!usesCanvas && !loops.length && !inputs.length) {
    level = 'incierto';
    summary = 'No detecté un bucle de juego ni entradas claras. Puede ser una página estática o un juego por turnos; revisa los puntos manuales.';
  } else {
    level = 'posible';
    summary = 'Hay indicios de un juego interactivo. La integración automática solo añade el SDK; la sincronización depende de tu lógica.';
  }

  return {
    entry,
    level,
    summary,
    heuristic: true,
    files: { count: files.length, totalSize, byType },
    scannedBytes: scanned,
    libraries: libs,
    externals: externalList,
    inputs,
    findings,
    warnings,
    syncCandidates,
    changes,
    manual,
    alreadyIntegrated,
    note: 'Análisis automático basado en patrones de texto. Puede equivocarse y no entiende juegos ofuscados o muy modificados.',
  };
}

/** Inserta las etiquetas <script> en el HTML de entrada. Devuelve {html, before, after}. */
export function injectScripts(html, scripts) {
  const tags = scripts.map((s) => `<script src="${s}"></script>`).join('\n');
  let idx = html.search(/<\/head>/i);
  let where = 'antes de </head>';
  if (idx < 0) {
    const m = html.match(/<body[^>]*>/i);
    if (m) { idx = m.index + m[0].length; where = 'después de <body>'; }
  }
  if (idx < 0) { idx = 0; where = 'al inicio del archivo'; }
  const out = html.slice(0, idx) + '\n' + tags + '\n' + html.slice(idx);
  const ctx = (s, i, n) => s.slice(Math.max(0, i - 80), i + n).split('\n');
  return {
    html: out,
    where,
    preview: { before: ctx(html, idx, 60), after: ctx(out, idx, tags.length + 60) },
    tags,
  };
}
