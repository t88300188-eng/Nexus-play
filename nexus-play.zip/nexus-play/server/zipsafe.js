import fs from 'node:fs';
import path from 'node:path';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import yauzl from 'yauzl';
import { UserError } from './errors.js';
import { mb } from './util.js';

// Extensiones permitidas dentro de un proyecto. Todo lo demás (.exe, .php, .sh, .zip...) se rechaza.
export const ALLOWED_EXT = new Set([
  'html', 'htm', 'css', 'js', 'mjs', 'json', 'map', 'txt', 'md', 'xml', 'csv', 'tsv', 'webmanifest',
  'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico', 'bmp', 'svg',
  'mp3', 'ogg', 'oga', 'wav', 'm4a', 'aac', 'flac', 'opus', 'webm', 'mp4', 'ogv', 'vtt', 'srt',
  'woff', 'woff2', 'ttf', 'otf',
  'glb', 'gltf', 'bin', 'obj', 'mtl', 'fbx', 'stl', 'dae', 'hdr', 'ktx2', 'basis', 'wasm',
  'atlas', 'fnt', 'tmx', 'tsx',
]);

export const MIME = {
  html: 'text/html; charset=utf-8', htm: 'text/html; charset=utf-8',
  css: 'text/css; charset=utf-8', js: 'text/javascript; charset=utf-8', mjs: 'text/javascript; charset=utf-8',
  json: 'application/json; charset=utf-8', map: 'application/json; charset=utf-8',
  txt: 'text/plain; charset=utf-8', md: 'text/plain; charset=utf-8', csv: 'text/csv; charset=utf-8',
  tsv: 'text/tab-separated-values; charset=utf-8', xml: 'application/xml; charset=utf-8',
  webmanifest: 'application/manifest+json',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp',
  avif: 'image/avif', ico: 'image/x-icon', bmp: 'image/bmp', svg: 'image/svg+xml',
  mp3: 'audio/mpeg', ogg: 'audio/ogg', oga: 'audio/ogg', wav: 'audio/wav', m4a: 'audio/mp4',
  aac: 'audio/aac', flac: 'audio/flac', opus: 'audio/ogg', webm: 'video/webm', mp4: 'video/mp4',
  ogv: 'video/ogg', vtt: 'text/vtt; charset=utf-8', srt: 'text/plain; charset=utf-8',
  woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf',
  glb: 'model/gltf-binary', gltf: 'model/gltf+json', wasm: 'application/wasm',
};
export const mimeFor = (name) => MIME[extOf(name)] || 'application/octet-stream';

export const extOf = (name) => {
  const i = name.lastIndexOf('.');
  return i < 0 ? '' : name.slice(i + 1).toLowerCase();
};

const IGNORED = (seg) => seg === '__MACOSX' || seg === '.DS_Store' || seg === 'Thumbs.db' || seg === 'desktop.ini';

/**
 * Normaliza un nombre de entrada de ZIP. Lanza UserError si es peligroso.
 * Devuelve null si debe ignorarse (carpetas, basura del sistema, archivos ocultos).
 */
export function cleanEntryName(raw, { maxDepth }) {
  if (typeof raw !== 'string' || !raw) throw new UserError('El ZIP contiene una entrada sin nombre.');
  if (raw.length > 300) throw new UserError('El ZIP contiene un nombre de archivo demasiado largo.');
  if (/[\u0000-\u001f\u007f]/.test(raw)) throw new UserError('El ZIP contiene nombres con caracteres no permitidos.');
  if (raw.includes('\\')) throw new UserError(`Ruta no permitida en el ZIP: "${raw.slice(0, 80)}" (usa "/" y no "\\").`);
  if (raw.startsWith('/') || /^[a-zA-Z]:/.test(raw)) throw new UserError(`Ruta absoluta no permitida en el ZIP: "${raw.slice(0, 80)}".`);
  if (raw.endsWith('/')) return null; // carpeta
  const segs = raw.split('/');
  if (segs.some((s) => s === '..' || s === '.' || s === '')) {
    throw new UserError(`Ruta peligrosa en el ZIP: "${raw.slice(0, 80)}".`);
  }
  if (segs.some(IGNORED)) return null;
  if (segs.some((s) => s.startsWith('.'))) return null; // archivos ocultos (.git, .env...) se omiten
  if (segs.length > maxDepth) throw new UserError(`El ZIP tiene carpetas demasiado profundas (máximo ${maxDepth} niveles).`);
  return segs.join('/');
}

/** Traduce los errores internos de yauzl a mensajes claros para el usuario. */
function zipError(e) {
  if (e && e.isUserError) return e;
  const m = String((e && e.message) || '');
  if (/absolute path/i.test(m)) return new UserError('Ruta absoluta no permitida en el ZIP.', 400, 'zip_unsafe_path');
  if (/invalid relative path/i.test(m)) return new UserError('Ruta peligrosa en el ZIP (intenta salir de la carpeta).', 400, 'zip_unsafe_path');
  if (/invalid characters in fileName/i.test(m)) return new UserError('Ruta no permitida en el ZIP (caracteres no válidos).', 400, 'zip_unsafe_path');
  if (/encrypted|strong encryption/i.test(m)) return new UserError('El ZIP está protegido con contraseña; súbelo sin cifrar.', 400, 'zip_encrypted');
  return new UserError('El archivo ZIP está dañado o usa una compresión no soportada.', 400, 'zip_invalid');
}

function openZip(file) {
  return new Promise((resolve, reject) => {
    yauzl.open(file, { lazyEntries: true, autoClose: false, validateEntrySizes: true, strictFileNames: false }, (err, zip) => {
      if (err) reject(new UserError('El archivo ZIP está dañado o no es un ZIP válido.', 400, 'zip_invalid'));
      else resolve(zip);
    });
  });
}

const isSymlink = (entry) => ((entry.externalFileAttributes >>> 16) & 0o170000) === 0o120000;

/** Primera pasada: lista y valida las entradas sin extraer nada. */
async function inspectZip(file, zipBytes, limits) {
  const zip = await openZip(file);
  const entries = [];
  const seen = new Set();
  const skipped = [];
  let totalDeclared = 0;
  try {
    await new Promise((resolve, reject) => {
      zip.on('error', (e) => reject(zipError(e)));
      zip.on('end', resolve);
      zip.on('entry', (entry) => {
        try {
          if (entry.fileName.endsWith('/')) { zip.readEntry(); return; }
          if (entries.length + skipped.length >= limits.maxZipFiles * 2) {
            throw new UserError(`El ZIP tiene demasiados archivos (máximo ${limits.maxZipFiles}).`, 400, 'zip_too_many');
          }
          const name = cleanEntryName(entry.fileName, limits);
          if (name === null) { skipped.push(entry.fileName); zip.readEntry(); return; }
          if (isSymlink(entry)) throw new UserError(`El ZIP contiene un enlace simbólico no permitido: "${name}".`);
          if (entry.isEncrypted()) throw new UserError('El ZIP está protegido con contraseña; súbelo sin cifrar.');
          const key = name.toLowerCase();
          if (seen.has(key)) throw new UserError(`El ZIP contiene el archivo duplicado "${name}".`);
          seen.add(key);
          if (entry.uncompressedSize > limits.maxFileBytes) {
            throw new UserError(`"${name}" pesa ${mb(entry.uncompressedSize)} MB y el máximo por archivo es ${mb(limits.maxFileBytes)} MB.`, 400, 'zip_file_too_big');
          }
          totalDeclared += entry.uncompressedSize;
          if (totalDeclared > limits.maxUnzippedBytes) {
            throw new UserError(`El contenido descomprimido supera ${mb(limits.maxUnzippedBytes)} MB.`, 400, 'zip_too_big');
          }
          entries.push({ entry, name, size: entry.uncompressedSize });
          if (entries.length > limits.maxZipFiles) {
            throw new UserError(`El ZIP tiene demasiados archivos (máximo ${limits.maxZipFiles}).`, 400, 'zip_too_many');
          }
          zip.readEntry();
        } catch (e) { reject(e); }
      });
      zip.readEntry();
    });
  } finally {
    zip.close();
  }
  if (!entries.length) throw new UserError('El ZIP está vacío.', 400, 'zip_empty');
  if (totalDeclared > 20 * 1048576 && totalDeclared / Math.max(1, zipBytes) > 150) {
    throw new UserError('El ZIP tiene una relación de compresión sospechosa y fue rechazado.', 400, 'zip_bomb');
  }
  const bad = entries.filter((e) => !ALLOWED_EXT.has(extOf(e.name))).map((e) => e.name);
  if (bad.length) {
    const sample = bad.slice(0, 5).map((n) => `"${n}"`).join(', ');
    throw new UserError(`Tipos de archivo no permitidos (${bad.length}): ${sample}${bad.length > 5 ? '…' : ''}.`, 400, 'zip_bad_type');
  }
  return { entries, skipped, totalDeclared };
}

/** Si todo el proyecto está dentro de una única carpeta, devuelve su prefijo ("juego/"). */
function wrapperPrefix(names) {
  const first = names[0].split('/');
  if (first.length < 2) return '';
  const top = first[0] + '/';
  return names.every((n) => n.startsWith(top)) ? top : '';
}

export function pickEntry(paths) {
  const lower = new Map(paths.map((p) => [p.toLowerCase(), p]));
  if (lower.has('index.html')) return lower.get('index.html');
  if (lower.has('index.htm')) return lower.get('index.htm');
  const rootHtml = paths.filter((p) => !p.includes('/') && /\.html?$/i.test(p));
  if (rootHtml.length === 1) return rootHtml[0];
  if (rootHtml.length > 1) {
    throw new UserError(`Hay varios HTML en la raíz (${rootHtml.slice(0, 4).join(', ')}) y ninguno se llama index.html. Renombra el principal a index.html.`, 400, 'zip_no_entry');
  }
  throw new UserError('No encontré un index.html en el ZIP. Debe estar en la raíz del proyecto (o dentro de una única carpeta).', 400, 'zip_no_entry');
}

/**
 * Valida y extrae un ZIP a `destDir` (debe NO existir o estar vacío).
 * Nada de lo que contiene se ejecuta. Devuelve {entry, files:[{path,size}], total, skipped}.
 */
export async function extractZip(zipFile, destDir, limits) {
  const zipBytes = fs.statSync(zipFile).size;
  const { entries, skipped } = await inspectZip(zipFile, zipBytes, limits);
  const prefix = wrapperPrefix(entries.map((e) => e.name));
  const rel = (e) => e.name.slice(prefix.length);
  const relPaths = entries.map(rel);
  const entryHtml = pickEntry(relPaths);

  fs.mkdirSync(destDir, { recursive: true });
  const root = path.resolve(destDir);
  const wanted = new Map(entries.map((e) => [e.entry.fileName, e]));
  const files = [];
  let total = 0;

  const zip = await openZip(zipFile);
  try {
    await new Promise((resolve, reject) => {
      zip.on('error', () => reject(new UserError('El ZIP está dañado o su contenido no coincide con lo declarado.', 400, 'zip_invalid')));
      zip.on('end', resolve);
      zip.on('entry', (entry) => {
        const item = wanted.get(entry.fileName);
        if (!item) { zip.readEntry(); return; }
        const relPath = rel(item);
        const target = path.resolve(root, relPath);
        if (!target.startsWith(root + path.sep)) { reject(new UserError(`Ruta peligrosa en el ZIP: "${item.name}".`)); return; }
        fs.mkdirSync(path.dirname(target), { recursive: true });
        zip.openReadStream(entry, async (err, stream) => {
          if (err) { reject(new UserError('No se pudo leer un archivo del ZIP.', 400, 'zip_invalid')); return; }
          let n = 0;
          const guard = new Transform({
            transform(chunk, _enc, cb) {
              n += chunk.length;
              total += chunk.length;
              if (n > limits.maxFileBytes || total > limits.maxUnzippedBytes) {
                cb(new UserError('El contenido real del ZIP supera los límites permitidos.', 400, 'zip_bomb'));
              } else cb(null, chunk);
            },
          });
          try {
            await pipeline(stream, guard, fs.createWriteStream(target, { flags: 'wx', mode: 0o644 }));
            files.push({ path: relPath, size: n });
            zip.readEntry();
          } catch (e) {
            reject(e instanceof UserError ? e : new UserError('El ZIP está dañado o su contenido no coincide con lo declarado.', 400, 'zip_invalid'));
          }
        });
      });
      zip.readEntry();
    });
  } catch (e) {
    fs.rmSync(destDir, { recursive: true, force: true });
    throw e;
  } finally {
    zip.close();
  }
  return { entry: entryHtml, files, total, skipped };
}
