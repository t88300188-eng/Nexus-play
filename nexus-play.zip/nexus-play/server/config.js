import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const MB = 1024 * 1024;
const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function num(env, key, fallback, { min = 0 } = {}) {
  const raw = env[key];
  if (raw === undefined || raw === '') return fallback;
  const v = Number(raw);
  return Number.isFinite(v) && v >= min ? v : fallback;
}

let version = '0.0.0';
try {
  version = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8')).version;
} catch { /* sin package.json: versión por defecto */ }

/**
 * Lee la configuración desde variables de entorno (ver .env.example).
 * `overrides` permite a las pruebas automáticas cambiar valores sin tocar el entorno.
 */
export function loadConfig(overrides = {}, env = process.env) {
  const cfg = {
    version,
    rootDir,
    port: num(env, 'PORT', 3000),
    host: env.HOST || '0.0.0.0',
    dataDir: path.resolve(env.DATA_DIR || path.join(rootDir, 'data')),
    quiet: false,
    trustProxy: env.TRUST_PROXY === 'true',
    uploadKey: env.UPLOAD_KEY || '',

    // Subidas (todo configurable; valores pensados para un celular)
    maxHtmlBytes: num(env, 'MAX_HTML_MB', 5) * MB,
    maxZipBytes: num(env, 'MAX_ZIP_MB', 30) * MB,
    maxUnzippedBytes: num(env, 'MAX_UNZIPPED_MB', 100) * MB,
    maxFileBytes: num(env, 'MAX_FILE_MB', 25) * MB,
    maxZipFiles: num(env, 'MAX_ZIP_FILES', 2000),
    maxZipDepth: num(env, 'MAX_ZIP_DEPTH', 10),
    maxUserBytes: num(env, 'MAX_USER_MB', 300) * MB,
    maxGamesPerUser: num(env, 'MAX_GAMES_PER_USER', 30),
    maxVersionsPerGame: num(env, 'MAX_VERSIONS', 20),
    maxUsers: num(env, 'MAX_USERS', 2000),

    // Salas
    maxRoomPlayers: num(env, 'MAX_ROOM_PLAYERS', 16),
    maxHostedRooms: num(env, 'MAX_HOSTED_ROOMS', 5),
    roomTtlMs: num(env, 'ROOM_TTL_MIN', 240) * 60_000,
    roomIdleMs: num(env, 'ROOM_IDLE_MIN', 15) * 60_000,
    closedRoomKeepMs: 24 * 3600_000,
    startTimeoutMs: 8000,
    closeDelayMs: 400,
    sweepMs: 30_000,
    sessionDays: num(env, 'SESSION_DAYS', 30),

    // Tiempo real
    wsMaxPayload: 16 * 1024,
    wsMaxMessageBytes: 8 * 1024,
    wsMaxStateBytes: 2 * 1024,
    wsMaxSharedValueBytes: 4 * 1024,
    wsMaxSharedTotalBytes: 32 * 1024,
    wsRatePerSec: num(env, 'WS_RATE_PER_SEC', 40),
    wsBurst: num(env, 'WS_BURST', 80),
    wsMaxConnections: num(env, 'WS_MAX_CONN', 300),
    wsMaxPerIp: num(env, 'WS_MAX_PER_IP', 30),
    wsHeartbeatMs: 20_000,
    ticketTtlMs: 30_000,

    // Límites HTTP (por IP)
    httpRatePerMin: num(env, 'HTTP_RATE_PER_MIN', 600),
    sessionsPerHour: num(env, 'SESSIONS_PER_HOUR', 60),
    uploadsPer10Min: num(env, 'UPLOADS_PER_10MIN', 30),
  };
  return Object.assign(cfg, overrides);
}
