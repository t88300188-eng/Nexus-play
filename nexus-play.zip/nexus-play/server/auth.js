import { UserError } from './errors.js';
import { cleanText, randId, randToken, sha256, clientIp } from './util.js';
import { RateLimiter } from './ratelimit.js';

/**
 * Identidad de invitado: el usuario elige un nombre y recibe un token aleatorio.
 * Solo se guarda el hash SHA-256 del token. No hay contraseñas ni cookies
 * (el token viaja en la cabecera Authorization), así que no hay CSRF.
 */
export class Auth {
  constructor({ store, config, log, now = Date.now }) {
    this.store = store;
    this.cfg = config;
    this.log = log;
    this.now = now;
    this.byHash = new Map();
    for (const u of Object.values(store.data.users)) if (u.tokenHash) this.byHash.set(u.tokenHash, u.id);
    this.sessionLimiter = new RateLimiter({ max: config.sessionsPerHour, windowMs: 3600_000, now });
  }

  get users() { return this.store.data.users; }

  createSession(nameRaw, ip) {
    if (!this.sessionLimiter.hit(ip)) {
      throw new UserError('Demasiadas sesiones nuevas desde tu red. Espera un rato.', 429, 'rate_limited');
    }
    if (Object.keys(this.users).length >= this.cfg.maxUsers) {
      throw new UserError('El servidor alcanzó su límite de usuarios.', 503, 'server_full');
    }
    const name = cleanText(nameRaw, { min: 2, max: 24, field: 'El nombre' });
    const token = randToken(32);
    const user = { id: randId('u_', 6), name, tokenHash: sha256(token), createdAt: this.now(), lastSeen: this.now(), system: false };
    this.users[user.id] = user;
    this.byHash.set(user.tokenHash, user.id);
    this.store.save();
    this.log.info('session.created', { user: user.id });
    return { token, user: this.publicUser(user) };
  }

  /** Usuario interno (dueño del juego de demostración). No tiene token utilizable. */
  ensureSystemUser(name) {
    let u = Object.values(this.users).find((x) => x.system);
    if (!u) {
      u = { id: randId('u_', 6), name, tokenHash: null, createdAt: this.now(), lastSeen: this.now(), system: true };
      this.users[u.id] = u;
      this.store.save();
    }
    return u;
  }

  authenticate(token) {
    if (typeof token !== 'string' || token.length < 20 || token.length > 100) return null;
    const id = this.byHash.get(sha256(token));
    const u = id && this.users[id];
    if (!u) return null;
    const t = this.now();
    if (t - u.lastSeen > 10 * 60_000) { u.lastSeen = t; this.store.save(); }
    return u;
  }

  fromRequest(req) {
    const h = req.headers.authorization;
    if (typeof h !== 'string' || !h.startsWith('Bearer ')) return null;
    return this.authenticate(h.slice(7).trim());
  }

  rename(user, nameRaw) {
    user.name = cleanText(nameRaw, { min: 2, max: 24, field: 'El nombre' });
    this.store.save();
    return this.publicUser(user);
  }

  publicUser(u) { return { id: u.id, name: u.name, createdAt: u.createdAt }; }

  /** Borra invitados inactivos (90 días) que no tienen juegos ni salas activas. */
  prune() {
    const cutoff = this.now() - 90 * 24 * 3600_000;
    const owners = new Set(Object.values(this.store.data.games).map((g) => g.ownerId));
    const inRooms = new Set();
    for (const r of Object.values(this.store.data.rooms)) for (const id of Object.keys(r.members)) inRooms.add(id);
    let n = 0;
    for (const u of Object.values(this.users)) {
      if (u.system || owners.has(u.id) || inRooms.has(u.id) || u.lastSeen > cutoff) continue;
      if (u.tokenHash) this.byHash.delete(u.tokenHash);
      delete this.users[u.id];
      n++;
    }
    if (n) { this.store.save(); this.log.info('auth.pruned', { users: n }); }
    return n;
  }
}

export { clientIp };
