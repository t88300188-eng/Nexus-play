// Puente entre el juego (iframe aislado) y la sala. El juego NUNCA ve el token ni abre su propio
// WebSocket: habla con el SDK por postMessage y este puente valida y reenvía a la sala.
// El iframe no tiene "allow-same-origin", así que su origen es "null": la identidad del remitente
// se comprueba por referencia (event.source === iframe.contentWindow), no por origen.

const EVENT_NAME = /^[A-Za-z0-9_.:-]{1,32}$/;
const KEY_NAME = /^[A-Za-z0-9_.-]{1,32}$/;
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const size = (v) => { try { const s = JSON.stringify(v); return s === undefined ? 0 : s.length; } catch { return -1; } };

const sdkStatus = (s) => (s === 'connected' ? 'connected' : s === 'connecting' || s === 'reconnecting' ? 'reconnecting' : 'disconnected');

export class GameBridge {
  constructor(iframe, link, { onLeave } = {}) {
    this.iframe = iframe;
    this.link = link;
    this.onLeave = onLeave;
    this.wantsInit = false;
    this.inited = false;
    this.tokens = 80;
    this.lastRefill = performance.now();
    this.onWindowMessage = (ev) => this.#fromGame(ev);
    window.addEventListener('message', this.onWindowMessage);
    this.offMsg = link.on('msg', (m, isResync) => this.#fromRoom(m, isResync));
    this.offStatus = link.on('status', (s) => { if (this.inited) this.#post({ type: 'connection', status: sdkStatus(s) }); });
  }

  destroy() {
    window.removeEventListener('message', this.onWindowMessage);
    this.offMsg();
    this.offStatus();
  }

  #post(msg) {
    try { this.iframe.contentWindow?.postMessage({ nexus: 1, ...msg }, '*'); } catch { /* iframe ya no existe */ }
  }

  #allow() {
    const now = performance.now();
    this.tokens = Math.min(80, this.tokens + ((now - this.lastRefill) / 1000) * 60);
    this.lastRefill = now;
    if (this.tokens < 1) return false;
    this.tokens -= 1;
    return true;
  }

  #sendInit() {
    const s = this.link.snap;
    if (!s.meId) { this.wantsInit = true; return; } // aún no hay datos: se responde al llegar el "hello"
    this.wantsInit = false;
    this.inited = true;
    this.#post({
      type: 'init', room: s.room, players: s.players, states: s.states, shared: s.shared,
      meId: s.meId, connection: sdkStatus(this.link.status),
    });
  }

  #fromGame(ev) {
    if (ev.source !== this.iframe.contentWindow) return;
    const m = ev.data;
    if (!isObj(m) || m.nexus !== 1 || typeof m.type !== 'string') return;
    if (m.type === 'hello') { this.#sendInit(); return; }
    if (!this.inited) return;
    if (!this.#allow()) return;
    switch (m.type) {
      case 'send': {
        if (typeof m.name !== 'string' || !EVENT_NAME.test(m.name)) return;
        if (size(m.data) < 0 || size(m.data) > 7000) return;
        const msg = { t: 'ev', n: m.name, d: m.data ?? null };
        if (typeof m.to === 'string' && m.to.length <= 40) msg.to = m.to;
        this.link.send(msg);
        break;
      }
      case 'state':
        if (!isObj(m.data) || size(m.data) < 0 || size(m.data) > 1900) return;
        this.link.send({ t: 'st', d: m.data });
        break;
      case 'shared':
        if (typeof m.key !== 'string' || !KEY_NAME.test(m.key)) return;
        if (m.value !== null && (size(m.value) < 0 || size(m.value) > 3500)) return;
        this.link.send({ t: 'sh', k: m.key, d: m.value ?? null });
        break;
      case 'ready':
        this.link.send({ t: 'ready' });
        break;
      case 'ping': {
        const id = m.id;
        this.link.ping().then((rtt) => this.#post({ type: 'pong', id, rtt })).catch(() => {});
        break;
      }
      case 'leave':
        this.onLeave?.();
        break;
      default:
        break;
    }
  }

  #fromRoom(m, isResync) {
    if (m.t === 'hello') {
      if (this.wantsInit) { this.#sendInit(); return; }
      if (isResync && this.inited) this.#resync();
      return;
    }
    if (!this.inited) return;
    switch (m.t) {
      case 'players': this.#post({ type: 'players', list: m.list, change: m.change }); break;
      case 'room': this.#post({ type: 'room', room: m.room, players: m.players }); break;
      case 'ev': this.#post({ type: 'event', name: m.n, data: m.d, from: m.from }); break;
      case 'st': this.#post({ type: 'state', from: m.from, data: m.d }); break;
      case 'sh': this.#post({ type: 'shared', key: m.k, value: m.d }); break;
      case 'err': this.#post({ type: 'error', code: m.code, message: m.message }); break;
      case 'bye': this.#post({ type: 'closed', reason: m.reason }); break;
      default: break;
    }
  }

  /** Tras reconectar: el juego recibe de nuevo jugadores, sala, estados y valores compartidos. */
  #resync() {
    const s = this.link.snap;
    this.#post({ type: 'connection', status: 'connected' });
    this.#post({ type: 'room', room: s.room, players: s.players });
    for (const [from, data] of Object.entries(s.states)) this.#post({ type: 'state', from, data });
    for (const [key, value] of Object.entries(s.shared)) this.#post({ type: 'shared', key, value });
  }
}
