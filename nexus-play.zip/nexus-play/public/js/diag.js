// Estado de diagnóstico del navegador: registro de eventos, errores y estado de las conexiones.
// Nunca se guardan tokens, códigos de invitación ni contraseñas.

const MAX = 80;
export const clientLog = [];
export const state = {
  backend: { ok: null, latencyMs: null, lastCheck: null, failures: 0, lastError: null },
  ws: { status: 'idle', latencyMs: null, reconnects: 0, lastClose: null, roomId: null },
};
const listeners = new Set();

export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function notify() { for (const fn of listeners) { try { fn(); } catch { /* ignorar */ } } }

export function log(level, message, data) {
  clientLog.push({ ts: Date.now(), level, message: String(message).slice(0, 300), data: data ? scrub(data) : undefined });
  if (clientLog.length > MAX) clientLog.shift();
  notify();
}

const SECRET = /token|ticket|authorization|password|secret|invite|code|key/i;
function scrub(v, depth = 0) {
  if (v === null || typeof v !== 'object') return typeof v === 'string' && v.length > 200 ? v.slice(0, 200) + '…' : v;
  if (depth > 2) return '[…]';
  if (Array.isArray(v)) return v.slice(0, 10).map((x) => scrub(x, depth + 1));
  const out = {};
  for (const [k, x] of Object.entries(v)) out[k] = SECRET.test(k) ? '[oculto]' : scrub(x, depth + 1);
  return out;
}

window.addEventListener('error', (e) => log('error', `Error de JavaScript: ${e.message}`, { at: `${(e.filename || '').split('/').pop()}:${e.lineno}` }));
window.addEventListener('unhandledrejection', (e) => log('error', `Promesa rechazada: ${e.reason?.message || e.reason}`));

const fmtTs = (t) => new Date(t).toISOString().slice(11, 19);

/** Informe de texto para pegar en un chat. `server` es la respuesta de /api/diagnostics (puede faltar). */
export function buildReport(server, extra = {}) {
  const L = [];
  L.push('=== INFORME DE DIAGNÓSTICO — NEXUS PLAY ===');
  L.push(`Generado: ${new Date().toISOString()}`);
  L.push(`Navegador: ${navigator.userAgent}`);
  L.push(`Pantalla: ${innerWidth}x${innerHeight} · táctil: ${matchMedia('(pointer:coarse)').matches ? 'sí' : 'no'} · contexto seguro (https): ${window.isSecureContext ? 'sí' : 'no'}`);
  L.push(`En línea (navegador): ${navigator.onLine ? 'sí' : 'no'} · WebSocket: ${'WebSocket' in window ? 'disponible' : 'NO disponible'}`);
  L.push('');
  L.push('-- Conexiones (cliente) --');
  L.push(`Backend: ${state.backend.ok === null ? 'sin comprobar' : state.backend.ok ? 'OK' : 'SIN RESPUESTA'} · latencia HTTP: ${state.backend.latencyMs ?? '—'} ms · fallos seguidos: ${state.backend.failures}`);
  L.push(`Multijugador: ${state.ws.status} · latencia WS: ${state.ws.latencyMs ?? '—'} ms · reconexiones: ${state.ws.reconnects}${state.ws.lastClose ? ` · último cierre: ${state.ws.lastClose}` : ''}`);
  for (const [k, v] of Object.entries(extra)) L.push(`${k}: ${v}`);
  if (server) {
    L.push('');
    L.push('-- Servidor --');
    L.push(`Versión ${server.server.version} · Node ${server.server.node} · ${server.server.platform}/${server.server.arch} · activo ${server.server.uptimeSec}s · RAM ${server.server.rssMb} MB`);
    const st = server.storage;
    L.push(`Almacenamiento: carpeta escribible: ${st.dataDirWritable ? 'sí' : 'NO'} · juegos: ${st.gamesMb} MB · libre: ${st.freeMb ?? '?'} MB · última escritura: ${st.lastSaveAt ? new Date(st.lastSaveAt).toISOString() : '—'}${st.lastError ? ` · ERROR: ${st.lastError.message}` : ''}${st.recoveredFrom ? ` · recuperado desde: ${st.recoveredFrom}` : ''}`);
    const rt = server.realtime;
    L.push(`Tiempo real: ${rt.connections} conexiones · ${rt.rooms} salas con jugadores · aceptadas ${rt.accepted} · rechazadas ${rt.rejected} · mensajes inválidos ${rt.invalid} · limitados ${rt.rateLimited}`);
    const r = server.rooms;
    L.push(`Salas: ${Object.entries(r.byState).map(([k, v]) => `${k}=${v}`).join(' ')} · jugadores conectados: ${r.playersOnline}`);
    L.push(`Juegos: ${server.games.total} (${server.games.published} publicados) · tu espacio: ${server.games.mineMb}/${server.games.quotaMb} MB`);
    if (server.games.recentErrors.length) {
      L.push('Errores recientes de carga:');
      for (const e of server.games.recentErrors) L.push(`  [${fmtTs(e.ts)}] ${e.kind}: ${e.message}`);
    }
    if (rt.lastErrors.length) {
      L.push('Errores recientes de comunicación (servidor):');
      for (const e of rt.lastErrors) L.push(`  [${fmtTs(e.ts)}] ${e.kind}: ${e.message}`);
    }
    L.push('');
    L.push('-- Registro del servidor (últimos eventos) --');
    for (const e of server.logs.slice(-30)) L.push(`[${fmtTs(e.ts)}] ${e.level.toUpperCase()} ${e.event} ${Object.keys(e.data).length ? JSON.stringify(e.data) : ''}`);
  } else {
    L.push('');
    L.push('-- Servidor -- (no se pudo consultar)');
  }
  L.push('');
  L.push('-- Registro del navegador --');
  for (const e of clientLog.slice(-40)) L.push(`[${fmtTs(e.ts)}] ${e.level.toUpperCase()} ${e.message}${e.data ? ' ' + JSON.stringify(e.data) : ''}`);
  L.push('');
  L.push('(Este informe no contiene contraseñas, tokens ni códigos de invitación.)');
  return L.join('\n');
}
