import { api } from './api.js';
import { log, state, notify } from './diag.js';

const GONE_TEXT = {
  room_closed: 'La sala fue cerrada.',
  kicked: 'El anfitrión te expulsó de la sala.',
  left: 'Saliste de la sala.',
  gone: 'La sala ya no existe o ya no tienes acceso.',
  session: 'Tu sesión ya no es válida.',
  origin: 'El servidor rechazó la conexión (origen no permitido).',
};
export const goneText = (reason) => GONE_TEXT[reason] || 'La conexión con la sala terminó.';

/**
 * Conexión de una sala con reconexión automática.
 * Estados: connecting · connected · reconnecting · closed(reason) · unavailable(reason) · replaced
 * Guarda una "instantánea" (jugadores, estados, valores compartidos) que sobrevive a las reconexiones.
 */
export class RoomLink {
  constructor(roomId) {
    this.roomId = roomId;
    this.ws = null;
    this.status = 'connecting';
    this.reason = null;
    this.attempt = 0;
    this.stopped = false;
    this.latency = null;
    this.snap = { room: null, players: [], states: {}, shared: {}, meId: null };
    this.h = { status: [], msg: [], latency: [] };
    this.retryTimer = null;
    this.pingTimer = null;
    this.lastPong = 0;
    this.pingWaiters = new Map();
    this.wake = () => this.#wake();
    this.hadHello = false;
  }

  on(evt, fn) {
    this.h[evt].push(fn);
    return () => { this.h[evt] = this.h[evt].filter((f) => f !== fn); };
  }

  #emit(evt, ...args) { for (const fn of this.h[evt].slice()) { try { fn(...args); } catch (e) { log('error', `Manejador de ${evt}: ${e.message}`); } } }

  start() {
    document.addEventListener('visibilitychange', this.wake);
    window.addEventListener('online', this.wake);
    state.ws = { ...state.ws, status: 'connecting', roomId: this.roomId };
    this.#connect();
  }

  stop() {
    this.stopped = true;
    clearTimeout(this.retryTimer);
    clearInterval(this.pingTimer);
    document.removeEventListener('visibilitychange', this.wake);
    window.removeEventListener('online', this.wake);
    if (this.ws) { this.ws.onclose = null; try { this.ws.close(1000); } catch { /* ya cerrado */ } }
    this.ws = null;
    state.ws = { ...state.ws, status: 'idle', latencyMs: null, roomId: null };
    notify();
  }

  #set(status, reason = null) {
    this.status = status;
    this.reason = reason;
    state.ws = { ...state.ws, status, roomId: this.roomId };
    notify();
    this.#emit('status', status, { reason, attempt: this.attempt });
  }

  #end(status, reason) {
    this.stopped = true;
    clearTimeout(this.retryTimer);
    clearInterval(this.pingTimer);
    document.removeEventListener('visibilitychange', this.wake);
    window.removeEventListener('online', this.wake);
    log('info', `Conexión de sala terminada: ${status}/${reason}`);
    this.#set(status, reason);
  }

  async #connect() {
    if (this.stopped) return;
    this.#set(this.hadHello || this.attempt > 0 ? 'reconnecting' : 'connecting');
    let ticket;
    try {
      ({ ticket } = await api(`/api/rooms/${this.roomId}/ticket`, { method: 'POST', quiet: true }));
    } catch (e) {
      if (this.stopped) return;
      if (e.status === 404) return this.#end('unavailable', 'gone');
      if (e.status === 410) return this.#end('closed', 'room_closed');
      if (e.code === 'unauthorized') return this.#end('unavailable', 'session');
      this.#retry(e.code === 'rate_limited' ? 8000 : 0);
      return;
    }
    if (this.stopped) return;
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    let ws;
    try { ws = new WebSocket(`${proto}//${location.host}/ws?t=${encodeURIComponent(ticket)}`); } catch (e) {
      log('error', `No se pudo abrir WebSocket: ${e.message}`);
      this.#retry();
      return;
    }
    this.ws = ws;
    ws.onmessage = (ev) => this.#onMessage(ev);
    ws.onerror = () => { /* el detalle llega en onclose */ };
    ws.onclose = (ev) => this.#onClose(ev, ws);
  }

  #onMessage(ev) {
    let m;
    try { m = JSON.parse(ev.data); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    const s = this.snap;
    switch (m.t) {
      case 'hello':
        s.meId = m.you.id;
        s.room = m.room;
        s.players = m.players;
        s.states = m.states || {};
        s.shared = m.shared || {};
        this.attempt = 0;
        this.lastPong = performance.now();
        this.#set('connected');
        this.#startPing();
        log('info', this.hadHello ? 'Reconectado a la sala' : 'Conectado a la sala');
        break;
      case 'players': s.players = m.list; break;
      case 'room': s.room = m.room; if (m.players) s.players = m.players; break;
      case 'st': s.states[m.from] = m.d; break;
      case 'sh': if (m.d === null) delete s.shared[m.k]; else s.shared[m.k] = m.d; break;
      case 'pong': {
        this.lastPong = performance.now();
        const rtt = Math.round(performance.now() - m.ts);
        this.latency = rtt;
        state.ws.latencyMs = rtt;
        const w = this.pingWaiters.get(m.ts);
        if (w) { this.pingWaiters.delete(m.ts); w(rtt); }
        this.#emit('latency', rtt);
        notify();
        return;
      }
      case 'err': log('warn', `El servidor rechazó un mensaje: ${m.code}`); break;
      case 'bye': this.byeReason = m.reason; break;
      default: break;
    }
    const wasHello = m.t === 'hello';
    this.#emit('msg', m, wasHello && this.hadHello);
    if (wasHello) this.hadHello = true;
  }

  #onClose(ev, ws) {
    if (ws !== this.ws) return;
    clearInterval(this.pingTimer);
    this.ws = null;
    state.ws.lastClose = `${ev.code}${ev.reason ? ' ' + ev.reason : ''}`;
    if (this.stopped) return;
    switch (ev.code) {
      case 4001: return this.#end('closed', 'room_closed');
      case 4005: return this.#end('closed', 'kicked');
      case 4006: return this.#end('closed', 'left');
      case 4003: return this.#end('replaced', null);
      case 4002: return this.#end('unavailable', 'gone');
      case 4010: return this.#end('unavailable', 'origin');
      case 4008: return this.#retry(6000);
      case 4004: return this.#retry(200);
      default:
        log('warn', `WebSocket cerrado (${ev.code})`);
        return this.#retry();
    }
  }

  #retry(forceMs = 0) {
    if (this.stopped) return;
    this.attempt++;
    state.ws.reconnects++;
    const base = Math.min(15000, 500 * 2 ** (this.attempt - 1));
    const delay = forceMs || base + Math.random() * 300;
    this.#set('reconnecting');
    clearTimeout(this.retryTimer);
    this.retryTimer = setTimeout(() => this.#connect(), delay);
  }

  #wake() {
    if (this.stopped || document.visibilityState === 'hidden') return;
    if (this.status === 'reconnecting') {
      clearTimeout(this.retryTimer);
      this.#connect();
    } else if (this.status === 'connected') {
      // Tras suspender el teléfono, el socket puede estar muerto sin avisar: se comprueba ya.
      this.#sendPing();
      const mark = this.lastPong;
      setTimeout(() => { if (!this.stopped && this.lastPong === mark && this.ws) { log('warn', 'Sin respuesta tras reactivar; se reconecta'); this.ws.close(); } }, 4000);
    }
  }

  #startPing() {
    clearInterval(this.pingTimer);
    this.pingTimer = setInterval(() => {
      if (performance.now() - this.lastPong > 15000) {
        log('warn', 'El servidor no responde; se reconecta');
        try { this.ws?.close(); } catch { /* ya cerrado */ }
        return;
      }
      this.#sendPing();
    }, 5000);
    this.#sendPing();
  }

  #sendPing() { this.send({ t: 'ping', ts: performance.now() }); }

  send(obj) {
    if (!this.ws || this.ws.readyState !== 1) return false;
    this.ws.send(JSON.stringify({ v: 1, ...obj }));
    return true;
  }

  ping(timeoutMs = 3000) {
    return new Promise((resolve, reject) => {
      const ts = performance.now();
      const t = setTimeout(() => { this.pingWaiters.delete(ts); reject(new Error('timeout')); }, timeoutMs);
      this.pingWaiters.set(ts, (rtt) => { clearTimeout(t); resolve(rtt); });
      if (!this.send({ t: 'ping', ts })) { clearTimeout(t); this.pingWaiters.delete(ts); reject(new Error('sin conexión')); }
    });
  }
}
