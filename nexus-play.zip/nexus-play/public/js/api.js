import { log, state, notify } from './diag.js';

const SESSION_KEY = 'nexus.session';
const UPLOAD_KEY = 'nexus.uploadKey';

export class ApiError extends Error {
  constructor(message, code = 'error', status = 0) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

function readJson(key) {
  try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch { return null; }
}
function writeStore(key, value) {
  try { value === null ? localStorage.removeItem(key) : localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value)); } catch { /* almacenamiento bloqueado */ }
}

// Si localStorage está bloqueado, la sesión vive solo mientras la pestaña esté abierta.
let memorySession = readJson(SESSION_KEY);
const sessionListeners = new Set();

export const session = {
  get token() { return memorySession?.token || null; },
  get user() { return memorySession?.user || null; },
  set(value) { memorySession = value; writeStore(SESSION_KEY, value); for (const fn of sessionListeners) fn(); },
  clear() { this.set(null); },
  onChange(fn) { sessionListeners.add(fn); return () => sessionListeners.delete(fn); },
};

export const uploadKey = {
  get: () => { try { return localStorage.getItem(UPLOAD_KEY) || ''; } catch { return ''; } },
  set: (v) => writeStore(UPLOAD_KEY, v || null),
};

function headers(extra = {}, auth = true) {
  const h = { ...extra };
  if (auth && session.token) h.Authorization = `Bearer ${session.token}`;
  return h;
}

async function parse(res) {
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = null; }
  return data;
}

export async function api(path, { method = 'GET', body, auth = true, quiet = false } = {}) {
  let res;
  const t0 = performance.now();
  try {
    res = await fetch(path, {
      method,
      headers: headers(body !== undefined ? { 'Content-Type': 'application/json' } : {}, auth),
      body: body !== undefined ? JSON.stringify(body) : undefined,
      cache: 'no-store',
    });
  } catch {
    log('error', `Sin conexión con el servidor (${method} ${path.split('?')[0]})`);
    throw new ApiError('No se pudo conectar con el servidor. Revisa tu red.', 'network', 0);
  }
  const data = await parse(res);
  if (!res.ok) {
    const code = data?.error?.code || 'error';
    const message = data?.error?.message || `Error ${res.status}`;
    if (res.status === 401 && code === 'unauthorized') { session.clear(); }
    if (!quiet) log('warn', `${method} ${path.split('?')[0]} → ${res.status} ${code}`);
    throw new ApiError(message, code, res.status);
  }
  if (path.startsWith('/api/health')) data.rtt = Math.round(performance.now() - t0);
  return data;
}

/** Sube un archivo con progreso. Devuelve el JSON de respuesta. */
export function uploadFile(path, file, { method = 'POST', onProgress, contentType = 'application/octet-stream' } = {}) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(method, path);
    xhr.setRequestHeader('Content-Type', contentType);
    if (session.token) xhr.setRequestHeader('Authorization', `Bearer ${session.token}`);
    const key = uploadKey.get();
    if (key) xhr.setRequestHeader('X-Upload-Key', key);
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress?.(e.loaded / e.total); };
    xhr.onerror = () => { log('error', 'La subida falló por la red'); reject(new ApiError('Se perdió la conexión durante la subida.', 'network', 0)); };
    xhr.onabort = () => reject(new ApiError('Subida cancelada.', 'aborted', 0));
    xhr.onload = () => {
      let data = null;
      try { data = JSON.parse(xhr.responseText); } catch { /* sin cuerpo JSON */ }
      if (xhr.status >= 200 && xhr.status < 300) { resolve(data); return; }
      if (xhr.status === 401 && data?.error?.code === 'unauthorized') session.clear();
      const e = new ApiError(data?.error?.message || `Error ${xhr.status}`, data?.error?.code || 'error', xhr.status);
      log('warn', `Subida rechazada: ${e.code}`);
      reject(e);
    };
    xhr.send(file);
  });
}

/** Comprobación periódica del backend (alimenta el indicador de conexión y el diagnóstico). */
export async function pingBackend() {
  try {
    const h = await api('/api/health', { auth: false, quiet: true });
    state.backend = { ok: true, latencyMs: h.rtt, lastCheck: Date.now(), failures: 0, lastError: null };
    notify();
    return h;
  } catch (e) {
    state.backend = { ok: false, latencyMs: null, lastCheck: Date.now(), failures: state.backend.failures + 1, lastError: e.message };
    notify();
    return null;
  }
}
