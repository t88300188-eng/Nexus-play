// Utilidades de interfaz sin dependencias. Todo el contenido dinámico se inserta como TEXTO
// (nunca innerHTML), así que un nombre o descripción maliciosos no pueden ejecutar código.

const PROPS = new Set(['value', 'checked', 'disabled', 'hidden', 'selected', 'textContent', 'readOnly']);

export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (PROPS.has(k)) el[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  add(el, kids);
  return el;
}

function add(el, kids) {
  for (const k of kids) {
    if (k === null || k === undefined || k === false) continue;
    if (Array.isArray(k)) add(el, k);
    else el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}

/** Añade hijos ignorando null/undefined/false (el append nativo escribiría "null"). */
export function put(el, ...kids) { add(el, kids); return el; }
/** Vacía el elemento y añade hijos con la misma regla. */
export function fill(el, ...kids) { el.replaceChildren(); add(el, kids); return el; }

export const $ = (sel, root = document) => root.querySelector(sel);
export const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };

export function fmtBytes(n) {
  if (n == null) return '—';
  if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
  return Math.max(1, Math.round(n / 1024)) + ' KB';
}

export function timeAgo(ts) {
  if (!ts) return '—';
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 5) return 'ahora';
  if (s < 60) return `hace ${s} s`;
  if (s < 3600) return `hace ${Math.round(s / 60)} min`;
  if (s < 86400) return `hace ${Math.round(s / 3600)} h`;
  return new Date(ts).toLocaleDateString('es');
}

export const clock = (ts) => new Date(ts).toLocaleTimeString('es', { hour12: false });

export function hueOf(id) {
  let x = 0;
  for (let i = 0; i < id.length; i++) x = (x * 31 + id.charCodeAt(i)) >>> 0;
  return x % 360;
}

export function avatar(player) {
  return h('div', { class: 'av', style: { background: `hsl(${hueOf(player.id)},70%,58%)` } }, (player.name || '?').trim().charAt(0).toUpperCase());
}

let toastTimer;
export function toast(msg, kind = '') {
  const el = $('#toast');
  el.textContent = msg;
  el.className = kind;
  el.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.style.display = 'none'; }, kind === 'bad' ? 5000 : 3000);
}

export function modal(build, { wide = false, dismissible = true } = {}) {
  const root = $('#modal-root');
  const box = h('div', { class: 'box' + (wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true' });
  const back = h('div', { class: 'back' }, box);
  const prevFocus = document.activeElement;
  const api = {
    box,
    close(result) {
      back.remove();
      document.removeEventListener('keydown', onKey);
      prevFocus?.focus?.();
      api.onClose?.(result);
    },
  };
  function onKey(e) { if (e.key === 'Escape' && dismissible) api.close(null); }
  document.addEventListener('keydown', onKey);
  if (dismissible) back.addEventListener('mousedown', (e) => { if (e.target === back) api.close(null); });
  build(box, api);
  root.append(back);
  (box.querySelector('[autofocus]') || box.querySelector('input,select,textarea,button'))?.focus();
  return api;
}

export function confirmDialog(message, { title = 'Confirmar', okText = 'Aceptar', danger = false } = {}) {
  return new Promise((resolve) => {
    const m = modal((box, api) => {
      put(box, 
        h('h2', null, title),
        h('p', { style: { whiteSpace: 'pre-line' } }, message),
        h('div', { class: 'row b' },
          h('button', { class: 'btn ' + (danger ? 'd' : 'p'), type: 'button', autofocus: true, onclick: () => api.close(true) }, okText),
          h('button', { class: 'btn', type: 'button', onclick: () => api.close(false) }, 'Cancelar')),
      );
    });
    m.onClose = (r) => resolve(r === true);
  });
}

export function promptDialog({ title, label, value = '', okText = 'Guardar', type = 'text', help = '', dismissible = true, maxlength = 60 }) {
  return new Promise((resolve) => {
    const m = modal((box, api) => {
      const input = h('input', { type, value, maxlength, autofocus: true, autocomplete: 'off', enterkeyhint: 'done' });
      const err = h('div', { class: 'alert bad', hidden: true });
      const submit = () => {
        const v = input.value.trim();
        if (!v) { err.hidden = false; err.textContent = 'Escribe un valor.'; return; }
        api.close(v);
      };
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
      put(box, 
        h('h2', null, title),
        h('label', null, label), input,
        help ? h('small', null, help) : null,
        err,
        h('div', { class: 'row b' },
          h('button', { class: 'btn p', type: 'button', onclick: submit }, okText),
          dismissible ? h('button', { class: 'btn', type: 'button', onclick: () => api.close(null) }, 'Cancelar') : null),
      );
    }, { dismissible });
    m.onClose = (r) => resolve(r);
  });
}

/** Desactiva un botón y muestra un indicador mientras dura la promesa. */
export async function busy(btn, promise) {
  btn.disabled = true;
  btn.classList.add('loading');
  try { return await (typeof promise === 'function' ? promise() : promise); }
  finally { btn.disabled = false; btn.classList.remove('loading'); }
}

/** Copia texto. En http (red local) navigator.clipboard no existe; se usa el método clásico. */
export async function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); return true; }
  } catch { /* se prueba el método clásico */ }
  const ta = h('textarea', { readOnly: true, style: { position: 'fixed', opacity: '0', top: '0', left: '0' } });
  ta.value = text;
  document.body.append(ta);
  ta.focus();
  ta.select();
  ta.setSelectionRange(0, text.length);
  let ok = false;
  try { ok = document.execCommand('copy'); } catch { ok = false; }
  ta.remove();
  return ok;
}

export const loadingBox = (text = 'Cargando…') => h('div', { class: 'loading-box' }, text);
export const errorBox = (msg, retry) => h('div', { class: 'alert bad' }, msg, retry ? h('div', { class: 'row b' }, h('button', { class: 'btn s', type: 'button', onclick: retry }, 'Reintentar')) : null);
