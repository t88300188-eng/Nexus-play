import { h, $, clear, modal, toast, promptDialog, fill } from './ui.js';
import { api, session, pingBackend } from './api.js';
import { state, onChange, log } from './diag.js';
import { homeView } from './views/home.js';
import { libraryView } from './views/library.js';
import { gameView } from './views/game.js';
import { uploadView } from './views/upload.js';
import { roomsView, joinView } from './views/rooms.js';
import { roomView } from './views/room.js';
import { diagnosticsView } from './views/diagnostics.js';

const NAV = [
  ['#/', '▦', 'Inicio', (p) => p === '/'],
  ['#/games', '🎮', 'Juegos', (p) => p.startsWith('/games')],
  ['#/upload', '⬆', 'Subir', (p) => p === '/upload'],
  ['#/rooms', '🚪', 'Salas', (p) => p.startsWith('/rooms') || p.startsWith('/room/') || p.startsWith('/join/')],
  ['#/diag', '🩺', 'Diagnóstico', (p) => p === '/diag'],
];

const ROUTES = [
  [/^\/$/, (r) => homeView(r)],
  [/^\/games$/, (r) => libraryView(r)],
  [/^\/games\/([\w-]+)$/, (r, m) => gameView(r, { id: m[1] })],
  [/^\/upload$/, (r) => uploadView(r)],
  [/^\/rooms$/, (r) => roomsView(r)],
  [/^\/room\/([\w-]+)$/, (r, m) => roomView(r, { id: m[1] })],
  [/^\/join\/([\w-]+)$/, (r, m) => joinView(r, { code: m[1] })],
  [/^\/diag$/, (r) => diagnosticsView(r)],
];

const view = $('#view');
let cleanup = null;
let booted = false;

const currentPath = () => (location.hash.replace(/^#/, '') || '/').split('?')[0];

function renderNav() {
  const p = currentPath();
  const nav = $('#nav');
  fill(nav, ...NAV.map(([href, icon, label, match]) => h('a', { href, class: match(p) ? 'on' : '', 'aria-current': match(p) ? 'page' : null }, h('span', { 'aria-hidden': 'true' }, icon), label)));
}

function route() {
  if (!booted) return;
  try { cleanup?.(); } catch (e) { log('error', `Limpieza de vista: ${e.message}`); }
  cleanup = null;
  clear(view);
  const p = currentPath();
  renderNav();
  for (const [re, fn] of ROUTES) {
    const m = p.match(re);
    if (m) {
      try { cleanup = fn(view, m) || null; } catch (e) {
        log('error', `Error al mostrar la vista: ${e.message}`);
        view.append(h('div', { class: 'alert bad' }, 'No se pudo mostrar esta pantalla.'));
      }
      window.scrollTo(0, 0);
      return;
    }
  }
  view.append(h('div', { class: 'card' }, h('h2', null, 'Página no encontrada'), h('a', { class: 'btn p', href: '#/' }, 'Ir al inicio')));
}

function renderUser() {
  const u = session.user;
  const chip = $('#userchip');
  fill(chip, ...(u ? [h('small', null, 'Tu nombre'), u.name] : ['Sin sesión']));
}

function renderConn() {
  const b = state.backend;
  const el = $('#conn');
  const cls = b.ok === null ? '' : b.ok ? 'ok' : 'bad';
  const text = b.ok === null ? 'Conectando…' : b.ok ? `Servidor OK${b.latencyMs != null ? ` · ${b.latencyMs} ms` : ''}` : 'Sin servidor';
  fill(el, h('span', { class: 'dot ' + cls }), h('span', { class: 'conn-text' }, text));
}

async function askName(first) {
  for (;;) {
    const name = await promptDialog({
      title: first ? 'Bienvenido a NEXUS PLAY' : 'Tu nombre', label: 'Elige un nombre para jugar', value: session.user?.name || '',
      help: first ? 'Entras como invitado: no necesitas cuenta ni contraseña. Tu nombre se verá en las salas.' : '',
      okText: first ? 'Entrar' : 'Guardar', dismissible: !first, maxlength: 24,
    });
    if (name === null) return false;
    try {
      if (first) {
        const r = await api('/api/session', { method: 'POST', body: { name }, auth: false });
        session.set({ token: r.token, user: r.user });
      } else {
        const r = await api('/api/me', { method: 'PATCH', body: { name } });
        session.set({ token: session.token, user: r.user });
        toast('Nombre actualizado', 'ok');
      }
      return true;
    } catch (e) { toast(e.message, 'bad'); }
  }
}

async function ensureSession() {
  if (session.token) {
    try {
      const { user } = await api('/api/me', { quiet: true });
      session.set({ token: session.token, user });
      return true;
    } catch (e) {
      if (e.code === 'network') return true; // sin red: se conserva la sesión local
      session.clear();
    }
  }
  return askName(true);
}

async function boot() {
  $('#userchip').addEventListener('click', () => { if (session.token) askName(false).then(renderUser); });
  onChange(renderConn);
  session.onChange(renderUser);
  renderConn();
  await pingBackend();
  if (state.backend.ok === false) {
    view.append(h('div', { class: 'alert warn' }, 'No hay conexión con el servidor de NEXUS PLAY. Reintentando…'));
    while (state.backend.ok === false) { await new Promise((r) => setTimeout(r, 2500)); await pingBackend(); }
    clear(view);
  }
  await ensureSession();
  renderUser();
  booted = true;
  window.addEventListener('hashchange', route);
  route();
  setInterval(pingBackend, 10000);
}

boot().catch((e) => { log('error', `Fallo al iniciar: ${e.message}`); view.append(h('div', { class: 'alert bad' }, `No se pudo iniciar la aplicación: ${e.message}`)); });
