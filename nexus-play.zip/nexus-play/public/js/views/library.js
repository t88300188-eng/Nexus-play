import { h, loadingBox, errorBox, fill } from '../ui.js';
import { api } from '../api.js';
import { gameCard, errMsg } from './common.js';

export function libraryView(root) {
  const holder = h('div', null, loadingBox());
  root.append(holder);
  let dead = false;
  let games = [];
  let tab = 'all';
  let q = '';

  const grid = h('div', { class: 'grid' });
  const tabs = h('div', { class: 'tabs' });
  const search = h('input', { type: 'search', placeholder: 'Buscar por nombre o descripción…', 'aria-label': 'Buscar juegos', style: { maxWidth: '360px' } });
  search.addEventListener('input', () => { q = search.value.trim().toLowerCase(); paint(); });

  function paint() {
    const list = games.filter((g) =>
      (tab === 'all' || (tab === 'mine' && g.mine) || (tab === 'published' && g.published))
      && (!q || (g.title + ' ' + g.description + ' ' + g.ownerName).toLowerCase().includes(q)));
    fill(tabs, ...[['all', 'Todos'], ['mine', 'Míos'], ['published', 'Publicados']].map(([k, label]) =>
      h('button', { type: 'button', class: tab === k ? 'on' : '', onclick: () => { tab = k; paint(); } }, label)));
    fill(grid, ...(list.length ? list.map((g) => gameCard(g, { games })) : [h('div', { class: 'empty' }, games.length ? 'No hay juegos con ese filtro.' : 'Aún no hay juegos. Sube el primero.')]));
  }

  async function load() {
    try {
      ({ games } = await api('/api/games'));
      if (dead) return;
      fill(holder, 
        h('div', { class: 'bar' },
          h('div', null, h('h1', null, 'Biblioteca'), h('p', { class: 'sub', style: { margin: '2px 0 0' } }, 'Tus juegos y los publicados por otros')),
          h('a', { class: 'btn p', href: '#/upload' }, '＋ Subir juego')),
        h('div', { style: { margin: '12px 0' } }, search),
        tabs, grid);
      paint();
    } catch (e) {
      if (!dead) fill(holder, errorBox(errMsg(e), () => { fill(holder, loadingBox()); load(); }));
    }
  }
  load();
  return () => { dead = true; };
}
