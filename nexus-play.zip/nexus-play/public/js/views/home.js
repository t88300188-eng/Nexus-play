import { h, loadingBox, errorBox, fill } from '../ui.js';
import { api } from '../api.js';
import { gameCard, errMsg } from './common.js';
import { roomCard } from './rooms.js';

export function homeView(root) {
  const holder = h('div', null, loadingBox());
  root.append(holder);
  let dead = false;

  async function load() {
    try {
      const [{ games }, { rooms }] = await Promise.all([api('/api/games'), api('/api/rooms')]);
      if (dead) return;
      const mine = games.filter((g) => g.mine);
      const online = rooms.reduce((a, r) => a + r.players.filter((p) => p.online).length, 0);
      fill(holder, 
        h('h1', null, 'Panel de control'),
        h('p', { class: 'sub' }, 'Gestiona tus juegos HTML y tus salas privadas'),
        rooms.length ? h('div', { class: 'alert ok' },
          `Tienes ${rooms.length} sala${rooms.length === 1 ? '' : 's'} activa${rooms.length === 1 ? '' : 's'}. `,
          h('a', { href: `#/room/${rooms[0].id}` }, `Volver a “${rooms[0].name}”`)) : null,
        h('div', { class: 'stats' },
          stat('Juegos publicados', games.filter((g) => g.published).length),
          stat('Mis juegos', mine.length),
          stat('Mis salas activas', rooms.length),
          h('a', { class: 'card stat cta', href: '#/upload' }, h('small', null, 'Publicar nuevo'), h('b', null, 'Subir juego ＋')),
        ),
        h('div', { class: 'bar' }, h('h2', { style: { margin: 0 } }, 'Salas activas'),
          h('span', { class: 'small' }, `${online} jugador${online === 1 ? '' : 'es'} conectado${online === 1 ? '' : 's'}`)),
        h('div', { class: 'grid' }, rooms.length ? rooms.map(roomCard) : h('div', { class: 'empty' }, 'No tienes salas activas. Crea una desde un juego.')),
        h('div', { class: 'bar' }, h('h2', { style: { margin: 0 } }, 'Biblioteca'),
          h('a', { class: 'btn s', href: '#/games' }, 'Ver todo')),
        h('div', { class: 'grid' }, games.length ? games.slice(0, 4).map((g) => gameCard(g, { games })) : h('div', { class: 'empty' }, 'Aún no hay juegos. Sube el primero.')),
      );
    } catch (e) {
      if (!dead) fill(holder, errorBox(errMsg(e), () => { fill(holder, loadingBox()); load(); }));
    }
  }
  load();
  return () => { dead = true; };
}

const stat = (label, value) => h('div', { class: 'card stat' }, h('small', null, label), h('b', null, String(value)));
