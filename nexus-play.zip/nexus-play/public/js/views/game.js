import { h, loadingBox, errorBox, modal, toast, busy, confirmDialog, fmtBytes, timeAgo, fill, put } from '../ui.js';
import { api, uploadFile } from '../api.js';
import { go, errMsg, thumb, gameBadges, preview, openCreateRoom } from './common.js';
import { uploadWithKey } from './upload.js';

const LEVEL = {
  integrado: ['Ya integrado', ''],
  posible: ['Integrable (con trabajo en tu código)', 'wait'],
  dificil: ['Difícil', 'bad'],
  incierto: ['Incierto', 'off'],
};

export function gameView(root, { id }) {
  const holder = h('div', null, loadingBox());
  root.append(holder);
  let dead = false;
  let game = null;

  async function load() {
    try {
      ({ game } = await api(`/api/games/${id}`));
      if (!dead) paint();
    } catch (e) {
      if (!dead) fill(holder, errorBox(errMsg(e), () => { fill(holder, loadingBox()); load(); }), h('a', { class: 'btn', href: '#/games' }, 'Volver a la biblioteca'));
    }
  }

  function update(g) { game = g; paint(); }

  function paint() {
    const g = game;
    const actions = h('div', { class: 'row wrap' },
      h('button', { class: 'btn', type: 'button', onclick: () => preview(g) }, 'Probar'),
      h('button', { class: 'btn p', type: 'button', onclick: async () => { const { games } = await api('/api/games'); openCreateRoom(games, g.id); } }, 'Crear sala'));
    if (g.mine) {
      put(actions, 
        pubToggle(g),
        h('button', { class: 'btn', type: 'button', onclick: () => editDialog(g) }, 'Editar datos'),
        h('button', { class: 'btn d', type: 'button', onclick: () => remove(g) }, 'Eliminar'));
    }
    fill(holder, 
      h('div', { class: 'bar' }, h('a', { class: 'btn s ghost', href: '#/games' }, '← Biblioteca')),
      h('div', { class: 'card' },
        h('div', { style: { maxWidth: '420px' } }, thumb(g)),
        h('h1', null, g.title),
        h('small', null, g.mine ? 'Tuyo' : `de ${g.ownerName}`, ` · actualizado ${timeAgo(g.updatedAt)} · ${g.files} archivo${g.files === 1 ? '' : 's'}`),
        h('p', { style: { whiteSpace: 'pre-wrap' } }, g.description || 'Sin descripción.'),
        gameBadges(g),
        !g.published && g.mine ? h('div', { class: 'alert warn' }, 'Es un borrador: solo tú lo ves. Publícalo para que otros puedan crear salas con él.') : null,
        h('div', { style: { marginTop: '12px' } }, actions)),
      g.mine ? versionsCard(g) : null,
      g.mine ? integrationCard(g) : null,
    );
  }

  function pubToggle(g) {
    const b = h('button', { class: 'btn', type: 'button' }, g.published ? 'Despublicar' : 'Publicar');
    b.addEventListener('click', () => busy(b, async () => {
      try {
        const r = await api(`/api/games/${g.id}`, { method: 'PATCH', body: { published: !g.published } });
        toast(r.game.published ? 'Juego publicado' : 'Juego despublicado (las salas activas siguen funcionando)', 'ok');
        update(r.game);
      } catch (e) { toast(errMsg(e), 'bad'); }
    }));
    return b;
  }

  async function remove(g) {
    const ok = await confirmDialog(`¿Eliminar “${g.title}” con todas sus versiones?\nEsta acción no se puede deshacer.`, { title: 'Eliminar juego', okText: 'Eliminar', danger: true });
    if (!ok) return;
    try {
      await api(`/api/games/${g.id}`, { method: 'DELETE' });
      toast('Juego eliminado', 'ok');
      go('#/games');
    } catch (e) { toast(errMsg(e), 'bad'); }
  }

  function editDialog(g) {
    modal((box, m) => {
      const title = h('input', { type: 'text', maxlength: 60, value: g.title });
      const desc = h('textarea', { maxlength: 400 });
      desc.value = g.description;
      const thumbIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' });
      const err = h('div', { class: 'alert bad', hidden: true });
      const save = h('button', { class: 'btn p', type: 'button' }, 'Guardar');
      save.addEventListener('click', () => busy(save, async () => {
        err.hidden = true;
        try {
          let r = await api(`/api/games/${g.id}`, { method: 'PATCH', body: { title: title.value, description: desc.value } });
          const f = thumbIn.files[0];
          if (f) {
            if (f.size > 512 * 1024) throw new Error('La miniatura debe pesar menos de 512 KB.');
            r = await uploadWithKey(() => uploadFile(`/api/games/${g.id}/thumbnail`, f, { method: 'PUT', contentType: f.type || 'image/png' }));
          }
          m.close();
          toast('Cambios guardados', 'ok');
          update(r.game);
        } catch (e) { err.hidden = false; err.textContent = errMsg(e); }
      }));
      put(box, 
        h('h2', null, 'Editar datos'),
        h('label', null, 'Título'), title,
        h('label', null, 'Descripción'), desc,
        h('label', null, 'Cambiar miniatura (PNG/JPG/WebP, máx. 512 KB)'), thumbIn,
        g.thumbUrl ? h('button', {
          class: 'btn s', type: 'button', style: { marginTop: '8px' },
          onclick: async () => { try { const r = await api(`/api/games/${g.id}/thumbnail`, { method: 'DELETE' }); m.close(); update(r.game); toast('Miniatura quitada', 'ok'); } catch (e) { toast(errMsg(e), 'bad'); } },
        }, 'Quitar miniatura actual') : null,
        err,
        h('div', { class: 'row b' }, save, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancelar')));
    });
  }

  // ---------- Versiones ----------
  function versionsCard(g) {
    const rows = g.versions.slice().reverse().map((v) => h('tr', null,
      h('td', null, `v${v.n}`, v.current ? h('span', { class: 'badge', style: { marginLeft: '6px' } }, 'actual') : null, v.inUse ? h('span', { class: 'badge wait', style: { marginLeft: '6px' } }, 'en sala') : null),
      h('td', null, timeAgo(v.createdAt), h('br'), h('small', null, v.note || '')),
      h('td', null, v.kind === 'html' ? 'HTML' : v.kind === 'integrated' ? 'ZIP + SDK' : 'ZIP', h('br'), h('small', null, fmtBytes(v.size))),
      h('td', null, h('div', { class: 'row wrap' },
        h('button', { class: 'btn s', type: 'button', onclick: () => preview(g, v.n) }, 'Probar'),
        !v.current ? h('button', { class: 'btn s', type: 'button', onclick: () => act(`/api/games/${g.id}/current`, 'POST', { version: v.n }, `v${v.n} es ahora la versión actual`) }, 'Usar') : null,
        !v.current && !v.inUse ? h('button', { class: 'btn s d', type: 'button', onclick: () => delVersion(g, v) }, 'Eliminar') : null))));

    const file = h('input', { type: 'file', accept: '.html,.htm,.zip' });
    const note = h('input', { type: 'text', maxlength: 120, placeholder: 'Nota (qué cambió)' });
    const err = h('div', { class: 'alert bad', hidden: true });
    const bar = h('i');
    const progress = h('div', { class: 'progress', hidden: true }, bar);
    const up = h('button', { class: 'btn p', type: 'button' }, 'Subir nueva versión');
    up.addEventListener('click', () => busy(up, async () => {
      err.hidden = true;
      const f = file.files[0];
      if (!f) { err.hidden = false; err.textContent = 'Elige un archivo .html o .zip.'; return; }
      progress.hidden = false;
      bar.style.width = '0%';
      try {
        const qs = `filename=${encodeURIComponent(f.name)}&note=${encodeURIComponent(note.value.trim())}`;
        const r = await uploadWithKey(() => uploadFile(`/api/games/${g.id}/versions?${qs}`, f, { onProgress: (p) => { bar.style.width = `${Math.round(p * 100)}%`; } }));
        toast('Nueva versión subida; las anteriores se conservan', 'ok');
        update(r.game);
      } catch (e) { err.hidden = false; err.textContent = errMsg(e); } finally { progress.hidden = true; }
    }));

    return h('div', { class: 'card', style: { marginTop: '12px' } },
      h('h2', null, `Versiones (${g.versions.length})`),
      h('div', { style: { overflowX: 'auto' } }, h('table', null,
        h('thead', null, h('tr', null, h('th', null, 'Versión'), h('th', null, 'Subida'), h('th', null, 'Tipo'), h('th', null, ''))),
        h('tbody', null, rows))),
      h('h3', { style: { marginTop: '16px' } }, 'Actualizar el juego'),
      h('small', null, 'La versión nueva pasa a ser la actual; las anteriores se conservan y puedes volver a ellas. Las salas ya creadas siguen con la versión con la que empezaron.'),
      file, note, err, progress, h('div', { class: 'row b' }, up));
  }

  async function act(path, method, body, okMsg) {
    try { const r = await api(path, { method, body }); toast(okMsg, 'ok'); update(r.game); } catch (e) { toast(errMsg(e), 'bad'); }
  }

  async function delVersion(g, v) {
    if (!(await confirmDialog(`¿Eliminar la versión v${v.n}? No se puede deshacer.`, { title: 'Eliminar versión', okText: 'Eliminar', danger: true }))) return;
    act(`/api/games/${g.id}/versions/${v.n}`, 'DELETE', undefined, `v${v.n} eliminada`);
  }

  // ---------- Asistente de integración ----------
  function integrationCard(g) {
    const out = h('div');
    const btn = h('button', { class: 'btn', type: 'button' }, 'Analizar si puede ser multijugador');
    btn.addEventListener('click', () => busy(btn, async () => {
      fill(out, loadingBox('Analizando…'));
      try {
        const { analysis } = await api(`/api/games/${g.id}/analysis`);
        fill(out, renderAnalysis(g, analysis));
      } catch (e) { fill(out, errorBox(errMsg(e))); }
    }));
    return h('div', { class: 'card', style: { marginTop: '12px' } },
      h('h2', null, 'Asistente de integración multijugador'),
      h('p', { class: 'small' }, 'Lee los archivos de la versión actual (sin ejecutarlos) y te dice qué haría falta para usarla en una sala. Es un análisis aproximado: no promete convertir cualquier juego. Nunca modifica tu versión original: si aplicas cambios, se crea una versión nueva.'),
      btn, out);
  }

  function renderAnalysis(g, a) {
    const [label, kind] = LEVEL[a.level] || ['—', 'off'];
    const accepted = new Set(a.changes.filter((c) => c.auto).map((c) => c.id));
    const list = (items) => h('ul', { class: 'clean' }, items.map((t) => h('li', null, t)));
    const nodes = [
      h('div', { class: 'alert info' },
        h('span', { class: 'badge ' + kind }, label), ' ', a.summary,
        h('br'), h('small', null, `Archivo de entrada: ${a.entry} · ${a.files.count} archivos · ${fmtBytes(a.files.totalSize)} · análisis heurístico`)),
    ];
    if (a.findings.length) nodes.push(h('h3', null, 'Qué detecté'), list(a.findings));
    if (a.externals.length) nodes.push(h('h3', null, 'Recursos externos (necesitan internet)'), list(a.externals));
    if (a.warnings.length) nodes.push(h('h3', null, 'Ojo con esto'), h('div', { class: 'alert warn' }, list(a.warnings.map((w) => w.text))));
    if (a.syncCandidates.length) {
      nodes.push(h('h3', null, 'Posibles puntos de sincronización'),
        list(a.syncCandidates.map((s) => `${s.kind === 'bucle' ? 'Bucle' : 'Jugador'}: ${s.name} (${s.file}${s.line ? `:${s.line}` : ''}) — ${s.hint}`)));
    }
    if (a.changes.length) {
      nodes.push(h('h3', null, 'Cambios que puedo aplicar automáticamente'));
      for (const c of a.changes) {
        const cb = h('input', { type: 'checkbox', checked: true, disabled: c.id === 'inject-sdk' });
        cb.addEventListener('change', () => { if (cb.checked) accepted.add(c.id); else accepted.delete(c.id); });
        nodes.push(h('label', { class: 'check', style: { alignItems: 'flex-start' } }, cb, h('span', null, h('b', null, c.title), h('br'), h('small', null, c.detail))));
      }
      if (a.patchPreview) {
        nodes.push(h('h3', null, `Vista previa de ${a.patchPreview.file} (${a.patchPreview.where})`),
          h('small', null, 'Antes:'), h('pre', null, a.patchPreview.before.join('\n')),
          h('small', null, 'Después:'), h('pre', null, a.patchPreview.after.join('\n')));
      }
      const apply = h('button', { class: 'btn p', type: 'button' }, `Crear versión v${g.versions[g.versions.length - 1].n + 1} con estos cambios`);
      apply.addEventListener('click', async () => {
        const ok = await confirmDialog(
          `Se creará una versión nueva con el SDK añadido.\nTu versión actual (v${a.version}) NO se modifica y podrás volver a ella cuando quieras.\n\nEl SDK solo permite conectarse a la sala; la sincronización de tu juego (posiciones, eventos) sigue siendo trabajo tuyo.`,
          { title: 'Aplicar integración', okText: 'Crear versión' });
        if (!ok) return;
        busy(apply, async () => {
          try {
            const r = await api(`/api/games/${g.id}/integrate`, { method: 'POST', body: { version: a.version, accept: [...accepted] } });
            toast('Versión integrada creada. La original sigue disponible.', 'ok');
            update(r.game);
          } catch (e) { toast(errMsg(e), 'bad'); }
        });
      });
      nodes.push(h('div', { class: 'row b' }, apply));
    }
    if (a.manual.length) {
      nodes.push(h('h3', { style: { marginTop: '16px' } }, 'Lo que tendrás que hacer tú en tu código'));
      for (const m of a.manual) nodes.push(h('div', null, h('b', null, m.title), h('br'), h('small', null, m.detail), h('pre', null, m.code)));
    }
    nodes.push(h('small', null, a.note));
    return h('div', { style: { marginTop: '12px' } }, nodes);
  }

  load();
  return () => { dead = true; };
}
