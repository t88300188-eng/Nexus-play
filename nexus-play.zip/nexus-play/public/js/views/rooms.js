import { h, loadingBox, errorBox, busy, fill } from '../ui.js';
import { api } from '../api.js';
import { errMsg, go, openCreateRoom } from './common.js';

export const STATE_TEXT = { waiting: 'Esperando', starting: 'Iniciando', playing: 'Jugando', closing: 'Cerrando', closed: 'Cerrada' };
export const stateBadge = (s) => h('span', { class: 'badge' + (s === 'playing' ? '' : s === 'closed' || s === 'closing' ? ' off' : ' wait') }, STATE_TEXT[s] || s);

export function roomCard(r) {
  const online = r.players.filter((p) => p.online).length;
  return h('div', { class: 'card' },
    h('p', { class: 'game-title' }, r.name),
    h('small', null, r.game ? r.game.title : '(juego eliminado)'),
    h('div', { class: 'badges' }, stateBadge(r.state), h('span', { class: 'badge off' }, `${r.players.length}/${r.max} jugadores`), h('span', { class: 'badge off' }, `${online} conectado${online === 1 ? '' : 's'}`), r.isHost ? h('span', { class: 'badge' }, 'Anfitrión') : null),
    h('div', { class: 'row b' }, h('span', { class: 'sp' }), h('a', { class: 'btn s p', href: `#/room/${r.id}` }, 'Abrir')));
}

export function roomsView(root) {
  const holder = h('div', null, loadingBox());
  root.append(holder);
  let dead = false;

  async function load() {
    try {
      const [{ rooms }, { games }] = await Promise.all([api('/api/rooms'), api('/api/games')]);
      if (dead) return;
      const code = h('input', { type: 'text', placeholder: 'XXXX-XXXX-XXXX', maxlength: 20, autocapitalize: 'characters', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Código de invitación', style: { textTransform: 'uppercase', letterSpacing: '2px' } });
      const err = h('div', { class: 'alert bad', hidden: true });
      const join = h('button', { class: 'btn p', type: 'button' }, 'Entrar');
      const doJoin = () => busy(join, async () => {
        err.hidden = true;
        const c = code.value.trim();
        if (!c) { err.hidden = false; err.textContent = 'Escribe el código de invitación.'; return; }
        try { const { room } = await api('/api/rooms/join', { method: 'POST', body: { code: c } }); go(`#/room/${room.id}`); }
        catch (e) { err.hidden = false; err.textContent = errMsg(e); }
      });
      join.addEventListener('click', doJoin);
      code.addEventListener('keydown', (e) => { if (e.key === 'Enter') doJoin(); });
      fill(holder, 
        h('div', { class: 'bar' },
          h('div', null, h('h1', null, 'Salas'), h('p', { class: 'sub', style: { margin: '2px 0 0' } }, 'Salas privadas con código de invitación')),
          h('button', { class: 'btn p', type: 'button', onclick: () => openCreateRoom(games) }, '＋ Crear sala')),
        h('div', { class: 'card', style: { margin: '16px 0', maxWidth: '520px' } },
          h('h2', null, 'Unirme con un código'),
          h('div', { class: 'row' }, code, join), err),
        h('h2', null, 'Mis salas activas'),
        h('div', { class: 'grid' }, rooms.length ? rooms.map(roomCard) : h('div', { class: 'empty' }, 'No estás en ninguna sala. Crea una o entra con un código.')));
    } catch (e) {
      if (!dead) fill(holder, errorBox(errMsg(e), () => { fill(holder, loadingBox()); load(); }));
    }
  }
  load();
  return () => { dead = true; };
}

/** Pantalla de entrada por enlace de invitación: #/join/CODIGO */
export function joinView(root, { code }) {
  const box = h('div', { class: 'card', style: { maxWidth: '520px' } }, loadingBox('Entrando a la sala…'));
  root.append(box);
  let dead = false;
  (async () => {
    try {
      const { room } = await api('/api/rooms/join', { method: 'POST', body: { code } });
      if (!dead) go(`#/room/${room.id}`);
    } catch (e) {
      if (dead) return;
      fill(box, 
        h('h2', null, 'No se pudo entrar a la sala'),
        h('div', { class: 'alert bad' }, errMsg(e)),
        h('div', { class: 'row b' }, h('a', { class: 'btn p', href: '#/rooms' }, 'Ir a Salas'), h('a', { class: 'btn', href: '#/' }, 'Inicio')));
    }
  })();
  return () => { dead = true; };
}
