import { h, modal, toast, busy, fmtBytes, timeAgo, put } from '../ui.js';
import { api, ApiError } from '../api.js';

export const SANDBOX = 'allow-scripts allow-pointer-lock allow-modals allow-forms';
export const IFRAME_ALLOW = 'fullscreen; autoplay; gamepad';

export const go = (hash) => { location.hash = hash; };
export const errMsg = (e) => (e instanceof ApiError ? e.message : `Error inesperado: ${e?.message || e}`);

export function thumb(game) {
  if (game.thumbUrl) return h('img', { class: 'thumb', src: game.thumbUrl, alt: '', loading: 'lazy' });
  return h('div', { class: 'thumb', 'aria-hidden': 'true' }, (game.title || '?').trim().charAt(0).toUpperCase());
}

export function gameBadges(g) {
  return h('div', { class: 'badges' },
    h('span', { class: 'badge' + (g.published ? '' : ' wait') }, g.published ? 'Publicado' : 'Borrador'),
    h('span', { class: 'badge off' }, `v${g.version}`),
    h('span', { class: 'badge off' }, g.kind === 'html' ? 'HTML' : g.kind === 'integrated' ? 'ZIP + SDK' : 'ZIP'),
    h('span', { class: 'badge off' }, fmtBytes(g.size)),
    g.integrated ? h('span', { class: 'badge' }, 'SDK') : null);
}

export function gameCard(g, { games } = {}) {
  return h('div', { class: 'card' },
    thumb(g),
    h('p', { class: 'game-title' }, g.title),
    h('small', null, g.mine ? 'Tuyo' : `de ${g.ownerName}`, ` · ${timeAgo(g.updatedAt)}`),
    h('p', { class: 'desc' }, g.description || 'Sin descripción.'),
    gameBadges(g),
    h('div', { class: 'row b' },
      h('button', { class: 'btn s', type: 'button', onclick: () => preview(g) }, 'Probar'),
      h('button', { class: 'btn s p', type: 'button', onclick: () => openCreateRoom(games || [g], g.id) }, 'Crear sala'),
      h('span', { class: 'sp' }),
      g.mine ? h('a', { class: 'btn s ghost', href: `#/games/${g.id}` }, 'Detalles') : null));
}

/** Vista previa en un iframe aislado (sin sala: el SDK no tendrá con quién hablar). */
export async function preview(g, version) {
  let url = g.playUrl && version === undefined ? g.playUrl : null;
  if (!url) {
    try {
      const r = await api(`/api/games/${g.id}/preview${version !== undefined ? `?version=${version}` : ''}`);
      url = r.url;
    } catch (e) { toast(errMsg(e), 'bad'); return; }
  }
  modal((box, api2) => {
    const frame = h('iframe', {
      class: 'game-frame', src: url, sandbox: SANDBOX, allow: IFRAME_ALLOW, referrerpolicy: 'no-referrer', title: g.title,
      style: { height: '60vh' },
    });
    put(box, 
      h('div', { class: 'bar' }, h('h2', { style: { margin: 0 } }, `${g.title} — vista previa`),
        h('button', { class: 'btn s', type: 'button', onclick: () => api2.close() }, 'Cerrar')),
      frame,
      h('small', null, 'Vista previa en solitario: no está conectada a ninguna sala. El juego corre aislado (sin acceso a tus datos de NEXUS PLAY).'));
  }, { wide: true });
}

/** Ventana para crear una sala. `games` = juegos disponibles (publicados o propios). */
export function openCreateRoom(games, preselect) {
  const usable = (games || []).filter((g) => g.published || g.mine);
  if (!usable.length) { toast('Aún no hay juegos disponibles para crear una sala.', 'bad'); return; }
  modal((box, m) => {
    const sel = h('select', null, usable.map((g) => h('option', { value: g.id, selected: g.id === preselect }, `${g.title} (v${g.version})${g.published ? '' : ' — borrador'}`)));
    const name = h('input', { type: 'text', maxlength: 40, placeholder: 'Sala de tus amigos', autocomplete: 'off' });
    const max = h('select', null, [2, 3, 4, 5, 6, 8, 10, 12, 16].map((n) => h('option', { value: n, selected: n === 4 }, `${n} jugadores`)));
    const ttl = h('select', null,
      h('option', { value: '' }, 'Sin caducidad (hasta cerrar la sala)'),
      h('option', { value: '15' }, '15 minutos'), h('option', { value: '60' }, '1 hora'), h('option', { value: '1440' }, '24 horas'));
    const err = h('div', { class: 'alert bad', hidden: true });
    const create = h('button', { class: 'btn p', type: 'button' }, 'Crear sala');
    create.addEventListener('click', () => busy(create, async () => {
      err.hidden = true;
      try {
        const body = { gameId: sel.value, max: Number(max.value) };
        if (name.value.trim()) body.name = name.value.trim();
        if (ttl.value) body.inviteTtlMin = Number(ttl.value);
        const { room } = await api('/api/rooms', { method: 'POST', body });
        m.close();
        toast('Sala creada', 'ok');
        go(`#/room/${room.id}`);
      } catch (e) { err.hidden = false; err.textContent = errMsg(e); }
    }));
    put(box, 
      h('h2', null, 'Crear sala privada'),
      h('label', null, 'Juego'), sel,
      h('label', null, 'Nombre de la sala'), name,
      h('label', null, 'Máximo de jugadores'), max,
      h('label', null, 'Validez de la invitación'), ttl,
      h('small', null, 'Solo entra quien tenga el código o el enlace. Podrás revocarlo cuando quieras.'),
      err,
      h('div', { class: 'row b' }, create, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancelar')));
  });
}
