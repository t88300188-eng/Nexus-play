import { h, busy, toast, promptDialog, fmtBytes } from '../ui.js';
import { api, uploadFile, uploadKey, ApiError } from '../api.js';
import { go, errMsg } from './common.js';

export async function ensureUploadKey(required) {
  if (!required || uploadKey.get()) return true;
  const k = await promptDialog({
    title: 'Clave de subida', label: 'Este servidor pide una clave para subir juegos', type: 'password',
    help: 'La definió quien administra el servidor (variable UPLOAD_KEY).', okText: 'Continuar', maxlength: 100,
  });
  if (!k) return false;
  uploadKey.set(k);
  return true;
}

/** Sube con reintento si el servidor pide (o rechaza) la clave de subida. */
export async function uploadWithKey(fn) {
  try { return await fn(); } catch (e) {
    if (e instanceof ApiError && e.code === 'upload_key_required') {
      uploadKey.set('');
      const k = await promptDialog({
        title: 'Clave de subida', label: 'Clave incorrecta o ausente. Escríbela de nuevo', type: 'password', okText: 'Reintentar', maxlength: 100,
      });
      if (!k) throw e;
      uploadKey.set(k);
      return fn();
    }
    throw e;
  }
}

const q = (o) => Object.entries(o).filter(([, v]) => v !== undefined && v !== '').map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

export function uploadView(root) {
  let limits = null;
  let health = null;
  const title = h('input', { type: 'text', maxlength: 60, placeholder: 'Mi juego', autocomplete: 'off' });
  const desc = h('textarea', { maxlength: 400, placeholder: 'Qué es y cómo se juega (opcional)' });
  const file = h('input', { type: 'file', accept: '.html,.htm,.zip' });
  const thumb = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' });
  const pub = h('input', { type: 'checkbox', checked: true });
  const err = h('div', { class: 'alert bad', hidden: true });
  const bar = h('i');
  const progress = h('div', { class: 'progress', hidden: true }, bar);
  const limitsText = h('p', { class: 'small' }, 'Cargando límites…');
  const submit = h('button', { class: 'btn p', type: 'button' }, 'Validar y subir');

  api('/api/health', { auth: false, quiet: true }).then((hh) => {
    health = hh;
    limits = hh.limits;
    limitsText.textContent = `Límites: HTML hasta ${limits.maxHtmlMb} MB · ZIP hasta ${limits.maxZipMb} MB (${limits.maxUnzippedMb} MB descomprimido) · ${limits.maxUserMb} MB en total por usuario.`;
  }).catch(() => { limitsText.textContent = 'No se pudieron consultar los límites del servidor.'; });

  file.addEventListener('change', () => {
    const f = file.files[0];
    if (f && !title.value.trim()) title.value = f.name.replace(/\.(html?|zip)$/i, '').replace(/[_-]+/g, ' ').slice(0, 60);
  });

  function fail(msg) { err.hidden = false; err.textContent = msg; }

  submit.addEventListener('click', () => busy(submit, async () => {
    err.hidden = true;
    const f = file.files[0];
    const t = title.value.trim();
    if (t.length < 2) return fail('Escribe un título de al menos 2 caracteres.');
    if (!f) return fail('Elige un archivo .html o .zip.');
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    if (!['html', 'htm', 'zip'].includes(ext)) return fail('Solo se admiten archivos .html o .zip.');
    if (limits) {
      const cap = (ext === 'zip' ? limits.maxZipMb : limits.maxHtmlMb) * 1048576;
      if (f.size > cap) return fail(`El archivo pesa ${fmtBytes(f.size)} y el máximo para ${ext === 'zip' ? 'ZIP' : 'HTML'} es ${fmtBytes(cap)}.`);
    }
    const th = thumb.files[0];
    if (th && th.size > 512 * 1024) return fail('La miniatura debe pesar menos de 512 KB.');
    if (!(await ensureUploadKey(health?.uploadKeyRequired))) return;
    progress.hidden = false;
    bar.style.width = '0%';
    try {
      const url = `/api/games?${q({ title: t, description: desc.value.trim(), filename: f.name })}`;
      const { game } = await uploadWithKey(() => uploadFile(url, f, { onProgress: (p) => { bar.style.width = `${Math.round(p * 100)}%`; } }));
      if (th) {
        try { await uploadFile(`/api/games/${game.id}/thumbnail`, th, { method: 'PUT', contentType: th.type || 'image/png' }); }
        catch (e) { toast(`Juego subido, pero la miniatura falló: ${errMsg(e)}`, 'bad'); }
      }
      if (pub.checked) {
        try { await api(`/api/games/${game.id}`, { method: 'PATCH', body: { published: true } }); }
        catch (e) { toast(`Juego subido, pero no se pudo publicar: ${errMsg(e)}`, 'bad'); }
      }
      toast('Juego subido correctamente', 'ok');
      go(`#/games/${game.id}`);
    } catch (e) {
      fail(errMsg(e));
    } finally {
      progress.hidden = true;
    }
  }));

  root.append(
    h('h1', null, 'Subir juego'),
    h('p', { class: 'sub' }, 'Un archivo HTML o un ZIP con todo el proyecto'),
    h('div', { class: 'card', style: { maxWidth: '560px' } },
      h('label', null, 'Título'), title,
      h('label', null, 'Descripción'), desc,
      h('label', null, 'Archivo (.html o .zip)'), file,
      h('small', null, 'El ZIP debe tener index.html en la raíz (o dentro de una única carpeta). Puede incluir CSS, JS, imágenes, audio, fuentes y modelos 3D.'),
      h('label', null, 'Miniatura (opcional, PNG/JPG/WebP, máx. 512 KB)'), thumb,
      h('label', { class: 'check', style: { marginTop: '14px' } }, pub, 'Publicar al subir (visible para todos en este servidor)'),
      limitsText, err, progress,
      h('div', { class: 'row b' }, submit, h('a', { class: 'btn', href: '#/games' }, 'Cancelar'))),
    h('div', { class: 'alert info', style: { maxWidth: '560px' } },
      'Subir un juego no lo hace multijugador. Para jugar en sala, el juego debe usar el SDK de NEXUS PLAY; después de subirlo puedes usar el asistente de integración en su página de detalles.'));
  return () => {};
}
