import { h, modal, toast, busy, confirmDialog, copyText, avatar, loadingBox, fill, put } from '../ui.js';
import { api, session } from '../api.js';
import { RoomLink, goneText } from '../rt.js';
import { GameBridge } from '../bridge.js';
import { state as diagState } from '../diag.js';
import { go, errMsg, SANDBOX, IFRAME_ALLOW } from './common.js';
import { stateBadge } from './rooms.js';

export function roomView(root, { id }) {
  let data = null;
  let loadError = null;
  let dead = false;
  let frame = null;
  let bridge = null;
  let fsBtn = null;
  let reloadTimer = null;
  const link = new RoomLink(id);
  const snap = link.snap;

  const banner = h('div');
  const head = h('div');
  const lobby = h('div');
  const stageBar = h('div');
  const frameWrap = h('div', { class: 'overlay-msg', hidden: true });
  const ended = h('div');
  root.append(banner, head, lobby, stageBar, frameWrap, ended);

  const roomState = () => snap.room?.state ?? data?.state;
  const players = () => (snap.players.length ? snap.players : data?.players ?? []);
  const hostId = () => snap.room?.hostId ?? data?.hostId;
  const meId = () => snap.meId ?? session.user?.id;
  const isHost = () => !!hostId() && hostId() === meId();
  const roomName = () => snap.room?.name ?? data?.name ?? 'Sala';
  const maxPlayers = () => snap.room?.max ?? data?.max;
  const isEnded = () => link.status === 'closed' || link.status === 'unavailable' || roomState() === 'closed';

  // ---------- Datos ----------
  async function loadData() {
    try {
      const r = await api(`/api/rooms/${id}`, { quiet: true });
      if (dead) return;
      data = r.room;
      loadError = null;
    } catch (e) {
      if (dead) return;
      if (e.status === 404 || e.status === 410) loadError = 'La sala no existe o ya no tienes acceso.';
      else loadError = e.message;
    }
    renderAll();
  }
  function scheduleReload() {
    clearTimeout(reloadTimer);
    reloadTimer = setTimeout(loadData, 150);
  }

  // ---------- Render ----------
  function renderAll() {
    if (dead) return;
    renderBanner();
    renderHead();
    renderLobby();
    renderStage();
    renderEnded();
  }

  function connText() {
    const s = link.status;
    if (s === 'connected') return { cls: 'ok', text: `Conectado${link.latency != null ? ` · ${link.latency} ms` : ''}` };
    if (s === 'connecting') return { cls: 'warn', text: 'Conectando…' };
    if (s === 'reconnecting') return { cls: 'warn', text: diagState.backend.ok === false ? 'Sin servidor' : 'Reconectando…' };
    if (s === 'replaced') return { cls: 'warn', text: 'En pausa (otra pestaña)' };
    return { cls: 'bad', text: 'Desconectado' };
  }

  function renderBanner() {
    const s = link.status;
    let node = null;
    if (s === 'connecting' && !data) node = null;
    else if (s === 'connecting') node = h('div', { class: 'alert info' }, 'Conectando con la sala…');
    else if (s === 'reconnecting') {
      const down = diagState.backend.ok === false;
      node = h('div', { class: 'alert warn', role: 'alert' },
        h('b', null, down ? 'No hay conexión con el servidor. ' : 'Se perdió la conexión con la sala. '),
        `Reconectando automáticamente… (intento ${link.attempt || 1}). `,
        'Tu lugar se conserva mientras la sala siga activa.',
        link.attempt >= 3 ? ' Si tarda mucho, revisa tu Wi-Fi o datos móviles; el servidor puede estar apagado.' : '',
        h('div', { class: 'row b' }, h('button', { class: 'btn s', type: 'button', onclick: () => location.reload() }, 'Recargar la página'), h('a', { class: 'btn s', href: '#/diag' }, 'Diagnóstico')));
    } else if (s === 'replaced') {
      node = h('div', { class: 'alert warn', role: 'alert' },
        'Abriste esta sala en otra pestaña o dispositivo, así que esta quedó en pausa. ',
        h('div', { class: 'row b' }, h('button', { class: 'btn s p', type: 'button', onclick: () => location.reload() }, 'Usar esta pestaña')));
    }
    fill(banner, ...(node ? [node] : []));
  }

  function renderHead() {
    const c = connText();
    const st = roomState();
    fill(head, 
      h('div', { class: 'room-head' },
        h('div', null,
          h('h1', null, roomName()),
          h('div', { class: 'row wrap' }, data?.game ? h('small', null, data.game.title) : null, st ? stateBadge(st) : null, isHost() ? h('span', { class: 'badge' }, 'Anfitrión') : null)),
        h('div', { class: 'conn', title: 'Estado de la conexión de la sala' }, h('span', { class: 'dot ' + c.cls }), h('span', null, c.text))));
  }

  function playerRow(p, canKick) {
    const me = p.id === meId();
    return h('div', { class: 'pl' },
      avatar(p),
      h('div', { class: 'sp' }, h('div', null, p.name, me ? ' (tú)' : '', p.host ? h('span', { class: 'badge', style: { marginLeft: '6px' } }, '★ anfitrión') : null),
        h('small', null, h('span', { class: 'dot ' + (p.online ? 'ok' : ''), style: { marginRight: '5px' } }), p.online ? 'conectado' : 'desconectado')),
      canKick && !me ? h('button', { class: 'btn s d', type: 'button', onclick: () => kick(p) }, 'Expulsar') : null);
  }

  function renderLobby() {
    const st = roomState();
    if (loadError || !data || st !== 'waiting' || isEnded()) { fill(lobby, ...(data || loadError ? [] : [loadingBox('Cargando sala…')])); return; }
    const host = isHost();
    const list = players();
    const cap = maxPlayers();

    const left = h('div', { class: 'card' });
    if (host) {
      const inv = data.invite;
      if (!inv) put(left, h('h2', null, 'Invitación'), loadingBox('Cargando invitación…'));
      else {
        const link2 = `${location.origin}/#/join/${inv.code}`;
        const dead2 = inv.revoked || inv.expired;
        const ttl = h('select', { 'aria-label': 'Validez del nuevo código' },
          h('option', { value: '' }, 'Sin caducidad'), h('option', { value: '15' }, '15 min'), h('option', { value: '60' }, '1 hora'), h('option', { value: '1440' }, '24 horas'));
        put(left, 
          h('h2', null, 'Invitación'),
          h('div', { class: 'code' + (dead2 ? ' dead' : '') }, inv.code),
          h('p', { class: 'mono' }, link2),
          dead2 ? h('div', { class: 'alert bad' }, inv.revoked ? 'Código revocado: ya no sirve para entrar.' : 'La invitación expiró. Genera un código nuevo.') :
            (inv.expiresAt ? h('small', null, `Caduca ${new Date(inv.expiresAt).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' })}`) : null),
          h('div', { class: 'row wrap', style: { marginTop: '10px' } },
            h('button', { class: 'btn s', type: 'button', disabled: dead2, onclick: () => copy(inv.code, 'Código copiado') }, 'Copiar código'),
            h('button', { class: 'btn s', type: 'button', disabled: dead2, onclick: () => copy(link2, 'Enlace copiado') }, 'Copiar enlace'),
            navigator.share && !dead2 ? h('button', { class: 'btn s', type: 'button', onclick: () => navigator.share({ title: 'NEXUS PLAY', text: `Únete a mi sala "${roomName()}"`, url: link2 }).catch(() => {}) }, 'Compartir') : null),
          h('div', { class: 'row wrap', style: { marginTop: '10px' } },
            h('button', { class: 'btn s d', type: 'button', disabled: inv.revoked, onclick: () => invite('revoke') }, 'Revocar'),
            h('button', { class: 'btn s', type: 'button', onclick: () => invite('regenerate', ttl.value) }, 'Código nuevo'), ttl),
          h('small', { style: { marginTop: '8px', display: 'block' } }, 'Revocar o generar uno nuevo invalida el anterior. Quien ya está dentro no sale.'));
      }
    } else {
      put(left, h('h2', null, 'Esperando al anfitrión'), h('p', { class: 'mut' }, 'El anfitrión iniciará la partida cuando todos estén listos. Mientras tanto puedes quedarte aquí.'));
    }

    const right = h('div', { class: 'card' },
      h('h2', null, `Jugadores (${list.length}/${cap ?? '?'})`),
      list.map((p) => playerRow(p, host)));

    const controls = h('div', { class: 'card', style: { marginTop: '12px' } }, h('h2', null, 'Partida'));
    if (host) {
      const start = h('button', { class: 'btn p', type: 'button', disabled: link.status !== 'connected' }, 'Iniciar partida');
      start.addEventListener('click', () => busy(start, () => setState('starting')));
      const nameIn = h('input', { type: 'text', maxlength: 40, value: roomName(), 'aria-label': 'Nombre de la sala' });
      const maxSel = h('select', { 'aria-label': 'Máximo de jugadores' }, [2, 3, 4, 5, 6, 8, 10, 12, 16].map((n) => h('option', { value: n, selected: n === cap }, `${n} jugadores`)));
      const save = h('button', { class: 'btn s', type: 'button' }, 'Guardar ajustes');
      save.addEventListener('click', () => busy(save, async () => {
        try { const r = await api(`/api/rooms/${id}/settings`, { method: 'POST', body: { name: nameIn.value, max: Number(maxSel.value) } }); data = r.room; toast('Ajustes guardados', 'ok'); renderAll(); } catch (e) { toast(errMsg(e), 'bad'); }
      }));
      put(controls, 
        h('div', { class: 'row wrap' }, start, h('button', { class: 'btn d', type: 'button', onclick: closeRoom }, 'Cerrar sala')),
        link.status !== 'connected' ? h('small', null, 'Espera a que la conexión esté activa para iniciar.') : null,
        h('div', { class: 'two', style: { marginTop: '12px' } }, h('div', null, h('label', null, 'Nombre'), nameIn), h('div', null, h('label', null, 'Máximo'), maxSel)),
        h('div', { class: 'row b' }, save));
    } else {
      put(controls, h('div', { class: 'row wrap' }, h('button', { class: 'btn', type: 'button', onclick: leave }, 'Salir de la sala')));
    }
    if (host) put(controls, h('div', { class: 'row b' }, h('button', { class: 'btn s ghost', type: 'button', onclick: leave }, 'Salir de la sala (el rol pasa a otro jugador)')));

    fill(lobby, h('div', { class: 'two' }, left, right), controls);
  }

  // ---------- Escenario del juego ----------
  function renderStage() {
    const st = roomState();
    const want = !isEnded() && (st === 'starting' || st === 'playing') && data?.game;
    if (want && !frame) createFrame();
    if (!want && frame) destroyFrame();
    if (!want) { fill(stageBar, ); frameWrap.hidden = true; return; }
    const host = isHost();
    fill(stageBar, h('div', { class: 'row wrap', style: { marginBottom: '8px' } },
      h('div', { class: 'row wrap sp' }, players().map((p) => h('span', { class: 'badge ' + (p.online ? '' : 'off'), title: p.online ? 'conectado' : 'desconectado' }, (p.host ? '★ ' : '') + p.name))),
      h('button', { class: 'btn s', type: 'button', onclick: toggleFull }, 'Pantalla completa'),
      host ? h('button', { class: 'btn s', type: 'button', onclick: () => setState('waiting') }, 'Volver a la sala') : null,
      host ? h('button', { class: 'btn s d', type: 'button', onclick: closeRoom }, 'Cerrar sala') : null,
      h('button', { class: 'btn s ghost', type: 'button', onclick: leave }, 'Salir')));
    let cover = frameWrap.querySelector('.cover');
    let msg = null;
    if (link.status !== 'connected') msg = 'Reconectando con la sala…';
    else if (st === 'starting') msg = 'Cargando el juego… la partida empieza cuando todos estén listos.';
    if (msg) {
      if (!cover) { cover = h('div', { class: 'cover' }); frameWrap.append(cover); }
      cover.textContent = msg;
    } else if (cover) cover.remove();
  }

  function createFrame() {
    frame = h('iframe', { class: 'game-frame', sandbox: SANDBOX, allow: IFRAME_ALLOW, referrerpolicy: 'no-referrer', title: data.game.title });
    bridge = new GameBridge(frame, link, { onLeave: leave });
    frame.addEventListener('load', () => link.send({ t: 'ready' }));
    frame.src = data.game.playUrl;
    fill(frameWrap, frame);
    frameWrap.hidden = false;
  }

  function destroyFrame() {
    bridge?.destroy();
    bridge = null;
    frame?.remove();
    frame = null;
    fsOff();
    fill(frameWrap, );
    frameWrap.hidden = true;
  }

  function toggleFull() {
    if (!frame) return;
    if (frame.classList.contains('full')) { fsOff(); return; }
    frame.classList.add('full');
    fsBtn = h('button', { class: 'btn s', type: 'button', style: { position: 'fixed', top: '8px', left: '8px', zIndex: '70' }, onclick: fsOff }, '✕ Salir de pantalla completa');
    document.body.append(fsBtn);
  }
  function fsOff() { frame?.classList.remove('full'); fsBtn?.remove(); fsBtn = null; }

  function renderEnded() {
    if (loadError && !data) {
      fill(ended, h('div', { class: 'card', style: { maxWidth: '520px' } },
        h('h2', null, 'Sala no disponible'), h('div', { class: 'alert bad' }, loadError),
        h('div', { class: 'row b' }, h('a', { class: 'btn p', href: '#/rooms' }, 'Ir a Salas'), h('button', { class: 'btn', type: 'button', onclick: () => { loadError = null; loadData(); } }, 'Reintentar'))));
      return;
    }
    if (link.status === 'closed' || link.status === 'unavailable' || roomState() === 'closed') {
      const reason = link.reason || (roomState() === 'closed' ? 'room_closed' : 'gone');
      fill(ended, h('div', { class: 'card', style: { maxWidth: '520px', marginTop: '12px' } },
        h('h2', null, 'La partida terminó'), h('p', null, goneText(reason)),
        h('div', { class: 'row b' }, h('a', { class: 'btn p', href: '#/rooms' }, 'Volver a Salas'), h('a', { class: 'btn', href: '#/games' }, 'Biblioteca'))));
    } else fill(ended, );
  }

  // ---------- Acciones ----------
  async function copy(text, msg) {
    const ok = await copyText(text);
    toast(ok ? msg : 'No se pudo copiar; selecciona el texto manualmente.', ok ? 'ok' : 'bad');
  }

  async function setState(next) {
    try { const r = await api(`/api/rooms/${id}/state`, { method: 'POST', body: { state: next } }); data = r.room; renderAll(); } catch (e) { toast(errMsg(e), 'bad'); }
  }

  async function closeRoom() {
    if (!(await confirmDialog('¿Cerrar la sala para todos? La partida terminará.', { title: 'Cerrar sala', okText: 'Cerrar sala', danger: true }))) return;
    await setState('closing');
  }

  async function leave() {
    if (!(await confirmDialog('¿Salir de la sala?' + (isHost() ? '\nEl rol de anfitrión pasará a otro jugador.' : ''), { title: 'Salir', okText: 'Salir' }))) return;
    try { await api(`/api/rooms/${id}/leave`, { method: 'POST' }); } catch (e) { if (e.status !== 404) { toast(errMsg(e), 'bad'); return; } }
    go('#/rooms');
  }

  async function kick(p) {
    if (!(await confirmDialog(`¿Expulsar a ${p.name}? No podrá volver a entrar a esta sala.`, { title: 'Expulsar jugador', okText: 'Expulsar', danger: true }))) return;
    try { const r = await api(`/api/rooms/${id}/kick`, { method: 'POST', body: { userId: p.id } }); data = r.room; renderAll(); toast(`${p.name} fue expulsado`, 'ok'); } catch (e) { toast(errMsg(e), 'bad'); }
  }

  async function invite(action, ttl) {
    try { const r = await api(`/api/rooms/${id}/invite`, { method: 'POST', body: { action, ttlMin: ttl ? Number(ttl) : undefined } }); data = r.room; renderAll(); toast(action === 'revoke' ? 'Invitación revocada' : 'Código nuevo generado', 'ok'); } catch (e) { toast(errMsg(e), 'bad'); }
  }

  // ---------- Conexión en tiempo real ----------
  link.on('status', () => renderAll());
  link.on('latency', () => renderHead());
  link.on('msg', (m) => {
    if (m.t === 'room') {
      const changed = !data || data.state !== m.room.state || data.hostId !== m.room.hostId || data.max !== m.room.max || data.name !== m.room.name;
      if (changed) scheduleReload();
    }
    if (m.t === 'hello' && !data) scheduleReload();
    renderAll();
  });

  renderAll();
  loadData();
  link.start();

  return () => {
    dead = true;
    clearTimeout(reloadTimer);
    link.stop();
    bridge?.destroy();
    fsOff();
  };
}
