import { h, loadingBox, toast, copyText, busy, clock, timeAgo, fill } from '../ui.js';
import { api, pingBackend } from '../api.js';
import { state, clientLog, buildReport, onChange } from '../diag.js';
import { errMsg } from './common.js';

const kv = (label, value, cls) => h('tr', null, h('td', { class: 'mut' }, label), h('td', null, cls ? h('span', { class: 'badge ' + cls }, value) : value));
const card = (title, rows) => h('div', { class: 'card' }, h('h2', null, title), h('table', null, h('tbody', null, rows)));
const wsText = { idle: 'Sin sala abierta', connecting: 'Conectando', connected: 'Conectado', reconnecting: 'Reconectando', closed: 'Sala cerrada', unavailable: 'No disponible', replaced: 'En pausa (otra pestaña)' };

export function diagnosticsView(root) {
  const holder = h('div', null, loadingBox());
  root.append(holder);
  let dead = false;
  let server = null;
  let serverError = null;

  async function refresh() {
    await pingBackend();
    try { server = await api('/api/diagnostics', { quiet: true }); serverError = null; } catch (e) { serverError = errMsg(e); }
    if (!dead) paint();
  }

  function paint() {
    const b = state.backend;
    const w = state.ws;
    const cards = [];
    cards.push(card('Conexión con el servidor', [
      kv('Estado', b.ok === null ? 'Sin comprobar' : b.ok ? 'Responde' : 'Sin respuesta', b.ok ? '' : 'bad'),
      kv('Latencia HTTP', b.latencyMs != null ? `${b.latencyMs} ms` : '—'),
      kv('Última comprobación', timeAgo(b.lastCheck)),
      b.lastError ? kv('Último error', b.lastError) : null,
    ]));
    cards.push(card('Multijugador (WebSocket)', [
      kv('Estado', wsText[w.status] || w.status, w.status === 'connected' ? '' : w.status === 'idle' ? 'off' : 'wait'),
      kv('Latencia', w.latencyMs != null ? `${w.latencyMs} ms` : w.status === 'idle' ? 'Abre una sala para medirla' : '—'),
      kv('Reconexiones', String(w.reconnects)),
      w.lastClose ? kv('Último cierre', w.lastClose) : null,
      kv('Soporte del navegador', 'WebSocket' in window ? 'Disponible' : 'NO disponible', 'WebSocket' in window ? '' : 'bad'),
    ]));
    if (server) {
      const s = server;
      cards.push(card('Salas y jugadores', [
        kv('Salas activas', String(s.rooms.active)),
        kv('Por estado', Object.entries(s.rooms.byState).filter(([k]) => k !== 'closed').map(([k, v]) => `${k}: ${v}`).join(' · ') || '—'),
        kv('Jugadores conectados', String(s.rooms.playersOnline)),
        kv('Conexiones WebSocket', String(s.realtime.connections)),
        kv('Mensajes inválidos / limitados', `${s.realtime.invalid} / ${s.realtime.rateLimited}`),
      ]));
      cards.push(card('Almacenamiento', [
        kv('Carpeta de datos escribible', s.storage.dataDirWritable ? 'Sí' : 'NO', s.storage.dataDirWritable ? '' : 'bad'),
        kv('Último guardado', s.storage.lastSaveAt ? timeAgo(s.storage.lastSaveAt) : 'Aún no hay cambios'),
        s.storage.lastError ? kv('Error al guardar', s.storage.lastError.message, 'bad') : null,
        s.storage.recoveredFrom ? kv('Recuperado desde', s.storage.recoveredFrom, 'wait') : null,
        kv('Juegos en disco', `${s.storage.gamesMb} MB`),
        kv('Espacio libre', s.storage.freeMb != null ? `${s.storage.freeMb} MB` : 'No disponible'),
        kv('Tu cuota', `${s.games.mineMb} / ${s.games.quotaMb} MB`),
      ]));
      cards.push(card('Servidor', [
        kv('Versión', s.server.version), kv('Node', `${s.server.node} (${s.server.platform}/${s.server.arch})`),
        kv('Activo desde hace', `${Math.round(s.server.uptimeSec / 60)} min`), kv('Memoria', `${s.server.rssMb} MB`),
      ]));
    }
    const problems = [];
    if (server) {
      for (const e of server.games.recentErrors) problems.push({ ts: e.ts, src: 'Carga de juegos', msg: e.message });
      for (const e of server.realtime.lastErrors) problems.push({ ts: e.ts, src: 'Comunicación', msg: `${e.kind}: ${e.message}` });
      if (server.storage.lastError) problems.push({ ts: server.storage.lastError.at, src: 'Almacenamiento', msg: server.storage.lastError.message });
    }
    for (const e of clientLog.filter((x) => x.level !== 'info')) problems.push({ ts: e.ts, src: 'Navegador', msg: e.message });
    problems.sort((a, c) => c.ts - a.ts);

    const logs = [...(server?.logs || []).map((e) => ({ ts: e.ts, level: e.level, text: `[servidor] ${e.event} ${Object.keys(e.data).length ? JSON.stringify(e.data) : ''}` })),
      ...clientLog.map((e) => ({ ts: e.ts, level: e.level, text: `[navegador] ${e.message}` }))].sort((a, c) => c.ts - a.ts).slice(0, 80);

    const copyBtn = h('button', { class: 'btn p', type: 'button' }, 'Copiar informe');
    copyBtn.addEventListener('click', () => busy(copyBtn, async () => {
      const ok = await copyText(buildReport(server));
      toast(ok ? 'Informe copiado (sin contraseñas ni tokens)' : 'No se pudo copiar automáticamente', ok ? 'ok' : 'bad');
    }));

    fill(holder, 
      h('div', { class: 'bar' },
        h('div', null, h('h1', null, 'Diagnóstico'), h('p', { class: 'sub', style: { margin: '2px 0 0' } }, 'Datos reales del navegador y del servidor')),
        h('div', { class: 'row wrap' }, h('button', { class: 'btn', type: 'button', onclick: refresh }, 'Actualizar'), copyBtn)),
      serverError ? h('div', { class: 'alert bad' }, `No se pudo consultar el servidor: ${serverError}`) : null,
      h('div', { class: 'grid' }, cards),
      h('h2', null, `Errores recientes (${problems.length})`),
      problems.length ? h('div', { class: 'log' }, problems.slice(0, 40).map((p) => h('div', { class: 'e' }, `${clock(p.ts)} · ${p.src}: ${p.msg}`))) : h('div', { class: 'alert ok' }, 'Sin errores recientes.'),
      h('h2', { style: { marginTop: '18px' } }, 'Registro de eventos'),
      h('div', { class: 'log' }, logs.length ? logs.map((l) => h('div', { class: l.level === 'error' ? 'e' : l.level === 'warn' ? 'w' : '' }, `${clock(l.ts)} ${l.text}`)) : 'Sin eventos.'));
  }

  const off = onChange(() => { if (!dead && server) paint(); });
  refresh();
  const timer = setInterval(refresh, 8000);
  return () => { dead = true; clearInterval(timer); off(); };
}
