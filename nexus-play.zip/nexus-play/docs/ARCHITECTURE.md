# Arquitectura

Monolito modular en Node (ESM). Un proceso, un puerto: API HTTP + WebSocket + archivos estáticos + juegos.

```
server/
  index.js      arranque, candado de datos (PID), señales de cierre
  app.js        Express: rutas, CSP, límites, manejo de errores
  config.js     configuración desde entorno
  store.js      almacén JSON (escritura atómica, .bak, recuperación)
  auth.js       sesiones de invitado (hash SHA-256 del token)
  games.js      biblioteca, versiones, subida, vista previa firmada, integración
  zipsafe.js    validación y extracción segura de ZIP
  analyzer.js   análisis heurístico y adaptación (inyección del SDK)
  rooms.js      salas, invitaciones, máquina de estados, mantenimiento
  realtime.js   WebSocket: tickets, límites, difusión, presencia
  ratelimit.js  ventana deslizante y token bucket
public/         panel (JS vanilla ES modules, sin build) + SDK
examples/       juego demo
scripts/        backup / restore
tests/          node:test + Playwright
```

## Decisiones
- **JSON atómico en vez de SQLite:** cero módulos nativos (Termux). Límite: un solo proceso y volumen pequeño. Migrable (capa `Store` aislada).
- **Juegos aislados:** se sirven en `/g/...` con `Content-Security-Policy: sandbox ...` y se incrustan en `<iframe sandbox="allow-scripts ...">` **sin `allow-same-origin`** → origen opaco, sin acceso al panel, tokens ni almacenamiento.
- **Versiones inmutables** (`data/games/<id>/v<N>/`): integrar o subir nunca pisa la anterior.
- **Servidor como relé, no autoritativo:** valida forma, tamaño y ritmo, y reenvía. La lógica de juego vive en los clientes (el anfitrión puede fijar estado compartido).
- **Sin cookies:** `Authorization: Bearer` → sin CSRF.
- **Tickets WebSocket** de un solo uso (30 s) para no poner el token en la URL.
- **Presencia y estado en memoria;** sala, miembros e invitación persisten.

## Datos en disco
`data/db.json` (+`.bak`), `data/games/`, `data/.secret` (HMAC de vistas previas), `data/.lock`, `data/tmp/` (se vacía al iniciar).

## Máquina de estados de sala
`waiting → starting → playing → (waiting) → closing → closed`. `starting` pasa a `playing` cuando todos los conectados avisan `ready` o a los 8 s. Salas inactivas (15 min sin nadie), vencidas (4 h) o sin miembros se cierran; las cerradas se purgan a las 24 h.
