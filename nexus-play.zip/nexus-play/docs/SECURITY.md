# Seguridad

## Modelo
Cualquiera con acceso a la red puede crear una sesión de invitado y **subir código que se ejecutará en el navegador de otros**. Por eso el código subido se trata como hostil.

## Controles implementados (verificados por pruebas)
- **Aislamiento:** iframe `sandbox` sin `allow-same-origin` + cabecera CSP `sandbox` en cada archivo de juego (si abren la URL directa, también aislado). El panel no es accesible desde el juego (probado con navegador real).
- **ZIP:** lista blanca de extensiones; rechaza `..`, rutas absolutas/Windows, enlaces simbólicos, duplicados, cifrados, demasiados archivos/profundidad, tamaños declarados mentirosos (cuenta bytes al extraer), bombas de compresión, ZIP corruptos; ignora `__MACOSX` y archivos ocultos; no queda nada en disco si se rechaza.
- **Límites:** tamaño por archivo/total/usuario, juegos y versiones, salas, conexiones, mensajes, peticiones por IP, sesiones por hora, intentos de código por IP.
- **Sesiones:** token aleatorio; solo se guarda su hash SHA-256; cabecera Bearer (sin cookies → sin CSRF).
- **Invitaciones:** 12 caracteres sin ambiguos (~60 bits), validadas en servidor, revocables, regenerables, con caducidad; respuesta 404 genérica ante códigos inválidos.
- **WebSocket:** ticket de un solo uso de 30 s, comprobación de `Origin`, validación de cada mensaje, token bucket, cierre ante abuso.
- **Vistas previas de borradores:** URL firmada HMAC con caducidad (2 h) ligada al juego/versión.
- **Panel:** CSP estricta (`default-src 'self'`, `frame-ancestors 'none'`), `nosniff`, `X-Frame-Options`; la interfaz no usa `innerHTML` con datos de usuario.
- **Privacidad de datos:** los borradores y versiones solo los ve su dueño (404 para el resto); el diagnóstico no incluye tokens ni códigos.
- **Datos:** escritura atómica, copia `.bak`, recuperación de `db.json` corrupto (se conserva como evidencia), candado contra dos procesos.

## Límites conocidos / riesgos aceptados
- **Sin cuentas:** perder el token (borrar datos del navegador) = perder la identidad y el acceso a tus juegos. Alguien con tu token es tú.
- **Sin HTTPS propio:** en `http://` el tráfico (incluido el token) es legible en la red local. Para Internet usa HTTPS (túnel/proxy).
- **Un juego sandboxeado puede** consumir CPU/memoria del navegador del jugador, mostrar contenido engañoso o cargar recursos externos (el sandbox sin `allow-same-origin` no impide peticiones de red salientes). No hay moderación de contenido.
- `allow-modals` permite `alert()` en bucle (molestia, no robo de datos).
- El análisis del asistente es heurístico, no un antivirus.
- Limitación de ritmo por IP: detrás de un NAT compartido (colegio) varias personas comparten cupo; ajusta los límites en `.env`.
- Sin auditoría externa. No lo expongas a Internet abierto sin `UPLOAD_KEY` y HTTPS.

## Reportar / endurecer
Define `UPLOAD_KEY`, `HOST=127.0.0.1` detrás de un proxy con `TRUST_PROXY=true`, y reduce `MAX_USER_MB`/`MAX_GAMES_PER_USER` si es público.
