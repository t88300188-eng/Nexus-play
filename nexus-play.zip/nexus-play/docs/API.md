# API HTTP

Todo bajo `/api`. JSON salvo subidas (cuerpo binario). Autenticación: `Authorization: Bearer <token>` (excepto `health` y `session`). Errores: `{ "error": { "code", "message" } }`.

| Método y ruta | Descripción |
|---|---|
| `GET /health` | Estado, versión, límites, si exige clave de subida |
| `POST /session` `{name}` | Crea sesión de invitado → `{token, user}` (201) |
| `GET/PATCH /me` | Ver / cambiar nombre |
| `GET /games` | Publicados + propios |
| `POST /games?title&description&filename` | Sube HTML/ZIP (cuerpo = archivo; cabecera `X-Upload-Key` si se exige) → borrador v1 |
| `GET /games/:id` | Detalle (versiones solo para el dueño) |
| `PATCH /games/:id` `{title,description,published}` | Editar/publicar (dueño) |
| `DELETE /games/:id` | Eliminar (dueño; 409 si hay sala activa) |
| `POST /games/:id/versions?filename&note` | Nueva versión |
| `POST /games/:id/current` `{version}` | Elegir versión actual |
| `DELETE /games/:id/versions/:n` | Eliminar versión (no la actual) |
| `PUT/GET/DELETE /games/:id/thumbnail` | Miniatura (PNG/JPEG/WebP ≤512 KB) |
| `GET /games/:id/preview?version=` | URL firmada (2 h) para probar un borrador |
| `GET /games/:id/analysis` | Análisis heurístico |
| `POST /games/:id/integrate` `{version?,accept:[ids]}` | Crea versión nueva con el SDK; original intacta |
| `GET /rooms` | Mis salas activas |
| `POST /rooms` `{gameId,name?,max?,inviteTtlMin?}` | Crear sala |
| `POST /rooms/join` `{code}` | Unirse (código sin distinguir mayúsculas/guiones) |
| `GET /rooms/:id` | Ver sala (solo miembros) |
| `POST /rooms/:id/leave` · `/state {state}` · `/invite {action:revoke\|regenerate,ttlMin?}` · `/kick {userId}` · `/settings {name?,max?}` | Gestión (estado, invitación, expulsión y ajustes: anfitrión) |
| `POST /rooms/:id/ticket` | Ticket de un solo uso para el WebSocket |
| `GET /diagnostics` | Diagnóstico sin secretos |

Otras rutas: `/g/:gid/:ver/*` (juego publicado o con sala activa), `/gp/<token>/*` (vista previa firmada), `/ws` (WebSocket).

Códigos habituales: 400 validación · 401 sin sesión · 403 sin permiso/expulsado/invitación revocada · 404 no existe (también si no puedes verlo) · 409 conflicto/estado/cuota · 410 sala cerrada/vencida · 413 demasiado grande · 429 límite de ritmo (`Retry-After`).
