# Hoja de ruta

## Hecho (v0.2.0)
Biblioteca con versiones, salas privadas, WebSocket, SDK, demo, asistente, diagnóstico, respaldo/restauración, pruebas.

## Siguiente (propuesto, sin fechas)
1. **Validar en dispositivos reales** (Android + PC) y corregir lo que aparezca.
2. PWA real: `service worker` para instalar y abrir sin pantalla de navegador (hoy solo hay `manifest`).
3. Cuentas opcionales (correo/código) para no perder la identidad.
4. Chat de sala y emojis rápidos en el panel.
5. Persistencia de resultados/puntajes por sala (API en el SDK).
6. Migrar el almacén a SQLite cuando haya una opción sin compilación nativa estable en Termux (`node:sqlite`) o si crece el volumen.
7. Moderación: reportar juegos, retirar juegos, lista de bloqueo.
8. Mejor análisis del asistente (más patrones, plantillas por tipo de juego).
9. Modo espectador y salas públicas.
10. Despliegue en Internet con HTTPS y guía verificada.

## Fuera de alcance por ahora
Servidor autoritativo por juego, matchmaking, voz/vídeo, pagos.
