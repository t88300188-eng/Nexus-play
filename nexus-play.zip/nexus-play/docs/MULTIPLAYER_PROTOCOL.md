# Protocolo multijugador v1

1. `POST /api/rooms/:id/ticket` → `{ticket}` (válido 30 s, **un solo uso**).
2. Abrir `ws(s)://host/ws?t=<ticket>`. Si hay cabecera `Origin`, debe coincidir con `Host` (si no: cierre 4010).
3. El servidor responde `hello`.

Mensajes JSON con `{"v":1,"t":tipo,...}`; solo texto (binario → error). Máx. 8 KB por mensaje (16 KB cierra con 1009).

## Cliente → servidor
| t | Campos | Notas |
|---|---|---|
| `ping` | `ts` | responde `pong` con el mismo `ts` |
| `ready` | | el juego cargó (acelera `starting → playing`) |
| `ev` | `n` nombre `[A-Za-z0-9_.:-]{1,32}`, `d` datos, `to?` id | a todos menos el emisor, o a uno |
| `st` | `d` objeto ≤2 KB | tu estado; se guarda y se reenvía |
| `sh` | `k` clave, `d` valor ≤4 KB (`null` borra) | **solo anfitrión**; total ≤32 KB |

`ev/st/sh` solo se aceptan con la sala en `waiting`, `starting` o `playing`.

## Servidor → cliente
`hello {you, room, players, states, shared, serverTime}` · `players {list, change:{type:join|leave|kick|online|offline,id}}` · `room {room, players}` · `ev {n,d,from}` · `st {from,d}` · `sh {k,d}` · `pong` · `err {code,message}` · `bye {reason}`.

Códigos de error: `bad_json, bad_message, bad_version, unknown_type, bad_ping, bad_event_name, bad_data, bad_target, bad_state, bad_key, forbidden, too_large, state_too_large, value_too_large, shared_full, binary_not_allowed, rate_limited`.

## Cierres
1001 servidor apagándose · 1009 mensaje enorme · 1013 servidor/IP saturados · 4001 sala cerrada · 4002 no es miembro · 4003 reemplazada por otra conexión · 4004 ticket inválido/caducado · 4005 expulsado · 4006 salió · 4008 abuso de ritmo/errores · 4010 origen inválido.

## Límites
Token bucket 40 msg/s (ráfaga 80); >200 descartes → 4008; 20 mensajes inválidos seguidos → 4008; heartbeat 20 s; cliente lento (>2 MB en cola) se corta; conexiones por IP 30, globales 300.

## Reconexión
El cliente del panel reconecta con backoff y pide ticket nuevo; el nuevo `hello` trae los estados y el compartido vigentes. En `waiting`, un jugador desconectado >45 s pierde su sitio; si el anfitrión falta >90 s el rol pasa a otro conectado.
