# Despliegue

## 1. Red local (recomendado para empezar, costo 0)
`npm start` en Termux o en cualquier PC con Node ≥ 22; los demás entran por `http://<IP-local>:3000`. Ver [TERMUX.md](TERMUX.md).

## 2. Variables
Ver `.env.example`. Con systemd/pm2/tmux: exporta las variables antes de `node server/index.js`.

## 3. Internet (opcional, no probado por mí)
El servidor necesita un proceso Node persistente con **WebSocket** y **disco escribible**; muchos hostings gratuitos no los dan o duermen el proceso, **y no he verificado cuotas ni condiciones de ninguno**. Opciones a evaluar tú: túnel (p. ej. Cloudflare Tunnel o similar) desde el celular/PC, o una VPS barata.

Con proxy inverso:
- Reenvía `Upgrade`/`Connection` para `/ws`.
- Aumenta el límite de cuerpo (subidas hasta `MAX_ZIP_MB`).
- Conserva `Host` y `Origin` coherentes (el servidor compara `Origin` con `Host`).
- Pon `TRUST_PROXY=true` solo si el proxy es de confianza (para ver la IP real).
- Sirve por HTTPS.

## 4. Datos y respaldo
Todo está en `DATA_DIR` (por defecto `./data`). `npm run backup` periódicamente (puedes programarlo con cron/termux-job-scheduler). Restaurar: ver TERMUX.md.

## 5. Actualizar
Detén el servidor, haz backup, reemplaza el código (no toques `data/`), `npm install`, inicia. Si cambia `db.json`, el CHANGELOG lo dirá.
