# Guía del SDK (v1.0.0)

El juego corre dentro de un iframe aislado y **no ve el servidor ni tokens**: el SDK habla con el panel por `postMessage` y el panel valida y reenvía.

## Uso mínimo
```html
<script src="nexus-sdk.js"></script>
<script>
(async () => {
  let nexus;
  try { nexus = await NexusPlay.connect(); }
  catch (e) { /* e.code === 'not_embedded' → modo individual */ }
  if (!nexus) return;
  const remotos = {};
  nexus.on('state', (id, estado) => { remotos[id] = estado; });
  nexus.on('event:disparo', (data, jugador) => { /* ... */ });
  nexus.ready();                       // opcional: el juego ya cargó
  setInterval(() => nexus.setState({ x, y }), 50);
})();
</script>
```
El SDK se puede copiar a tu proyecto (`public/sdk/nexus-sdk.js`) o dejar que el **asistente de integración** lo inyecte en una versión nueva.

## API
| | |
|---|---|
| `NexusPlay.connect({timeout?})` | Promesa → cliente. Rechaza con `not_embedded` o `timeout`. Llamadas repetidas devuelven el mismo cliente |
| `nexus.me` · `players` · `room` · `isHost` · `connected` | Lectura |
| `getPlayer(id)` · `getStates()` · `getShared()` | Lectura |
| `send(nombre, datos, {to?})` | Evento puntual (≤~7 KB). Sin eco al emisor |
| `setState(obj)` | Tu estado (objeto ≤~2 KB). Agrupa a ≤~20 envíos/s; lo último gana |
| `setShared(clave, valor)` | Solo anfitrión (≤~3.5 KB; `null` borra) |
| `ping()` | Promesa con la latencia en ms |
| `ready()` · `leave()` | Control |
| `on/off/once(evento, fn)` | `on` devuelve la función para desuscribir |

Eventos: `player:join`, `player:leave`, `player:online`, `player:offline`, `players`, `room`, `room:state`, `state`, `shared`, `event`, `event:<nombre>`, `connection`, `closed`, `error`.

Errores: `NexusError` con `code` (`bad_event_name, too_large, bad_state, bad_key, forbidden, not_connected, closed, timeout, not_embedded…`).

## Reglas del entorno aislado
- Sin `localStorage`/cookies/`document.domain`: el origen es opaco. Guarda lo necesario en el estado compartido.
- Los recursos del ZIP se cargan por rutas **relativas**. Recursos externos (CDN) dependen de internet de cada jugador; el analizador te avisa.
- Pantalla completa, bloqueo de puntero, `alert/confirm` y formularios están permitidos.
- Para sincronizar, envía **estados** (posición, etc.) a ritmo moderado y **eventos** para acciones puntuales. La lógica "quién gana" debe decidirla un cliente (normalmente el anfitrión).

## Asistente de integración
Analiza por **patrones de texto** (no ejecuta tu juego): detecta canvas, bucle, jugador, librerías, recursos externos, uso de `localStorage`, falta de controles táctiles. Puede equivocarse. Al aplicar crea una versión nueva con `nexus-sdk.js` (y opcionalmente `nexus-hud.js`, un panel de sala); **no cambia tu lógica de juego**: eso queda como sugerencias manuales.
