# Pruebas

## Ejecutadas (por mí, en Linux con Node 22.23, 28-oct-2026)
| Qué | Cómo | Resultado |
|---|---|---|
| Sesiones, cuotas, permisos, HTML/ZIP válidos y maliciosos (20 ataques/inválidos), versiones, miniaturas, vista previa firmada, rutas fuera de carpeta, asistente de integración, persistencia, recuperación de `db.json`, diagnóstico | `tests/games.test.js` | 51 ✔ |
| Salas: crear/unirse, capacidad, revocar/regenerar/caducar (reloj simulado), expulsar, salir y traspaso, máquina de estados, cierre, mantenimiento (inactividad, expiración, purga), límite de intentos | `tests/rooms.test.js` | 16 ✔ |
| WebSocket real: ticket único/caducado, difusión sin eco, mensajes directos, estados para quien entra tarde, compartido solo anfitrión, mensajes inválidos, 16 KB, aislamiento entre salas, presencia, reemplazo, expulsión/salida/cierre, ready/tiempo, origen, límite por IP, ritmo, reinicio del servidor | `tests/ws.test.js` | 17 ✔ |
| SDK con ventana simulada | `tests/sdk.test.js` | 18 ✔ |
| **Total `npm test`** | `node --test` | **102 ✔ / 0 ✘** |
| Navegador real (Chromium/Playwright): dos clientes (PC + **Pixel 7 emulado**), entrar, crear sala, jugar, sincronizar, aislamiento del iframe, reconexión, recargar, expulsar, cerrar, subir por la interfaz, asistente, diagnóstico, sin errores de consola | `node tests/e2e.mjs` | **39/39 ✔** |
| Respaldo y restauración (copia real, rechazo con servidor encendido, restauración y arranque) | manual con el servidor real | ✔ |

## Pendientes (no los he hecho; no los doy por buenos)
- **Prueba física Android + PC** en tu red Wi-Fi (la del Pixel es *emulación*, no un teléfono real).
- **Ejecución en tu Termux** (Node v24.17.0, ARM64): no tengo acceso a tu dispositivo.
- Prueba de carga (muchos jugadores/salas simultáneos) y de rendimiento en celular.
- Pruebas con tus juegos reales y con ZIP grandes (decenas de MB) en el celular.
- Navegadores distintos de Chromium (Firefox/Safari), pantallas táctiles reales, bloqueo de pantalla/cambio de red en Android.
- Prueba tras un proxy/túnel HTTPS.
- Auditoría de seguridad externa.

## Cómo correrlas
```bash
npm test                                   # unitarias/integración (~10 s)
npm i --no-save playwright                 # solo para E2E, requiere Chromium
SHOTS=./capturas node tests/e2e.mjs        # E2E + capturas
```
Las pruebas arrancan servidores reales en puertos libres con carpetas temporales; no tocan tu `data/`.

## Checklist de la prueba física (para ti)
1. Celular: `npm start`; PC: abrir la dirección `Red:`.
2. Celular crea sala con el demo; PC entra con el código y con el enlace.
3. Iniciar partida; mover en ambos; ¿se ven en tiempo real?
4. Apagar/encender Wi-Fi del PC 10 s: ¿reconecta solo?
5. Bloquear el celular 30 s y volver.
6. Subir un HTML propio y un ZIP; revisar el análisis.
7. Copiar el informe de *Diagnóstico* y compartirlo si algo falla.
