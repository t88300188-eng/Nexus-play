# Guía Termux (Android)

Versión de Node de referencia: **v24.17.0** (la tuya). El proyecto exige Node ≥ 22 y **no usa módulos nativos** (solo `express`, `ws`, `yauzl`, JavaScript puro), así que no necesita compilar nada.

> Probado por mí en Linux con Node 22; **no lo he ejecutado en tu Termux**. Si algo falla, usa el panel *Diagnóstico* y la sección "Errores conocidos".

## Instalar
```bash
pkg update && pkg upgrade
pkg install nodejs git zip unzip      # nodejs trae npm
termux-setup-storage                  # opcional: acceso a /sdcard
# copia/descomprime nexus-play.zip, por ejemplo:
cd ~ && unzip /sdcard/Download/nexus-play.zip && cd nexus-play
npm install
npm start
```

## Usar
1. `npm start` imprime `Local:` y `Red:`. En el PC abre la dirección `Red:` (misma Wi-Fi o el hotspot del celular).
2. En el celular abre `http://localhost:3000`.
3. Cada dispositivo escribe su nombre (sesión de invitado). Sube un juego (o usa el demo), pulsa **Crear sala**, comparte el código o enlace.

Si el PC no conecta: confirma misma red, que el celular no esté en "aislamiento de clientes" del router, y prueba con el hotspot del celular.

## Configuración
```bash
PORT=3001 npm start
DATA_DIR=$HOME/nexus-datos npm start
UPLOAD_KEY=mi-clave npm start     # exige clave para subir juegos
```
Todas las variables: `.env.example`. El servidor **no lee `.env` solo**; expórtalas o ponlas delante del comando. Para dejarlas fijas: `set -a; . ./.env; set +a; npm start`.

## Que no se apague
- Pon la pantalla encendida o ejecuta `termux-wake-lock`.
- Desactiva la optimización de batería para Termux en Android.
- Para seguir tras cerrar la sesión: `pkg install tmux` → `tmux new -s nexus` → `npm start` → `Ctrl+B` luego `D`.

## Copias de seguridad
```bash
npm run backup                       # crea backups/<fecha>/ (se conservan las últimas 10)
npm run restore                      # lista copias
npm run restore -- 2026-10-28_05-00-00   # requiere servidor apagado; guarda lo actual en data.before-restore-*
```
Copia además la carpeta `backups/` fuera del celular de vez en cuando.

## Errores conocidos
| Síntoma | Causa / solución |
|---|---|
| `Ya hay un servidor ... (PID n)` | Otra instancia usa esa carpeta. Ciérrala. Si fue un cierre brusco, el candado se ignora si ese PID ya no existe. |
| `El puerto 3000 ya está en uso` | `PORT=3001 npm start` |
| `npm install` falla por red | Revisa conexión; reintenta. No hay compilación nativa. |
| El botón *Copiar* no copia | En `http://` (no seguro) el navegador limita el portapapeles; hay un método alternativo, si falla copia a mano. |
| El juego no guarda datos (localStorage) | Los juegos corren en sandbox sin `allow-same-origin`: es intencional. Guarda estado con el SDK. |
| Se desconecta al bloquear el celular | Android suspende pestañas; al volver se reconecta solo. Mantén la pantalla activa durante la partida. |
