# Changelog

## 0.2.0 — 2026-10-28
Primera entrega completa.
- Biblioteca: HTML/ZIP, versiones inmutables, miniatura, editar, publicar/despublicar, eliminar, vista previa firmada.
- Salas privadas con invitaciones revocables/caducables, expulsión, cambio de anfitrión, máquina de estados.
- Tiempo real por WebSocket (protocolo v1) con reconexión automática.
- SDK 1.0.0, HUD opcional y juego demo "Cuadrados".
- Asistente de integración (versión nueva, original intacta).
- Panel de diagnóstico con informe copiable.
- Validación de ZIP endurecida; errores de ZIP con mensajes claros.
- Respaldo/restauración (`npm run backup|restore`), `.env.example`.
- Corregido durante las pruebas: texto "null" visible en la interfaz; archivos temporales que quedaban tras rechazar una subida por título inválido; un usuario ajeno recibía 403 (revelaba que existía un borrador) en vez de 404.
- Pruebas: 102 automáticas + 39 en navegador.
