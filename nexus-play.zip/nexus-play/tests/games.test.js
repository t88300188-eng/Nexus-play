import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, upload, buildZip, GAME_HTML, publishedGame } from './helpers.js';

const gamesOnDisk = (ctx) => fs.readdirSync(path.join(ctx.dataDir, 'games'));
const tmpLeft = (ctx) => fs.readdirSync(path.join(ctx.dataDir, 'tmp'));

describe('Sesiones y seguridad básica', () => {
  let ctx;
  before(async () => { ctx = await startServer(); });
  after(() => ctx.close());

  test('health responde y expone límites', async () => {
    const r = await ctx.api('GET', '/api/health');
    assert.equal(r.status, 200);
    assert.equal(r.json.ok, true);
    assert.ok(r.json.limits.maxZipMb > 0);
  });

  test('crear sesión valida el nombre', async () => {
    assert.equal((await ctx.api('POST', '/api/session', { body: { name: 'A' } })).status, 400);
    assert.equal((await ctx.api('POST', '/api/session', { body: { name: 'x'.repeat(40) } })).status, 400);
    assert.equal((await ctx.api('POST', '/api/session', { body: { name: 123 } })).status, 400);
    assert.equal((await ctx.api('POST', '/api/session', { body: [1] })).status, 400);
    assert.equal((await ctx.api('POST', '/api/session', { raw: '{malo', headers: { 'content-type': 'application/json' } })).status, 400);
    const ok = await ctx.api('POST', '/api/session', { body: { name: '  Ana  ' } });
    assert.equal(ok.status, 201);
    assert.equal(ok.json.user.name, 'Ana');
  });

  test('sin token o con token falso: 401', async () => {
    assert.equal((await ctx.api('GET', '/api/games')).status, 401);
    assert.equal((await ctx.api('GET', '/api/games', { token: 'x'.repeat(43) })).status, 401);
    assert.equal((await ctx.api('GET', '/api/me', { headers: { authorization: 'Basic abc' } })).status, 401);
  });

  test('el token no se guarda en claro (solo su hash)', async () => {
    const u = await ctx.user('Hasheado');
    ctx.srv.store.flush();
    const db = fs.readFileSync(path.join(ctx.dataDir, 'db.json'), 'utf8');
    assert.ok(!db.includes(u.token), 'el token apareció en db.json');
    assert.ok(db.includes('tokenHash'));
  });

  test('cabeceras de seguridad del panel', async () => {
    const r = await ctx.api('GET', '/');
    assert.equal(r.status, 200);
    assert.match(r.headers.get('content-security-policy'), /default-src 'self'/);
    assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'none'/);
    assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(r.headers.get('x-frame-options'), 'DENY');
  });

  test('ruta de API desconocida: 404 JSON', async () => {
    const r = await ctx.api('GET', '/api/nada');
    assert.equal(r.status, 404);
    assert.equal(r.json.error.code, 'not_found');
  });

  test('el nombre puede cambiarse', async () => {
    const u = await ctx.user('Viejo');
    const r = await ctx.api('PATCH', '/api/me', { token: u.token, body: { name: 'Nuevo' } });
    assert.equal(r.json.user.name, 'Nuevo');
  });
});

describe('Límite de sesiones y peticiones', () => {
  test('demasiadas sesiones desde una IP: 429', async () => {
    const ctx = await startServer({ sessionsPerHour: 3 });
    try {
      for (let i = 0; i < 3; i++) assert.equal((await ctx.api('POST', '/api/session', { body: { name: `U${i}x` } })).status, 201);
      assert.equal((await ctx.api('POST', '/api/session', { body: { name: 'Otro' } })).status, 429);
    } finally { await ctx.close(); }
  });

  test('límite general de peticiones por IP: 429 con Retry-After', async () => {
    const ctx = await startServer({ httpRatePerMin: 5 });
    try {
      let last;
      for (let i = 0; i < 8; i++) last = await ctx.api('GET', '/api/health');
      assert.equal(last.status, 429);
      assert.ok(Number(last.headers.get('retry-after')) >= 1);
    } finally { await ctx.close(); }
  });
});

describe('Subida de HTML', () => {
  let ctx; let ana; let beto;
  before(async () => { ctx = await startServer({ maxHtmlBytes: 2000 }); ana = await ctx.user('Ana'); beto = await ctx.user('Beto'); });
  after(() => ctx.close());

  test('un HTML válido se guarda como borrador v1', async () => {
    const r = await upload(ctx, ana.token, { filename: 'juego.html', data: GAME_HTML, title: 'Mi juego', description: 'Prueba' });
    assert.equal(r.status, 201);
    const g = r.json.game;
    assert.equal(g.title, 'Mi juego');
    assert.equal(g.published, false);
    assert.equal(g.version, 1);
    assert.equal(g.kind, 'html');
    assert.equal(g.versions.length, 1);
    assert.match(g.versions[0].sha256, /^[0-9a-f]{64}$/);
  });

  test('rechaza: extensión mala, vacío, binario, texto sin HTML, título corto, demasiado grande', async () => {
    const bad = async (o) => (await upload(ctx, ana.token, { title: 'Titulo', ...o })).status;
    assert.equal(await bad({ filename: 'x.exe', data: 'MZ' }), 400);
    assert.equal(await bad({ filename: 'x.html', data: '' }), 400);
    assert.equal(await bad({ filename: 'x.html', data: Buffer.from([0x3c, 0x68, 0x00, 0x01, 0x02]) }), 400);
    assert.equal(await bad({ filename: 'x.html', data: 'solo texto sin etiquetas' }), 400);
    assert.equal(await bad({ filename: 'x.html', data: GAME_HTML, title: 'a' }), 400);
    assert.equal(await bad({ filename: 'x.html', data: GAME_HTML + ' '.repeat(3000) }), 413);
    assert.deepEqual(tmpLeft(ctx), [], 'quedaron archivos temporales');
  });

  test('se sirve con el aislamiento y las cabeceras correctas', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML })).json.game;
    await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { published: true } });
    const pub = (await ctx.api('GET', `/api/games/${g.id}`, { token: beto.token })).json.game;
    assert.ok(pub.playUrl);
    const r = await fetch(ctx.base + pub.playUrl);
    assert.equal(r.status, 200);
    assert.match(r.headers.get('content-security-policy'), /^sandbox allow-scripts/);
    assert.ok(!/allow-same-origin/.test(r.headers.get('content-security-policy')));
    assert.match(r.headers.get('content-security-policy'), /frame-ancestors 'self'/);
    assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    assert.match(r.headers.get('content-type'), /text\/html/);
    assert.equal(await r.text(), GAME_HTML);
  });

  test('solo el propietario ve y modifica borradores', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML, title: 'Secreto' })).json.game;
    assert.equal((await ctx.api('GET', `/api/games/${g.id}`, { token: beto.token })).status, 404);
    const list = (await ctx.api('GET', '/api/games', { token: beto.token })).json.games;
    assert.ok(!list.some((x) => x.id === g.id));
    assert.equal((await fetch(`${ctx.base}/g/${g.id}/1/index.html`)).status, 404, 'un borrador no debe servirse');
    assert.equal((await ctx.api('PATCH', `/api/games/${g.id}`, { token: beto.token, body: { title: 'Hackeado' } })).status, 404);
    // un juego publicado de otro: se ve, pero no se toca
    await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { published: true } });
    assert.equal((await ctx.api('GET', `/api/games/${g.id}`, { token: beto.token })).status, 200);
    for (const [m, u, b] of [['PATCH', '', { title: 'Hackeado' }], ['DELETE', '', undefined], ['POST', '/current', { version: 1 }], ['POST', '/integrate', { accept: ['inject-sdk'] }]]) {
      const r = await ctx.api(m, `/api/games/${g.id}${u}`, { token: beto.token, body: b });
      assert.equal(r.status, 403, `${m} ${u} debería ser 403`);
    }
    const nv = await upload(ctx, beto.token, { filename: 'b.html', data: GAME_HTML, gameId: g.id });
    assert.equal(nv.status, 403, 'otro usuario no puede añadir versiones');
    assert.equal((await ctx.api('GET', `/api/games/${g.id}/analysis`, { token: beto.token })).status, 403);
    const detail = (await ctx.api('GET', `/api/games/${g.id}`, { token: beto.token })).json.game;
    assert.equal(detail.versions, undefined, 'el detalle de versiones es solo del propietario');
  });

  test('la vista previa de un borrador usa un enlace firmado que caduca y no se falsifica', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML, title: 'Borrador2' })).json.game;
    assert.equal((await ctx.api('GET', `/api/games/${g.id}/preview`, { token: beto.token })).status, 404);
    const p = (await ctx.api('GET', `/api/games/${g.id}/preview`, { token: ana.token })).json;
    assert.equal((await fetch(ctx.base + p.url)).status, 200);
    const parts = p.url.split('/'); // ['', 'gp', token, 'index.html']
    const forged = [...parts]; forged[2] = forged[2].slice(0, -3) + 'abc';
    assert.equal((await fetch(ctx.base + forged.join('/'))).status, 404);
    const tok = parts[2].split('.');
    const otherGame = (await upload(ctx, beto.token, { filename: 'a.html', data: GAME_HTML, title: 'DeBeto' })).json.game;
    const swapped = [otherGame.id, tok[1], tok[2], tok[3]].join('.');
    assert.equal((await fetch(`${ctx.base}/gp/${swapped}/index.html`)).status, 404, 'no se puede reutilizar la firma en otro juego');
    const expired = [tok[0], tok[1], '1000', tok[3]].join('.');
    assert.equal((await fetch(`${ctx.base}/gp/${expired}/index.html`)).status, 404);
  });

  test('no se sirven rutas fuera de la versión ni archivos ocultos', async () => {
    const g = await publishedGame(ctx, ana.token, 'Rutas');
    for (const p of [`/g/${g.id}/1/../../../db.json`, `/g/${g.id}/1/%2e%2e/%2e%2e/db.json`, `/g/${g.id}/1/..%2f..%2fdb.json`, `/g/${g.id}/1/.secret`, `/g/${g.id}/1/index.html%00.png`, `/g/${g.id}/9/index.html`, `/g/nope/1/index.html`, `/g/${g.id}/1/`]) {
      const r = await fetch(ctx.base + p);
      assert.notEqual(r.status, 200, `${p} no debería servirse`);
    }
    const sec = await fetch(`${ctx.base}/g/${g.id}/1/.secret`);
    assert.equal(sec.status, 404);
  });
});

describe('Subida de ZIP: casos válidos', () => {
  let ctx; let ana;
  before(async () => { ctx = await startServer(); ana = await ctx.user('Ana'); });
  after(() => ctx.close());

  test('un ZIP con carpeta contenedora, CSS, JS, imagen, audio y modelo 3D se publica y sirve con el MIME correcto', async () => {
    const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
    const zip = buildZip([
      { name: 'mijuego/index.html', data: '<!doctype html><html><head><link rel="stylesheet" href="css/s.css"></head><body><script src="js/g.js"></script></body></html>', method: 'deflate' },
      { name: 'mijuego/css/s.css', data: 'body{color:red}', method: 'deflate' },
      { name: 'mijuego/js/g.js', data: 'console.log(1)', method: 'deflate' },
      { name: 'mijuego/img/a.png', data: png },
      { name: 'mijuego/audio/s.mp3', data: Buffer.alloc(100, 1) },
      { name: 'mijuego/models/m.glb', data: Buffer.alloc(80, 2) },
      { name: '__MACOSX/mijuego/._index.html', data: 'basura' },
      { name: 'mijuego/.DS_Store', data: 'x' },
      { name: 'mijuego/carpeta/', data: '' },
    ]);
    const r = await upload(ctx, ana.token, { filename: 'mijuego.zip', data: zip, title: 'Con ZIP' });
    assert.equal(r.status, 201, r.text);
    const g = r.json.game;
    assert.equal(g.kind, 'zip');
    assert.equal(g.files, 6, 'basura del sistema y carpetas no cuentan');
    assert.equal(g.entry, 'index.html', 'se quitó la carpeta contenedora');
    await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { published: true } });
    const base = `${ctx.base}/g/${g.id}/1`;
    const check = async (p, type) => { const x = await fetch(`${base}/${p}`); assert.equal(x.status, 200, p); assert.match(x.headers.get('content-type'), type, p); };
    await check('index.html', /text\/html/);
    await check('css/s.css', /text\/css/);
    await check('js/g.js', /javascript/);
    await check('img/a.png', /image\/png/);
    await check('audio/s.mp3', /audio\/mpeg/);
    await check('models/m.glb', /model\/gltf-binary/);
    assert.equal((await fetch(`${base}/__MACOSX/mijuego/._index.html`)).status, 404);
    const range = await fetch(`${base}/audio/s.mp3`, { headers: { range: 'bytes=0-9' } });
    assert.equal(range.status, 206, 'el audio/vídeo necesita peticiones parciales (Range)');
  });

  test('un único HTML en la raíz sin llamarse index.html se acepta como entrada', async () => {
    const zip = buildZip([{ name: 'juego.html', data: GAME_HTML }, { name: 'a.js', data: '1' }]);
    const r = await upload(ctx, ana.token, { filename: 'j.zip', data: zip, title: 'Sin index' });
    assert.equal(r.status, 201, r.text);
    assert.equal(r.json.game.entry, 'juego.html');
  });

  test('varias versiones: se conservan, se puede volver a una anterior y eliminarla', async () => {
    const g0 = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML, title: 'Versionado' })).json.game;
    const v2 = await upload(ctx, ana.token, { filename: 'b.html', data: GAME_HTML.replace('player', 'jugador'), gameId: g0.id, note: 'cambio' });
    assert.equal(v2.status, 201);
    assert.equal(v2.json.game.version, 2);
    assert.equal(v2.json.game.versions.length, 2);
    assert.equal((await ctx.api('GET', `/api/games/${g0.id}/preview?version=1`, { token: ana.token })).status, 200);
    const back = await ctx.api('POST', `/api/games/${g0.id}/current`, { token: ana.token, body: { version: 1 } });
    assert.equal(back.json.game.version, 1);
    assert.equal((await ctx.api('POST', `/api/games/${g0.id}/current`, { token: ana.token, body: { version: 9 } })).status, 404);
    assert.equal((await ctx.api('DELETE', `/api/games/${g0.id}/versions/1`, { token: ana.token })).status, 409, 'no se elimina la versión actual');
    const del = await ctx.api('DELETE', `/api/games/${g0.id}/versions/2`, { token: ana.token });
    assert.equal(del.status, 200);
    assert.equal(del.json.game.versions.length, 1);
    assert.ok(!fs.existsSync(path.join(ctx.dataDir, 'games', g0.id, 'v2')), 'la carpeta de la versión se borró');
    const v3 = await upload(ctx, ana.token, { filename: 'c.html', data: GAME_HTML, gameId: g0.id });
    assert.equal(v3.json.game.version, 3, 'los números de versión no se reutilizan');
  });

  test('editar datos, publicar y despublicar, y eliminar con limpieza de archivos', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML, title: 'Editable' })).json.game;
    const e = await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { title: 'Nuevo título', description: 'Línea 1\nLínea 2', published: true } });
    assert.equal(e.json.game.title, 'Nuevo título');
    assert.equal(e.json.game.published, true);
    assert.equal((await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { title: 'x' } })).status, 400);
    assert.equal((await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { published: 'si' } })).status, 400);
    assert.equal((await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { published: false } })).json.game.published, false);
    assert.equal((await ctx.api('DELETE', `/api/games/${g.id}`, { token: ana.token })).status, 200);
    assert.ok(!gamesOnDisk(ctx).includes(g.id));
    assert.equal((await ctx.api('GET', `/api/games/${g.id}`, { token: ana.token })).status, 404);
  });

  test('miniatura: acepta PNG real, rechaza otros formatos, se sirve con su tipo y se puede quitar', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML, title: 'Con miniatura' })).json.game;
    const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
    assert.equal((await ctx.api('PUT', `/api/games/${g.id}/thumbnail`, { token: ana.token, raw: '<svg onload=alert(1)>' })).status, 400);
    assert.equal((await ctx.api('PUT', `/api/games/${g.id}/thumbnail`, { token: ana.token, raw: Buffer.alloc(600 * 1024, 1) })).status, 413);
    const ok = await ctx.api('PUT', `/api/games/${g.id}/thumbnail`, { token: ana.token, raw: png });
    assert.equal(ok.status, 200);
    assert.ok(ok.json.game.thumbUrl);
    const img = await fetch(ctx.base + ok.json.game.thumbUrl);
    assert.equal(img.status, 200);
    assert.equal(img.headers.get('content-type'), 'image/png');
    const rm = await ctx.api('DELETE', `/api/games/${g.id}/thumbnail`, { token: ana.token });
    assert.equal(rm.json.game.thumbUrl, null);
    const other = await ctx.user('Otro');
    assert.equal((await ctx.api('PUT', `/api/games/${g.id}/thumbnail`, { token: other.token, raw: png })).status, 404);
  });
});

describe('Subida de ZIP: archivos maliciosos o inválidos', () => {
  let ctx; let ana;
  before(async () => {
    ctx = await startServer({ maxZipFiles: 8, maxZipDepth: 4, maxFileBytes: 200_000, maxUnzippedBytes: 400_000, maxZipBytes: 5_000_000 });
    ana = await ctx.user('Ana');
  });
  after(() => ctx.close());

  const rejects = async (name, entries, status = 400, rx) => {
    const before = gamesOnDisk(ctx).length;
    const data = Buffer.isBuffer(entries) ? entries : buildZip(entries);
    const r = await upload(ctx, ana.token, { filename: 'x.zip', data, title: 'Malicioso' });
    assert.equal(r.status, status, `${name}: esperaba ${status}, llegó ${r.status} ${r.text}`);
    if (rx) assert.match(r.json.error.message, rx, name);
    assert.equal(gamesOnDisk(ctx).length, before, `${name}: no debe quedar ningún juego`);
    assert.deepEqual(tmpLeft(ctx), [], `${name}: quedaron temporales`);
    const list = (await ctx.api('GET', '/api/games', { token: ana.token })).json.games;
    assert.ok(!list.some((g) => g.title === 'Malicioso'), `${name}: apareció en la biblioteca`);
  };
  const idx = { name: 'index.html', data: GAME_HTML };

  test('zip-slip: rutas con ..', () => rejects('zip-slip', [idx, { name: '../evil.js', data: 'x' }], 400, /peligrosa/));
  test('zip-slip anidado', () => rejects('zip-slip2', [idx, { name: 'a/../../evil.js', data: 'x' }], 400, /peligrosa/));
  test('rutas absolutas', () => rejects('absoluta', [idx, { name: '/etc/passwd.txt', data: 'x' }], 400, /absoluta/));
  test('rutas de Windows (letra de unidad y barras invertidas)', async () => {
    await rejects('unidad', [idx, { name: 'C:/x.js', data: 'x' }], 400, /absoluta/);
    await rejects('backslash', [idx, { name: 'a\\..\\x.js', data: 'x' }], 400, /peligrosa|no permitida/);
  });
  test('enlaces simbólicos', () => rejects('symlink', [idx, { name: 'link.js', data: '/etc/passwd', mode: 0o120777 }], 400, /simbólico/));
  test('archivos duplicados (sin distinguir mayúsculas)', () => rejects('duplicado', [idx, { name: 'A.js', data: '1' }, { name: 'a.js', data: '2' }], 400, /duplicado/));
  test('tipos no permitidos (.exe, .php, .sh, .zip anidado)', () => rejects('tipos', [idx, { name: 'a.exe', data: 'MZ' }, { name: 'b.php', data: '<?php' }, { name: 's.sh', data: '#!/bin/sh' }, { name: 'n.zip', data: 'PK' }], 400, /no permitidos \(4\)/));
  test('sin index.html', () => rejects('sin-index', [{ name: 'a.js', data: '1' }], 400, /index\.html/));
  test('varios HTML sin index', () => rejects('varios', [{ name: 'a.html', data: GAME_HTML }, { name: 'b.html', data: GAME_HTML }], 400, /varios HTML/));
  test('demasiados archivos', () => rejects('muchos', [idx, ...Array.from({ length: 10 }, (_, i) => ({ name: `f${i}.js`, data: '1' }))], 400, /demasiados/));
  test('carpetas demasiado profundas', () => rejects('profundo', [idx, { name: 'a/b/c/d/e/f.js', data: '1' }], 400, /profundas/));
  test('archivo individual demasiado grande (cabecera honesta)', () => rejects('grande', [idx, { name: 'big.bin', data: Buffer.alloc(250_000, 7), method: 'deflate' }], 400, /por archivo/));
  test('total descomprimido demasiado grande', () => rejects('total', [idx, ...[1, 2, 3].map((i) => ({ name: `d${i}.bin`, data: Buffer.alloc(150_000, i), method: 'deflate' }))], 400, /descomprimido/));
  test('mentira en la cabecera: tamaño declarado pequeño, contenido real enorme (zip bomb)', () => rejects('bomba', [idx, { name: 'bomba.bin', data: Buffer.alloc(3_000_000, 0), method: 'deflate', declaredSize: 50 }], 400));
  test('ZIP cifrado (con contraseña)', () => rejects('cifrado', [idx, { name: 's.js', data: 'x'.repeat(50), method: 'deflate', flags: 1 }], 400, /contraseña/));
  test('archivo que no es un ZIP aunque se llame .zip', async () => {
    await rejects('falso', Buffer.from('esto no es un zip, solo texto largo '.repeat(10)), 400, /ZIP/);
    await rejects('corrupto', Buffer.concat([Buffer.from('PK\x03\x04'), Buffer.alloc(200, 9)]), 400, /dañado|ZIP/);
  });
  test('ZIP vacío', () => rejects('vacio', [], 400));
  test('nombres con caracteres de control', () => rejects('control', [idx, { name: 'a\u0001b.js', data: '1', flags: 0x800 }], 400));
  test('ZIP demasiado grande por el límite de subida', async () => {
    const r = await upload(ctx, ana.token, { filename: 'x.zip', data: Buffer.alloc(5_100_000, 1), title: 'Enorme' });
    assert.equal(r.status, 413);
  });
  test('archivos ocultos (.env, .git) se omiten sin romper la subida y no se sirven', async () => {
    const r = await upload(ctx, ana.token, { filename: 'x.zip', data: buildZip([idx, { name: '.env', data: 'SECRETO=1' }, { name: '.git/config', data: 'x' }]), title: 'Ocultos' });
    assert.equal(r.status, 201, r.text);
    assert.equal(r.json.game.files, 1);
    assert.equal(fs.existsSync(path.join(ctx.dataDir, 'games', r.json.game.id, 'v1', '.env')), false);
  });
});

describe('Cuotas', () => {
  test('máximo de juegos, versiones y espacio por usuario', async () => {
    const ctx = await startServer({ maxGamesPerUser: 2, maxVersionsPerGame: 2, maxUserBytes: 3000 });
    try {
      const u = await ctx.user('Cuota');
      const html = (n) => GAME_HTML.replace('t</title>', `${'x'.repeat(n)}</title>`);
      const g1 = await upload(ctx, u.token, { filename: 'a.html', data: html(1), title: 'Uno' });
      assert.equal(g1.status, 201);
      assert.equal((await upload(ctx, u.token, { filename: 'a.html', data: html(1), title: 'Dos' })).status, 201);
      assert.equal((await upload(ctx, u.token, { filename: 'a.html', data: html(1), title: 'Tres' })).status, 409, 'máximo de juegos');
      assert.equal((await upload(ctx, u.token, { filename: 'a.html', data: html(1), gameId: g1.json.game.id })).status, 201);
      assert.equal((await upload(ctx, u.token, { filename: 'a.html', data: html(1), gameId: g1.json.game.id })).status, 409, 'máximo de versiones');
      const ctx2 = await startServer({ maxUserBytes: 400 });
      try {
        const u2 = await ctx2.user('Espacio');
        const r = await upload(ctx2, u2.token, { filename: 'a.html', data: html(500), title: 'Grande' });
        assert.equal(r.status, 413);
        assert.match(r.json.error.message, /espacio/);
        assert.deepEqual(tmpLeft(ctx2), []);
      } finally { await ctx2.close(); }
    } finally { await ctx.close(); }
  });

  test('clave de subida opcional (UPLOAD_KEY)', async () => {
    const ctx = await startServer({ uploadKey: 'clave-secreta' });
    try {
      const u = await ctx.user('Con clave');
      const sin = await upload(ctx, u.token, { filename: 'a.html', data: GAME_HTML });
      assert.equal(sin.status, 401);
      assert.equal(sin.json.error.code, 'upload_key_required');
      const mala = await ctx.api('POST', '/api/games?title=Titulo&filename=a.html', { token: u.token, raw: GAME_HTML, headers: { 'x-upload-key': 'otra' } });
      assert.equal(mala.status, 401);
      const buena = await ctx.api('POST', '/api/games?title=Titulo&filename=a.html', { token: u.token, raw: GAME_HTML, headers: { 'x-upload-key': 'clave-secreta' } });
      assert.equal(buena.status, 201);
      assert.equal((await ctx.api('GET', '/api/health')).json.uploadKeyRequired, true);
    } finally { await ctx.close(); }
  });
});

describe('Asistente de integración', () => {
  let ctx; let ana; let beto;
  const CANVAS_GAME = '<!doctype html><html><head><title>j</title></head><body><canvas id="c"></canvas><script src="https://cdn.example.com/three.min.js"></script><script>\nlet player = { x: 1, y: 2 };\nconst ctx = c.getContext("2d");\naddEventListener("keydown", e => {});\nfunction loop(){ requestAnimationFrame(loop); }\ntry { localStorage.getItem("a"); } catch(e) {}\n</script></body></html>';
  before(async () => { ctx = await startServer(); ana = await ctx.user('Ana'); beto = await ctx.user('Beto'); });
  after(() => ctx.close());

  test('analiza sin ejecutar, detecta puntos clave y avisa de limitaciones', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: CANVAS_GAME, title: 'Canvas' })).json.game;
    const a = (await ctx.api('GET', `/api/games/${g.id}/analysis`, { token: ana.token })).json.analysis;
    assert.equal(a.entry, 'index.html');
    assert.equal(a.heuristic, true);
    assert.equal(a.level, 'posible');
    assert.ok(a.externals.some((x) => x.includes('cdn.example.com')));
    assert.ok(a.libraries.includes('Three.js'));
    assert.ok(a.syncCandidates.some((s) => s.kind === 'jugador'));
    assert.ok(a.syncCandidates.some((s) => s.kind === 'bucle'));
    assert.ok(a.warnings.some((w) => /localStorage/.test(w.text)));
    assert.ok(a.warnings.some((w) => /táctil/.test(w.text)));
    assert.ok(a.changes.some((c) => c.id === 'inject-sdk'));
    assert.ok(a.manual.length >= 1);
    assert.ok(a.patchPreview.after.join('\n').includes('nexus-sdk.js'));
    assert.match(a.note, /puede equivocarse/i);
  });

  test('aplicar crea una versión nueva; la original queda intacta', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: CANVAS_GAME, title: 'Para integrar' })).json.game;
    const origPath = path.join(ctx.dataDir, 'games', g.id, 'v1', 'index.html');
    const orig = fs.readFileSync(origPath, 'utf8');
    assert.equal((await ctx.api('POST', `/api/games/${g.id}/integrate`, { token: ana.token, body: { accept: [] } })).status, 400, 'sin aceptar nada no se aplica');
    const r = await ctx.api('POST', `/api/games/${g.id}/integrate`, { token: ana.token, body: { version: 1, accept: ['inject-sdk', 'inject-hud'] } });
    assert.equal(r.status, 201, r.text);
    assert.equal(r.json.game.version, 2);
    assert.equal(r.json.game.versions.length, 2);
    assert.equal(r.json.game.versions[1].integratedFrom, 1);
    assert.equal(fs.readFileSync(origPath, 'utf8'), orig, 'la versión original NO se modificó');
    const v2dir = path.join(ctx.dataDir, 'games', g.id, 'v2');
    const html2 = fs.readFileSync(path.join(v2dir, 'index.html'), 'utf8');
    assert.match(html2, /<script src="nexus-sdk\.js"><\/script>/);
    assert.match(html2, /<script src="nexus-hud\.js"><\/script>/);
    assert.ok(fs.existsSync(path.join(v2dir, 'nexus-sdk.js')));
    assert.ok(fs.existsSync(path.join(v2dir, 'nexus-hud.js')));
    assert.equal(html2.replace(/\n<script src="nexus-(sdk|hud)\.js"><\/script>/g, '').replace('\n\n</head>', '\n</head>'), orig.replace(/<\/head>/, '\n</head>').replace('\n\n</head>', '\n</head>'), 'solo se añadieron las etiquetas');
    const again = await ctx.api('POST', `/api/games/${g.id}/integrate`, { token: ana.token, body: { accept: ['inject-sdk'] } });
    assert.equal(again.status, 409, 'ya integrado');
    const a2 = (await ctx.api('GET', `/api/games/${g.id}/analysis`, { token: ana.token })).json.analysis;
    assert.equal(a2.level, 'integrado');
    // volver a la original
    const back = await ctx.api('POST', `/api/games/${g.id}/current`, { token: ana.token, body: { version: 1 } });
    assert.equal(back.json.game.version, 1);
  });

  test('un HTML que no parece juego recibe veredicto prudente', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: '<html><body><h1>Hola</h1></body></html>', title: 'Estatico' })).json.game;
    const a = (await ctx.api('GET', `/api/games/${g.id}/analysis`, { token: ana.token })).json.analysis;
    assert.equal(a.level, 'incierto');
  });

  test('otro usuario no puede analizar ni integrar', async () => {
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: CANVAS_GAME, title: 'Ajeno' })).json.game;
    assert.equal((await ctx.api('GET', `/api/games/${g.id}/analysis`, { token: beto.token })).status, 404);
  });
});

describe('Persistencia', () => {
  test('juegos, versiones, sesiones y salas sobreviven a un reinicio', async () => {
    const dataDir = fs.mkdtempSync(path.join(await import('node:os').then((m) => m.tmpdir()), 'nexus-persist-'));
    let ctx = await startServer({ dataDir });
    const ana = await ctx.user('Ana');
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML, title: 'Persistente' })).json.game;
    await upload(ctx, ana.token, { filename: 'b.html', data: GAME_HTML, gameId: g.id });
    await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { published: true } });
    const room = (await ctx.api('POST', '/api/rooms', { token: ana.token, body: { gameId: g.id, max: 3 } })).json.room;
    await ctx.close();

    ctx = await startServer({ dataDir });
    try {
      const me = await ctx.api('GET', '/api/me', { token: ana.token });
      assert.equal(me.status, 200, 'la sesión sigue siendo válida tras reiniciar');
      const g2 = (await ctx.api('GET', `/api/games/${g.id}`, { token: ana.token })).json.game;
      assert.equal(g2.versions.length, 2);
      assert.equal(g2.published, true);
      assert.equal((await fetch(ctx.base + g2.playUrl)).status, 200, 'los archivos siguen ahí');
      const r2 = await ctx.api('GET', `/api/rooms/${room.id}`, { token: ana.token });
      assert.equal(r2.status, 200);
      assert.equal(r2.json.room.invite.code, room.invite.code, 'la invitación se conserva');
      const beto = await ctx.user('Beto');
      assert.equal((await ctx.api('POST', '/api/rooms/join', { token: beto.token, body: { code: room.invite.code } })).status, 200, 'la invitación sigue funcionando');
    } finally { await ctx.close(); }
  });

  test('si db.json se corrompe se recupera la copia anterior sin perder juegos', async () => {
    const dataDir = fs.mkdtempSync(path.join(await import('node:os').then((m) => m.tmpdir()), 'nexus-corrupt-'));
    let ctx = await startServer({ dataDir });
    const ana = await ctx.user('Ana');
    const g = (await upload(ctx, ana.token, { filename: 'a.html', data: GAME_HTML, title: 'Sobrevive' })).json.game;
    ctx.srv.store.flush();
    await ctx.api('PATCH', `/api/games/${g.id}`, { token: ana.token, body: { description: 'cambio' } });
    await ctx.close(); // segundo guardado => existe db.json.bak
    assert.ok(fs.existsSync(path.join(dataDir, 'db.json.bak')));
    fs.writeFileSync(path.join(dataDir, 'db.json'), '{"users": {corrupto');
    ctx = await startServer({ dataDir });
    try {
      assert.equal(ctx.srv.store.recovered, 'bak');
      const r = await ctx.api('GET', `/api/games/${g.id}`, { token: ana.token });
      assert.equal(r.status, 200);
      assert.ok(fs.readdirSync(dataDir).some((f) => f.startsWith('db.corrupt-')), 'el archivo dañado se conserva como evidencia');
    } finally { await ctx.close(); }
  });

  test('la escritura de db.json es atómica (no queda .tmp) y los temporales de subidas se limpian al arrancar', async () => {
    const dataDir = fs.mkdtempSync(path.join(await import('node:os').then((m) => m.tmpdir()), 'nexus-atomic-'));
    let ctx = await startServer({ dataDir });
    await ctx.user('Ana');
    ctx.srv.store.flush();
    assert.ok(!fs.existsSync(path.join(dataDir, 'db.json.tmp')));
    await ctx.close();
    fs.writeFileSync(path.join(dataDir, 'tmp', 'up_restos'), 'x');
    ctx = await startServer({ dataDir });
    try { assert.deepEqual(tmpLeft(ctx), []); } finally { await ctx.close(); }
  });
});

describe('Diagnóstico', () => {
  test('devuelve información real y no filtra secretos', async () => {
    const ctx = await startServer();
    try {
      const u = await ctx.user('Diag');
      const g = await publishedGame(ctx, u.token);
      const room = (await ctx.api('POST', '/api/rooms', { token: u.token, body: { gameId: g.id } })).json.room;
      await upload(ctx, u.token, { filename: 'x.html', data: 'sin etiquetas' }); // provoca un error de carga registrado
      const r = await ctx.api('GET', '/api/diagnostics', { token: u.token });
      assert.equal(r.status, 200);
      const d = r.json;
      assert.equal(d.storage.dataDirWritable, true);
      assert.ok(d.server.node.startsWith('v'));
      assert.ok(d.rooms.active >= 1);
      assert.ok(d.games.recentErrors.length >= 1, 'el error de carga aparece en el diagnóstico');
      assert.ok(d.logs.length > 0);
      assert.ok(!r.text.includes(u.token), 'el token no debe aparecer');
      assert.ok(!r.text.includes(room.invite.code.replace(/-/g, '')), 'el código de invitación no debe aparecer');
      assert.ok(!r.text.includes(room.invite.code));
      assert.equal((await ctx.api('GET', '/api/diagnostics')).status, 401);
    } finally { await ctx.close(); }
  });
});

test('el juego demo se instala al primer arranque con el SDK incluido', async () => {
  const ctx = await startServer({ seedDemo: true });
  try {
    const u = await ctx.user('Visita');
    const list = (await ctx.api('GET', '/api/games', { token: u.token })).json.games;
    assert.equal(list.length, 1);
    assert.equal(list[0].published, true);
    assert.equal(list[0].integrated, false);
    const sdk = await fetch(ctx.base + list[0].playUrl.replace('index.html', 'nexus-sdk.js'));
    assert.equal(sdk.status, 200);
    assert.match(await sdk.text(), /NEXUS PLAY SDK v1/);
  } finally { await ctx.close(); }
});
