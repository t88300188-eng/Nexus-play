import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startServer, until, roomWithPlayers, publishedGame, upload, GAME_HTML } from './helpers.js';

describe('Salas privadas (HTTP)', () => {
  let ctx;
  before(async () => { ctx = await startServer({ closeDelayMs: 20, startTimeoutMs: 100 }); });
  after(() => ctx.close());
  const post = (u, url, body) => ctx.api('POST', url, { token: u.token, body });

  test('crear sala: el anfitrión recibe código de 12 caracteres; el invitado no lo ve', async () => {
    const { room, host } = await roomWithPlayers(ctx, ['Host']);
    assert.match(room.invite.code, /^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$/);
    assert.equal(room.state, 'waiting');
    assert.equal(room.isHost, true);
    assert.equal(room.players.length, 1);
    const guest = await ctx.user('Invitado');
    const j = await post(guest, '/api/rooms/join', { code: room.invite.code });
    assert.equal(j.status, 200);
    assert.equal(j.json.room.invite, undefined, 'el invitado no recibe el código');
    assert.equal(j.json.room.isHost, false);
    assert.equal(host.name, 'Host');
  });

  test('validaciones al crear', async () => {
    const u = await ctx.user('Crea');
    const g = await publishedGame(ctx, u.token);
    assert.equal((await post(u, '/api/rooms', { gameId: 'g_nope' })).status, 404);
    assert.equal((await post(u, '/api/rooms', { gameId: g.id, max: 1 })).status, 400);
    assert.equal((await post(u, '/api/rooms', { gameId: g.id, max: 999 })).status, 400);
    assert.equal((await post(u, '/api/rooms', { gameId: g.id, inviteTtlMin: -5 })).status, 400);
    const other = await ctx.user('Otro');
    const draft = (await upload(ctx, u.token, { filename: 'a.html', data: GAME_HTML, title: 'Borrador' })).json.game;
    assert.equal((await post(other, '/api/rooms', { gameId: draft.id })).status, 404, 'no se puede crear sala con borrador ajeno');
    assert.equal((await post(u, '/api/rooms', { gameId: draft.id })).status, 201, 'el dueño sí puede probar su borrador');
  });

  test('límite de salas activas por anfitrión', async () => {
    const c2 = await startServer({ maxHostedRooms: 2 });
    try {
      const u = await c2.user('Muchas');
      const g = await publishedGame(c2, u.token);
      assert.equal((await c2.api('POST', '/api/rooms', { token: u.token, body: { gameId: g.id } })).status, 201);
      assert.equal((await c2.api('POST', '/api/rooms', { token: u.token, body: { gameId: g.id } })).status, 201);
      assert.equal((await c2.api('POST', '/api/rooms', { token: u.token, body: { gameId: g.id } })).status, 409);
    } finally { await c2.close(); }
  });

  test('el código no distingue mayúsculas ni guiones; códigos inválidos dan 404 genérico', async () => {
    const { code } = await roomWithPlayers(ctx, ['Hosti']);
    const g1 = await ctx.user('Gus1');
    assert.equal((await post(g1, '/api/rooms/join', { code: code.toLowerCase().replace(/-/g, ' ') })).status, 200);
    const g2 = await ctx.user('Gus2');
    for (const bad of ['', 'ABC', 'AAAA-AAAA-AAAA', null, 123, {}, 'x'.repeat(500)]) {
      const r = await post(g2, '/api/rooms/join', { code: bad });
      assert.equal(r.status, 404, `código ${JSON.stringify(bad)}`);
      assert.equal(r.json.error.code, 'invalid_code');
    }
  });

  test('capacidad: sala llena y reentrada de un miembro existente', async () => {
    const { code, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto'], { max: 2 });
    const extra = await ctx.user('Extra');
    const r = await post(extra, '/api/rooms/join', { code });
    assert.equal(r.status, 409);
    assert.equal(r.json.error.code, 'room_full');
    assert.equal((await post(players[1], '/api/rooms/join', { code })).status, 200, 'un miembro puede volver a entrar');
  });

  test('solo los miembros ven una sala; las demás reciben 404', async () => {
    const { room } = await roomWithPlayers(ctx, ['Hosti']);
    const ajeno = await ctx.user('Ajeno');
    assert.equal((await ctx.api('GET', `/api/rooms/${room.id}`, { token: ajeno.token })).status, 404);
    assert.equal((await post(ajeno, `/api/rooms/${room.id}/ticket`)).status, 404);
    assert.equal((await post(ajeno, `/api/rooms/${room.id}/state`, { state: 'starting' })).status, 404);
    assert.ok(!(await ctx.api('GET', '/api/rooms', { token: ajeno.token })).json.rooms.some((x) => x.id === room.id));
  });

  test('revocar, regenerar y caducidad de la invitación (validadas en el servidor)', async () => {
    const { room, host } = await roomWithPlayers(ctx, ['Hosti']);
    const url = `/api/rooms/${room.id}/invite`;
    const a = await ctx.user('Alba');
    assert.equal((await post(host, url, { action: 'revoke' })).json.room.invite.revoked, true);
    const rv = await post(a, '/api/rooms/join', { code: room.invite.code });
    assert.equal(rv.status, 403); assert.equal(rv.json.error.code, 'invite_revoked');
    const reg = (await post(host, url, { action: 'regenerate' })).json.room.invite;
    assert.notEqual(reg.code, room.invite.code);
    assert.equal(reg.revoked, false);
    assert.equal((await post(a, '/api/rooms/join', { code: room.invite.code })).status, 404, 'el código viejo ya no existe');
    assert.equal((await post(a, '/api/rooms/join', { code: reg.code })).status, 200);
    assert.equal((await post(a, url, { action: 'revoke' })).status, 403, 'un invitado no puede revocar');
    assert.equal((await post(host, url, { action: 'explotar' })).status, 400);

    const ttl = await post(host, url, { action: 'regenerate', ttlMin: 10 });
    const code = ttl.json.room.invite.code;
    const b = await ctx.user('Bruno');
    const real = ctx.srv.rooms.now;
    ctx.srv.rooms.now = () => Date.now() + 11 * 60_000;
    try {
      const ex = await post(b, '/api/rooms/join', { code });
      assert.equal(ex.status, 403); assert.equal(ex.json.error.code, 'invite_expired');
      assert.equal((await ctx.api('GET', `/api/rooms/${room.id}`, { token: host.token })).json.room.invite.expired, true);
    } finally { ctx.srv.rooms.now = real; }
    assert.equal((await post(b, '/api/rooms/join', { code })).status, 200, 'antes de caducar sí funcionaba');
  });

  test('expulsar: solo el anfitrión; el expulsado no puede volver ni conectarse', async () => {
    const { room, host, players, code } = await roomWithPlayers(ctx, ['Hosti', 'Beto', 'Carla']);
    const [, b, c] = players;
    assert.equal((await post(b, `/api/rooms/${room.id}/kick`, { userId: c.id })).status, 403);
    assert.equal((await post(host, `/api/rooms/${room.id}/kick`, { userId: host.id })).status, 400);
    assert.equal((await post(host, `/api/rooms/${room.id}/kick`, { userId: 'u_nadie' })).status, 404);
    const k = await post(host, `/api/rooms/${room.id}/kick`, { userId: c.id });
    assert.equal(k.status, 200);
    assert.equal(k.json.room.players.length, 2);
    assert.equal((await ctx.api('GET', `/api/rooms/${room.id}`, { token: c.token })).status, 404);
    const rj = await post(c, '/api/rooms/join', { code });
    assert.equal(rj.status, 403); assert.equal(rj.json.error.code, 'kicked');
    assert.equal((await post(c, `/api/rooms/${room.id}/ticket`)).status, 404);
  });

  test('salir; si sale el anfitrión el rol pasa a otro; si sale el último la sala se cierra', async () => {
    const { room, host, players, code } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const b = players[1];
    assert.equal((await post(host, `/api/rooms/${room.id}/leave`)).status, 200);
    const v = (await ctx.api('GET', `/api/rooms/${room.id}`, { token: b.token })).json.room;
    assert.equal(v.hostId, b.id);
    assert.equal(v.isHost, true);
    assert.ok(v.invite, 'el nuevo anfitrión ve la invitación');
    assert.equal((await ctx.api('GET', `/api/rooms/${room.id}`, { token: host.token })).status, 404);
    await post(b, `/api/rooms/${room.id}/leave`);
    const late = await ctx.user('Tarde');
    assert.equal((await post(late, '/api/rooms/join', { code })).status, 410);
  });

  test('máquina de estados: transiciones válidas e inválidas', async () => {
    const { room, host, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const st = (u, state) => post(u, `/api/rooms/${room.id}/state`, { state });
    assert.equal((await st(players[1], 'starting')).status, 403, 'solo el anfitrión');
    assert.equal((await st(host, 'playing')).status, 409, 'waiting → playing no existe');
    assert.equal((await st(host, 'closed')).status, 409);
    assert.equal((await st(host, 'inventado')).status, 400);
    assert.equal((await st(host, 'starting')).json.room.state, 'starting');
    assert.equal((await st(host, 'waiting')).status, 409, 'starting → waiting no existe');
    await until(async () => (await ctx.api('GET', `/api/rooms/${room.id}`, { token: host.token })).json.room.state === 'playing');
    const late = await ctx.user('Tarde');
    const rs = await post(late, '/api/rooms/join', { code: room.invite.code });
    assert.equal(rs.status, 409); assert.equal(rs.json.error.code, 'room_started');
    assert.equal((await st(host, 'waiting')).json.room.state, 'waiting', 'playing → waiting (volver al lobby)');
    assert.equal((await st(host, 'closing')).json.room.state, 'closing');
    await until(async () => (await ctx.api('GET', `/api/rooms/${room.id}`, { token: host.token })).json.room?.state === 'closed');
    const after = await st(host, 'waiting');
    assert.equal(after.status, 410);
  });

  test('ajustes: nombre y máximo respetan límites y miembros actuales', async () => {
    const { room, host } = await roomWithPlayers(ctx, ['Hosti', 'Beto', 'Carla']);
    const s = (b) => post(host, `/api/rooms/${room.id}/settings`, b);
    assert.equal((await s({ name: 'Sala nueva' })).json.room.name, 'Sala nueva');
    assert.equal((await s({ max: 2 })).status, 409, 'hay 3 jugadores');
    assert.equal((await s({ max: 1 })).status, 400);
    assert.equal((await s({ max: 3 })).json.room.max, 3);
  });

  test('no se puede eliminar un juego ni una versión con una sala activa', async () => {
    const { game, host } = await roomWithPlayers(ctx, ['Hosti']);
    const r = await ctx.api('DELETE', `/api/games/${game.id}`, { token: host.token });
    assert.equal(r.status, 409);
  });

  test('un juego despublicado sigue sirviéndose mientras haya sala activa', async () => {
    const { game, host, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    await ctx.api('PATCH', `/api/games/${game.id}`, { token: host.token, body: { published: false } });
    const room = (await ctx.api('GET', '/api/rooms', { token: players[1].token })).json.rooms[0];
    assert.equal((await fetch(ctx.base + room.game.playUrl)).status, 200);
  });

  test('límite de intentos de unión por IP: 429', async () => {
    const { code } = await roomWithPlayers(ctx, ['Hosti']);
    const u = await ctx.user('Fuerza bruta');
    let last;
    for (let i = 0; i < 35; i++) last = await post(u, '/api/rooms/join', { code: 'AAAA-BBBB-CCCC' });
    assert.equal(last.status, 429);
    assert.ok(Number(last.headers.get('retry-after')) >= 1);
    assert.ok(code);
  });
});

describe('Mantenimiento de salas (sweep)', () => {
  test('expiración de sala, abandono por desconexión y traspaso de anfitrión', async () => {
    const ctx = await startServer({ roomTtlMs: 60 * 60_000 });
    try {
      const { room, host, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
      const real = ctx.srv.rooms.now;
      const get = async (u) => ctx.api('GET', `/api/rooms/${room.id}`, { token: u.token });
      // nadie conectado: tras 46 s en espera el invitado libera su sitio; el anfitrión mantiene su sala
      ctx.srv.rooms.now = () => Date.now() + 46_000;
      ctx.srv.rooms.sweep();
      assert.equal((await get(players[1])).status, 404, 'el invitado desconectado fue retirado');
      assert.equal((await get(host)).status, 200);
      // pasada la hora, la sala expira
      ctx.srv.rooms.now = () => Date.now() + 61 * 60_000;
      ctx.srv.rooms.sweep();
      const v = await get(host);
      assert.ok(v.status === 410 || v.json.room?.state === 'closed' || v.status === 404, `estado inesperado ${v.status}`);
      const j = await ctx.api('POST', '/api/rooms/join', { token: (await ctx.user('Zeta')).token, body: { code: room.invite.code } });
      assert.ok([410, 404].includes(j.status));
      ctx.srv.rooms.now = real;
    } finally { await ctx.close(); }
  });

  test('salas inactivas se cierran y las cerradas se borran tras el periodo de retención', async () => {
    const ctx = await startServer({ roomIdleMs: 1000, closedRoomKeepMs: 5000 });
    try {
      const { room, host } = await roomWithPlayers(ctx, ['Hosti']);
      const real = ctx.srv.rooms.now;
      ctx.srv.rooms.now = () => Date.now() + 2000;
      ctx.srv.rooms.sweep();
      assert.equal(ctx.srv.rooms.rooms[room.id].state, 'closed');
      ctx.srv.rooms.now = () => Date.now() + 10_000;
      ctx.srv.rooms.sweep();
      assert.equal(ctx.srv.rooms.rooms[room.id], undefined);
      assert.equal((await ctx.api('GET', `/api/rooms/${room.id}`, { token: host.token })).status, 404);
      ctx.srv.rooms.now = real;
    } finally { await ctx.close(); }
  });
});
