import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startServer, sleep, until, roomWithPlayers, ticketFor, wsFor, connectWs } from './helpers.js';

const post = (ctx, u, url, body) => ctx.api('POST', url, { token: u.token, body });

describe('Tiempo real (WebSocket)', () => {
  let ctx;
  before(async () => { ctx = await startServer({ closeDelayMs: 20, startTimeoutMs: 300 }); });
  after(() => ctx.close());

  test('el ticket es de un solo uso y un ticket falso se rechaza con 4004', async () => {
    const { room, host } = await roomWithPlayers(ctx, ['Hosti']);
    const t = await ticketFor(ctx, host, room.id);
    const a = connectWs(ctx.base, t); await a.opened;
    await a.waitFor((m) => m.t === 'hello');
    const b = connectWs(ctx.base, t); await b.opened.catch(() => {});
    assert.equal((await b.waitClose()).code, 4004, 'reutilizar el ticket falla');
    const c = connectWs(ctx.base, 'inventado'); await c.opened.catch(() => {});
    assert.equal((await c.waitClose()).code, 4004);
    a.ws.close();
  });

  test('un ticket caducado no sirve', async () => {
    const { room, host } = await roomWithPlayers(ctx, ['Hosti']);
    const t = await ticketFor(ctx, host, room.id);
    const real = ctx.srv.realtime.now;
    ctx.srv.realtime.now = () => Date.now() + 60_000;
    try {
      const c = connectWs(ctx.base, t); await c.opened.catch(() => {});
      assert.equal((await c.waitClose()).code, 4004);
    } finally { ctx.srv.realtime.now = real; }
  });

  test('hello trae identidad, sala, jugadores y estados; los eventos llegan a los demás pero no al emisor', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto', 'Carla']);
    const [h, b, c] = await Promise.all(players.map((p) => wsFor(ctx, p, room.id)));
    const hello = h.of('hello')[0];
    assert.equal(hello.v, 1);
    assert.equal(hello.you.id, players[0].id);
    assert.equal(hello.you.host, true);
    assert.equal(hello.room.id, room.id);
    assert.equal(hello.players.length, 3);
    assert.equal(b.of('hello')[0].you.host, false);
    // presencia
    await h.waitFor((m) => m.t === 'players' && m.change?.type === 'online' && m.change.id === players[2].id);
    await until(() => h.ofPlayers = h.of('players').at(-1)?.list.filter((p) => p.online).length === 3);
    // la sala debe estar jugando para aceptar eventos
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'starting' });
    await h.waitFor((m) => m.t === 'room' && m.room.state === 'playing', 4000);
    b.send({ t: 'ev', n: 'hola', d: { x: 1 } });
    const got = await c.waitFor((m) => m.t === 'ev' && m.n === 'hola');
    assert.deepEqual(got.d, { x: 1 });
    assert.equal(got.from, players[1].id);
    await h.waitFor((m) => m.t === 'ev' && m.n === 'hola');
    await sleep(100);
    assert.equal(b.of('ev').length, 0, 'el emisor no recibe su propio evento');
    // mensaje directo
    b.send({ t: 'ev', n: 'privado', d: 'solo para Carla', to: players[2].id });
    await c.waitFor((m) => m.t === 'ev' && m.n === 'privado');
    await sleep(100);
    assert.ok(!h.of('ev').some((m) => m.n === 'privado'), 'el anfitrión no ve el mensaje directo');
    b.send({ t: 'ev', n: 'privado', to: players[1].id });
    b.send({ t: 'ev', n: 'privado', to: 'u_nadie' });
    await b.waitFor((m) => m.t === 'err' && m.code === 'bad_target');
    [h, b, c].forEach((x) => x.ws.close());
  });

  test('estado por jugador: los que entran tarde reciben los estados; el compartido solo lo cambia el anfitrión', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const [h, b] = await Promise.all(players.slice(0, 2).map((p) => wsFor(ctx, p, room.id)));
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'starting' });
    await h.waitFor((m) => m.t === 'room' && m.room.state === 'playing', 4000);
    h.send({ t: 'st', d: { x: 5, y: 6 } });
    await b.waitFor((m) => m.t === 'st' && m.d.x === 5);
    h.send({ t: 'sh', k: 'tema', d: 'verde' });
    await b.waitFor((m) => m.t === 'sh' && m.k === 'tema' && m.d === 'verde');
    b.send({ t: 'sh', k: 'tema', d: 'rojo' });
    await b.waitFor((m) => m.t === 'err' && m.code === 'forbidden');
    // reconexión de Beto: ve estado previo y compartido
    b.ws.close(); await b.closePromise;
    const b2 = await wsFor(ctx, players[1], room.id);
    const hello = b2.of('hello')[0];
    assert.deepEqual(hello.states[players[0].id], { x: 5, y: 6 });
    assert.equal(hello.shared.tema, 'verde');
    h.send({ t: 'sh', k: 'tema', d: null });
    h.send({ t: 'sh', k: 'bad key!', d: 1 });
    await h.waitFor((m) => m.t === 'err' && m.code === 'bad_key');
    h.send({ t: 'sh', k: 'grande', d: 'x'.repeat(5000) });
    await h.waitFor((m) => m.t === 'err' && m.code === 'value_too_large');
    h.send({ t: 'st', d: 'no objeto' });
    await h.waitFor((m) => m.t === 'err' && m.code === 'bad_data');
    h.send({ t: 'st', d: { blob: 'x'.repeat(3000) } });
    await h.waitFor((m) => m.t === 'err' && m.code === 'state_too_large');
    [h, b2].forEach((x) => x.ws.close());
  });

  test('mensajes inválidos reciben error claro y no tumban la conexión', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti']);
    const h = await wsFor(ctx, players[0], room.id);
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'starting' });
    await h.waitFor((m) => m.t === 'room' && m.room.state === 'playing', 4000);
    const errs = () => h.of('err').map((e) => e.code);
    h.send('{no json'); await until(() => errs().includes('bad_json'));
    h.send('[1,2]'); await until(() => errs().includes('bad_message'));
    h.send({ t: 'volar' }); await until(() => errs().includes('unknown_type'));
    h.send({ t: 'ev', n: 'nombre con espacios' }); await until(() => errs().includes('bad_event_name'));
    h.send({ t: 'ev', n: 'ok', d: { a: { b: { c: { d: { e: { f: { g: 1 } } } } } } } }); await until(() => errs().includes('bad_data'));
    h.send({ t: 'ev', v: 2, n: 'ok' }); await until(() => errs().includes('bad_version'));
    h.send({ t: 'ping', ts: 'x' }); await until(() => errs().includes('bad_ping'));
    h.ws.send(Buffer.from([1, 2, 3])); await until(() => errs().includes('binary_not_allowed'));
    h.send({ t: 'ev', n: 'ok', d: 'y'.repeat(9000) }); await until(() => errs().includes('too_large'));
    h.send({ t: 'ping', ts: 123 });
    assert.equal((await h.waitFor((m) => m.t === 'pong')).ts, 123, 'sigue viva');
    assert.equal(h.closed, null);
    h.ws.close();
  });

  test('un mensaje de más de 16 KB cierra la conexión (1009)', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti']);
    const h = await wsFor(ctx, players[0], room.id);
    h.ws.send(JSON.stringify({ v: 1, t: 'ev', n: 'x', d: 'z'.repeat(20_000) }));
    assert.equal((await h.waitClose()).code, 1009);
  });

  test('eventos antes de empezar la partida se rechazan (bad_state en lobby solo si la sala no está viva)', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const [h, b] = await Promise.all(players.map((p) => wsFor(ctx, p, room.id)));
    h.send({ t: 'ev', n: 'lobby', d: 1 });
    await b.waitFor((m) => m.t === 'ev' && m.n === 'lobby');
    [h, b].forEach((x) => x.ws.close());
  });

  test('aislamiento entre salas: nada cruza de una sala a otra', async () => {
    const r1 = await roomWithPlayers(ctx, ['Sala1a', 'Sala1b']);
    const r2 = await roomWithPlayers(ctx, ['Sala2a', 'Sala2b']);
    const [a1, b1] = await Promise.all(r1.players.map((p) => wsFor(ctx, p, r1.room.id)));
    const [a2, b2] = await Promise.all(r2.players.map((p) => wsFor(ctx, p, r2.room.id)));
    a1.send({ t: 'ev', n: 'secreto', d: 'sala1' });
    await b1.waitFor((m) => m.t === 'ev' && m.n === 'secreto');
    a1.send({ t: 'st', d: { v: 1 } });
    await sleep(150);
    assert.equal(a2.of('ev').length + b2.of('ev').length + a2.of('st').length + b2.of('st').length, 0);
    // un jugador de la sala 2 no puede pedir ticket para la sala 1
    assert.equal((await post(ctx, r2.players[0], `/api/rooms/${r1.room.id}/ticket`)).status, 404);
    // y a1 no puede apuntar a un jugador de otra sala
    a1.send({ t: 'ev', n: 'x', to: r2.players[0].id });
    await a1.waitFor((m) => m.t === 'err' && m.code === 'bad_target');
    [a1, b1, a2, b2].forEach((x) => x.ws.close());
  });

  test('presencia: online/offline se anuncia; una segunda conexión del mismo jugador reemplaza a la primera (4003)', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const h = await wsFor(ctx, players[0], room.id);
    const b = await wsFor(ctx, players[1], room.id);
    await h.waitFor((m) => m.t === 'players' && m.change?.type === 'online' && m.change.id === players[1].id);
    const b2 = await wsFor(ctx, players[1], room.id);
    assert.equal((await b.waitClose()).code, 4003);
    assert.ok(b.of('bye').some((m) => m.reason === 'replaced'));
    await sleep(100);
    const list = h.of('players').at(-1).list;
    assert.equal(list.find((p) => p.id === players[1].id).online, true, 'sigue online gracias a la conexión nueva');
    b2.ws.close();
    await h.waitFor((m) => m.t === 'players' && m.change?.type === 'offline' && m.change.id === players[1].id);
    h.ws.close();
  });

  test('expulsar cierra el socket con 4005; salir con 4006; cerrar la sala con 4001', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto', 'Carla']);
    const [h, b, c] = await Promise.all(players.map((p) => wsFor(ctx, p, room.id)));
    await post(ctx, players[0], `/api/rooms/${room.id}/kick`, { userId: players[1].id });
    assert.equal((await b.waitClose()).code, 4005);
    assert.ok(b.of('bye').some((m) => m.reason === 'kicked'));
    await post(ctx, players[2], `/api/rooms/${room.id}/leave`);
    assert.equal((await c.waitClose()).code, 4006);
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'closing' });
    assert.equal((await h.waitClose()).code, 4001);
    assert.ok(h.of('bye').some((m) => m.reason === 'room_closed'));
    // y ya no se puede pedir ticket
    assert.ok([404, 410].includes((await post(ctx, players[0], `/api/rooms/${room.id}/ticket`)).status));
  });

  test('starting → playing cuando todos están listos y también por tiempo', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const [h, b] = await Promise.all(players.map((p) => wsFor(ctx, p, room.id)));
    const t0 = Date.now();
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'starting' });
    await h.waitFor((m) => m.t === 'room' && m.room.state === 'starting');
    h.send({ t: 'ready' }); b.send({ t: 'ready' });
    await h.waitFor((m) => m.t === 'room' && m.room.state === 'playing', 2000);
    assert.ok(Date.now() - t0 < 280, 'pasó a jugando sin esperar el tiempo máximo');
    // por tiempo: solo uno listo
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'waiting' });
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'starting' });
    h.msgs.length = 0;
    h.send({ t: 'ready' });
    await h.waitFor((m) => m.t === 'room' && m.room.state === 'playing', 2000);
    [h, b].forEach((x) => x.ws.close());
  });

  test('volver al lobby limpia el estado compartido y los estados de jugador', async () => {
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const [h, b] = await Promise.all(players.map((p) => wsFor(ctx, p, room.id)));
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'starting' });
    await h.waitFor((m) => m.t === 'room' && m.room.state === 'playing', 4000);
    h.send({ t: 'sh', k: 'a', d: 1 }); h.send({ t: 'st', d: { q: 1 } });
    await b.waitFor((m) => m.t === 'sh');
    await post(ctx, players[0], `/api/rooms/${room.id}/state`, { state: 'waiting' });
    await b.waitFor((m) => m.t === 'room' && m.room.state === 'waiting');
    b.ws.close(); await b.closePromise;
    const b2 = await wsFor(ctx, players[1], room.id);
    assert.deepEqual(b2.of('hello')[0].shared, {});
    assert.deepEqual(b2.of('hello')[0].states, {});
    [h, b2].forEach((x) => x.ws.close());
  });
});

describe('Límites de conexión', () => {
  test('origen distinto del host: 4010; navegadores del mismo origen: permitido', async () => {
    const ctx = await startServer();
    try {
      const { room, players } = await roomWithPlayers(ctx, ['Hosti']);
      const bad = connectWs(ctx.base, await ticketFor(ctx, players[0], room.id), { origin: 'https://evil.example' });
      await bad.opened.catch(() => {});
      assert.equal((await bad.waitClose()).code, 4010);
      const ok = connectWs(ctx.base, await ticketFor(ctx, players[0], room.id), { origin: ctx.base });
      await ok.opened;
      await ok.waitFor((m) => m.t === 'hello');
      ok.ws.close();
    } finally { await ctx.close(); }
  });

  test('máximo de conexiones por IP: 1013', async () => {
    const ctx = await startServer({ wsMaxPerIp: 2 });
    try {
      const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto', 'Carla']);
      const a = await wsFor(ctx, players[0], room.id);
      const b = await wsFor(ctx, players[1], room.id);
      const c = connectWs(ctx.base, await ticketFor(ctx, players[2], room.id)); await c.opened.catch(() => {});
      assert.equal((await c.waitClose()).code, 1013);
      a.ws.close(); b.ws.close();
    } finally { await ctx.close(); }
  });

  test('límite de ritmo: ráfagas excesivas se descartan con aviso y los abusos graves cierran (4008)', async () => {
    const ctx = await startServer({ wsRatePerSec: 5, wsBurst: 10 });
    try {
      const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
      const [h, b] = await Promise.all(players.map((p) => wsFor(ctx, p, room.id)));
      for (let i = 0; i < 40; i++) h.send({ t: 'ev', n: 'spam', d: i });
      await h.waitFor((m) => m.t === 'err' && m.code === 'rate_limited');
      await sleep(200);
      assert.ok(b.of('ev').length <= 12, `llegaron ${b.of('ev').length}, deberían limitarse`);
      // la otra persona no se ve afectada
      b.send({ t: 'ping', ts: 1 });
      await b.waitFor((m) => m.t === 'pong');
      for (let i = 0; i < 400; i++) h.send({ t: 'ev', n: 'spam', d: i });
      assert.equal((await h.waitClose(4000)).code, 4008);
    } finally { await ctx.close(); }
  });

  test('demasiados mensajes inválidos seguidos cierran la conexión (4008)', async () => {
    const ctx = await startServer({ wsRatePerSec: 1000, wsBurst: 1000 });
    try {
      const { room, players } = await roomWithPlayers(ctx, ['Hosti']);
      const h = await wsFor(ctx, players[0], room.id);
      for (let i = 0; i < 25; i++) h.ws.send('no json');
      assert.equal((await h.waitClose()).code, 4008);
    } finally { await ctx.close(); }
  });

  test('tras reiniciar el servidor la sala persiste y se puede reconectar con un ticket nuevo', async () => {
    const dataDir = (await import('./helpers.js')).tmpDir();
    let ctx = await startServer({ dataDir });
    const { room, players } = await roomWithPlayers(ctx, ['Hosti', 'Beto']);
    const h = await wsFor(ctx, players[0], room.id);
    const closed = h.closePromise;
    await ctx.close();
    await closed;
    ctx = await startServer({ dataDir });
    try {
      const v = await ctx.api('GET', `/api/rooms/${room.id}`, { token: players[0].token });
      assert.equal(v.status, 200);
      assert.equal(v.json.room.state, 'waiting');
      const again = await wsFor(ctx, players[0], room.id);
      assert.equal(again.of('hello')[0].you.id, players[0].id);
      assert.equal(again.of('hello')[0].players.find((p) => p.id === players[1].id).online, false);
      again.ws.close();
    } finally { await ctx.close(); }
  });
});
