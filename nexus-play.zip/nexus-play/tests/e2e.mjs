// Prueba de extremo a extremo con navegadores reales (Playwright + Chromium).
// NO forma parte de `npm test` porque necesita Playwright instalado aparte.
//   Uso:  node tests/e2e.mjs            (variable SHOTS=carpeta guarda capturas de pantalla)
// Dos "dispositivos" en el mismo equipo: un escritorio y un teléfono emulado.
// Esto NO sustituye una prueba con un Android físico (ver docs/TESTING.md).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createServer } from '../server/app.js';

const require = createRequire(import.meta.url);
const { chromium, devices } = require('playwright');

const SHOTS = process.env.SHOTS || '';
if (SHOTS) fs.mkdirSync(SHOTS, { recursive: true });

const results = [];
function check(name, ok, detail = '') {
  results.push({ name, ok });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail && !ok ? `  -> ${detail}` : ''}`);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(fn, { timeout = 10000, every = 100 } = {}) {
  const t0 = Date.now();
  for (;;) {
    try { const v = await fn(); if (v) return v; } catch { /* reintentar */ }
    if (Date.now() - t0 > timeout) return false;
    await sleep(every);
  }
}

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-e2e-'));
const srv = await createServer({ dataDir, port: 0, host: '127.0.0.1', quiet: true, startTimeoutMs: 4000 });
await srv.start();
const base = srv.url();
console.log(`Servidor de prueba en ${base}`);

const browser = await chromium.launch({ args: ['--no-sandbox'] });
const errors = { host: [], guest: [] };

async function newDevice(label, contextOpts) {
  const ctx = await browser.newContext(contextOpts);
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors[label].push(`pageerror: ${e.message}`));
  page.on('console', (m) => {
    if (m.type() !== 'error') return;
    const t = m.text();
    if (/WebSocket|Failed to load resource|net::ERR/i.test(t)) return;
    errors[label].push(`console: ${t}`);
  });
  return { ctx, page };
}
const shot = async (page, name) => { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, `${name}.png`), fullPage: false }); };

async function enter(page, name) {
  await page.goto(base);
  await page.waitForSelector('#modal-root input', { timeout: 10000 });
  await page.fill('#modal-root input', name);
  await page.click('#modal-root button:has-text("Entrar")');
  await page.waitForSelector('main h1', { timeout: 10000 });
}

const host = await newDevice('host', { viewport: { width: 1280, height: 800 } });
const guest = await newDevice('guest', { ...devices['Pixel 7'] });
const H = host.page;
const G = guest.page;

try {
  // ---------- Entrada como invitado ----------
  await enter(H, 'Ana');
  check('PC: entra como invitado y ve el panel', (await H.textContent('main h1')).includes('Panel de control'));
  await shot(H, '01-dashboard-pc');
  await enter(G, 'Beto');
  check('Móvil: entra como invitado y ve el panel', (await G.textContent('main h1')).includes('Panel de control'));
  await shot(G, '02-dashboard-movil');

  // ---------- Biblioteca y demo ----------
  await H.goto(`${base}/#/games`);
  await H.waitForSelector('.game-title');
  check('La biblioteca muestra el juego demo incluido', (await H.textContent('.game-title')).includes('Cuadrados'));
  await shot(H, '03-biblioteca-pc');

  // ---------- Crear sala ----------
  await H.click('.card button:has-text("Crear sala")');
  await H.waitForSelector('#modal-root select');
  await H.fill('#modal-root input[type=text]', 'Sala de prueba');
  await H.click('#modal-root button:has-text("Crear sala")');
  await H.waitForSelector('.code', { timeout: 10000 });
  const code = (await H.textContent('.code')).trim();
  const roomUrl = H.url();
  check('El anfitrión crea una sala y obtiene un código de invitación', /^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(code), code);
  check('El anfitrión se ve conectado', !!(await until(async () => (await H.textContent('.room-head .conn')).includes('Conectado'))));
  await shot(H, '04-sala-espera-pc');

  // ---------- Invitado entra con el código ----------
  await G.goto(`${base}/#/rooms`);
  await G.waitForSelector('[aria-label="Código de invitación"]');
  await G.fill('[aria-label="Código de invitación"]', code.toLowerCase());
  await G.click('button:has-text("Entrar")');
  await G.waitForSelector('.room-head', { timeout: 10000 });
  check('El invitado entra a la sala con el código', true);
  check('El invitado se ve conectado', !!(await until(async () => (await G.textContent('.room-head .conn')).includes('Conectado'))));
  check('El anfitrión ve a 2 jugadores conectados', !!(await until(async () => (await H.locator('.pl .dot.ok').count()) === 2)));
  check('El invitado no ve el código de invitación', (await G.locator('.code').count()) === 0);
  await shot(G, '05-sala-espera-movil');

  // ---------- Iniciar partida ----------
  await H.click('button:has-text("Iniciar partida")');
  check('La partida pasa a "Jugando" en ambos dispositivos', !!(await until(async () => (await H.textContent('.room-head')).includes('Jugando') && (await G.textContent('.room-head')).includes('Jugando'), { timeout: 15000 })));
  const hf = H.frames().find((f) => f.url().includes('/g/'));
  const gf = G.frames().find((f) => f.url().includes('/g/'));
  check('Ambos cargan el juego en un iframe aislado', !!hf && !!gf);
  const sbHost = await H.getAttribute('iframe', 'sandbox');
  check('El iframe NO tiene allow-same-origin', !!sbHost && !sbHost.includes('allow-same-origin'), sbHost);

  // El juego (origen "null") no puede leer el panel ni el almacenamiento
  const iso = await hf.evaluate(() => {
    const r = {};
    try { r.parent = typeof window.parent.document.title; } catch { r.parent = 'bloqueado'; }
    try { localStorage.setItem('x', '1'); r.ls = 'permitido'; } catch { r.ls = 'bloqueado'; }
    try { r.cookie = document.cookie === '' ? 'vacío' : 'datos'; } catch { r.cookie = 'bloqueado'; }
    return r;
  });
  check('El juego no puede leer el documento del panel', iso.parent === 'bloqueado', JSON.stringify(iso));
  check('El juego no tiene localStorage ni cookies del panel', iso.ls === 'bloqueado' && iso.cookie !== 'datos', JSON.stringify(iso));

  // ---------- Conexión SDK ----------
  const ids = await until(async () => {
    const [a, b] = await Promise.all([
      hf.evaluate(() => NexusPlay.connect().then((n) => ({ me: n.me.id, host: n.isHost, players: n.players.length }))),
      gf.evaluate(() => NexusPlay.connect().then((n) => ({ me: n.me.id, host: n.isHost, players: n.players.length }))),
    ]);
    return a.players === 2 && b.players === 2 ? { a, b } : null;
  }, { timeout: 10000 });
  check('El SDK conecta en ambos juegos y ven 2 jugadores', !!ids);
  check('El SDK identifica al anfitrión', !!ids && ids.a.host === true && ids.b.host === false);

  // ---------- Estado sincronizado (posición) ----------
  await gf.evaluate(() => { window.__evs = []; NexusPlay.connect().then((n) => n.on('event:saludo', (d, from) => window.__evs.push(from.id))); });
  const before = await gf.evaluate(() => NexusPlay.connect().then((n) => JSON.stringify(n.getStates())));
  await hf.locator('canvas').click({ position: { x: 100, y: 100 } });
  await H.keyboard.down('ArrowRight');
  await H.keyboard.down('ArrowDown');
  await sleep(900);
  await H.keyboard.up('ArrowRight');
  await H.keyboard.up('ArrowDown');
  const moved = await until(async () => {
    const st = await gf.evaluate((hid) => NexusPlay.connect().then((n) => n.getStates()[hid]), ids.a.me);
    const st0 = JSON.parse(before)[ids.a.me];
    return st && (!st0 || st.x > st0.x + 0.03 || st.y > st0.y + 0.03) ? st : null;
  }, { timeout: 8000 });
  check('El movimiento del anfitrión llega al invitado (estado real entre clientes)', !!moved, JSON.stringify(moved));

  // ---------- Evento puntual ----------
  await hf.click('#wave');
  check('Un evento del anfitrión llega al invitado', !!(await until(async () => (await gf.evaluate(() => window.__evs.length)) >= 1, { timeout: 6000 })));

  // ---------- Estado compartido (solo anfitrión) ----------
  await hf.click('#theme');
  check('El valor compartido del anfitrión llega al invitado', !!(await until(async () => (await gf.evaluate(() => NexusPlay.connect().then((n) => n.getShared().tema))) === 1, { timeout: 6000 })));
  const guestShared = await gf.evaluate(() => NexusPlay.connect().then((n) => { try { n.setShared('tema', 3); return 'permitido'; } catch (e) { return e.code; } }));
  check('El invitado NO puede modificar el estado compartido', guestShared === 'forbidden', guestShared);
  const hiddenTheme = await gf.locator('#theme').isHidden();
  check('El botón de anfitrión está oculto para el invitado', hiddenTheme);
  await shot(G, '06-partida-movil');
  await shot(H, '07-partida-pc');

  // ---------- Latencia ----------
  const rtt = await hf.evaluate(() => NexusPlay.connect().then((n) => n.ping()));
  check('La latencia se puede medir desde el SDK', typeof rtt === 'number' && rtt >= 0 && rtt < 2000, String(rtt));

  // ---------- Desconexión y reconexión automática ----------
  const guestConn = [...srv.realtime.conns].find((c) => c.name === 'Beto');
  guestConn.ws.terminate();
  check('El anfitrión ve al invitado desconectado', !!(await until(async () => (await H.locator('.badge.off').count()) >= 1, { timeout: 6000 })));
  check('El invitado se reconecta solo', !!(await until(async () => (await G.textContent('.room-head .conn')).includes('Conectado') && [...srv.realtime.conns].some((c) => c.name === 'Beto'), { timeout: 15000 })));
  check('Tras reconectar el anfitrión lo ve conectado otra vez', !!(await until(async () => (await H.locator('.badge.off').count()) === 0, { timeout: 8000 })));
  const stillStates = await gf.evaluate((hid) => NexusPlay.connect().then((n) => !!n.getStates()[hid]), ids.a.me);
  check('Tras reconectar el juego conserva el estado de los demás', stillStates);

  // ---------- Recarga de página ----------
  await G.reload();
  await G.waitForSelector('.room-head', { timeout: 15000 });
  check('Al recargar la página el invitado vuelve a la misma sala', !!(await until(async () => (await G.textContent('.room-head')).includes('Jugando') && G.frames().some((f) => f.url().includes('/g/')), { timeout: 15000 })));
  check('Tras recargar el invitado aparece conectado', !!(await until(async () => (await G.textContent('.room-head .conn')).includes('Conectado'))));

  // ---------- Volver a la sala, expulsar y cerrar ----------
  await H.click('button:has-text("Volver a la sala")');
  check('El anfitrión puede volver a la sala de espera', !!(await until(async () => (await H.locator('.code').count()) === 1 && (await G.textContent('.room-head')).includes('Esperando'), { timeout: 8000 })));
  await H.click('.pl button:has-text("Expulsar")');
  await H.click('#modal-root button:has-text("Expulsar")');
  check('El invitado expulsado ve el aviso y no puede volver', !!(await until(async () => (await G.textContent('main')).includes('expulsó'), { timeout: 8000 })));
  const rejoin = await G.evaluate(async (c) => {
    const s = JSON.parse(localStorage.getItem('nexus.session'));
    const r = await fetch('/api/rooms/join', { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${s.token}` }, body: JSON.stringify({ code: c }) });
    return r.status;
  }, code);
  check('El expulsado no puede reentrar con el mismo código (403)', rejoin === 403, String(rejoin));
  await shot(G, '08-expulsado-movil');

  await H.click('button:has-text("Cerrar sala")');
  await H.click('#modal-root button:has-text("Cerrar sala")');
  check('El anfitrión cierra la sala', !!(await until(async () => (await H.textContent('main')).includes('La partida terminó'), { timeout: 8000 })));
  const afterClose = await G.evaluate(async (c) => {
    const s = JSON.parse(localStorage.getItem('nexus.session'));
    const r = await fetch('/api/rooms/join', { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${s.token}` }, body: JSON.stringify({ code: c }) });
    return r.status;
  }, code);
  check('Una sala cerrada ya no admite entradas', afterClose === 410 || afterClose === 403, String(afterClose));

  // ---------- Subida de un juego por la interfaz + asistente de integración ----------
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-up-'));
  const gameFile = path.join(tmp, 'mi-juego.html');
  fs.writeFileSync(gameFile, `<!doctype html><html><head><title>t</title></head><body><canvas id="c"></canvas><script>
    let player = { x: 10, y: 10, score: 0 };
    const ctx = document.getElementById('c').getContext('2d');
    window.addEventListener('keydown', e => { player.x += 5; });
    function loop(){ ctx.fillRect(player.x, player.y, 10, 10); requestAnimationFrame(loop); }
    loop();
    try { localStorage.setItem('a','b'); } catch(e) {}
  </script></body></html>`);
  await H.goto(`${base}/#/upload`);
  await H.waitForSelector('input[type=file]');
  await H.setInputFiles('input[type=file][accept=".html,.htm,.zip"]', gameFile);
  await H.click('button:has-text("Validar y subir")');
  await H.waitForSelector('h1:has-text("Mi juego")', { timeout: 10000 });
  check('Se sube un HTML por la interfaz y se abre su página', true);
  await shot(H, '09-detalle-juego-pc');
  await H.click('button:has-text("Analizar si puede ser multijugador")');
  await H.waitForSelector('text=Cambios que puedo aplicar automáticamente', { timeout: 8000 });
  check('El asistente analiza el juego y propone cambios', true);
  await shot(H, '10-asistente-pc');
  await H.click('button:has-text("Crear versión v2")');
  await H.click('#modal-root button:has-text("Crear versión")');
  check('Aplicar la integración crea la versión 2 y conserva la 1', !!(await until(async () => {
    const t = await H.textContent('main');
    return t.includes('Versiones (2)');
  }, { timeout: 8000 })));
  await shot(H, '11-versiones-pc');

  // ---------- Diagnóstico ----------
  await H.goto(`${base}/#/diag`);
  await H.waitForSelector('text=Conexión con el servidor');
  check('El panel de diagnóstico muestra datos reales', (await H.textContent('main')).includes('Responde'));
  await shot(H, '12-diagnostico-pc');
  await G.goto(`${base}/#/diag`);
  await G.waitForSelector('text=Conexión con el servidor');
  await shot(G, '13-diagnostico-movil');
} catch (e) {
  check('La prueba terminó sin excepciones', false, e.stack || e.message);
  try { await shot(H, 'zz-error-pc'); await shot(G, 'zz-error-movil'); } catch { /* ignorar */ }
}

for (const label of ['host', 'guest']) {
  check(`Sin errores de JavaScript en la consola (${label === 'host' ? 'PC' : 'móvil'})`, errors[label].length === 0, errors[label].slice(0, 3).join(' | '));
}

await browser.close();
await srv.stop();
fs.rmSync(dataDir, { recursive: true, force: true });
const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} comprobaciones superadas`);
process.exit(failed ? 1 : 0);
