import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { sleep } from './helpers.js';

// El SDK es UMD; el paquete es ESM, así que se evalúa como lo haría un navegador (script clásico).
const sandbox = { console, setTimeout, clearTimeout, setInterval, clearInterval, Date, Promise, WeakMap, Object, Array, JSON, Error };
sandbox.self = sandbox;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(new URL('../public/sdk/nexus-sdk.js', import.meta.url), 'utf8'), sandbox);
const NexusPlay = sandbox.NexusPlay;
// Los objetos creados dentro del vm tienen otros prototipos: se comparan como JSON.
const plain = (v) => JSON.parse(JSON.stringify(v));
const same = (a, b, m) => assert.deepStrictEqual(plain(a), plain(b), m);

/** Ventana falsa: `parent` recibe lo que el juego envía; `deliver` simula mensajes del panel. */
function fakeEnv() {
  const sent = [];
  const listeners = [];
  const parent = { postMessage: (m) => sent.push(m) };
  const win = {
    parent,
    addEventListener: (t, fn) => t === 'message' && listeners.push(fn),
    removeEventListener: (t, fn) => { const i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); },
  };
  const deliver = (data, source = parent) => listeners.slice().forEach((fn) => fn({ data, source }));
  const init = (extra = {}) => deliver({
    nexus: 1, type: 'init', meId: 'u1', connection: 'connected',
    room: { id: 'r1', state: 'playing' },
    players: [{ id: 'u1', name: 'Ana', host: true, online: true }, { id: 'u2', name: 'Beto', host: false, online: true }],
    states: { u2: { x: 1 } }, shared: { tema: 'verde' }, ...extra,
  });
  return { win, sent, deliver, init, listeners };
}

async function connected(opts = {}) {
  const env = fakeEnv();
  const p = NexusPlay.connect({ window: env.win, stateIntervalMs: 20, ...opts });
  env.init();
  const nx = await p;
  env.sent.length = 0;
  return { env, nx };
}

describe('SDK NexusPlay', () => {
  test('expone versión y protocolo', () => {
    assert.equal(NexusPlay.version, '1.0.0');
    assert.equal(NexusPlay.protocol, 1);
    assert.equal(typeof NexusPlay.connect, 'function');
  });

  test('fuera de una sala (sin iframe) falla con not_embedded', async () => {
    const win = { addEventListener() {}, removeEventListener() {} }; win.parent = win;
    await assert.rejects(NexusPlay.connect({ window: win }), (e) => e.code === 'not_embedded' && e.name === 'NexusError');
    assert.equal(NexusPlay.isEmbedded(win), false);
  });

  test('connect envía hello, reintenta, y resuelve con init; datos iniciales disponibles', async () => {
    const env = fakeEnv();
    const p = NexusPlay.connect({ window: env.win });
    same(env.sent[0], { type: 'hello', sdk: '1.0.0', nexus: 1 });
    await sleep(450);
    assert.ok(env.sent.length >= 2, 'reintenta el hello');
    env.init();
    const nx = await p;
    assert.equal(nx.me.id, 'u1'); assert.equal(nx.isHost, true); assert.equal(nx.connected, true);
    assert.equal(nx.players.length, 2);
    same(nx.getStates(), { u2: { x: 1 } });
    same(nx.getShared(), { tema: 'verde' });
    assert.equal(nx.getPlayer('u2').name, 'Beto');
    assert.equal(NexusPlay.connect({ window: env.win }), p, 'llamadas repetidas devuelven el mismo cliente');
    nx.leave();
  });

  test('timeout si el panel no responde', async () => {
    const env = fakeEnv();
    await assert.rejects(NexusPlay.connect({ window: env.win, timeout: 60 }), (e) => e.code === 'timeout');
    assert.equal(env.listeners.length, 0, 'se limpió el listener');
  });

  test('ignora mensajes que no vienen del padre o sin el sello nexus', async () => {
    const env = fakeEnv();
    const p = NexusPlay.connect({ window: env.win, timeout: 150 });
    env.deliver({ nexus: 1, type: 'init', meId: 'x', players: [] }, { postMessage() {} }); // otra ventana
    env.deliver({ type: 'init', meId: 'x' });                                              // sin sello
    env.deliver('texto'); env.deliver(null);
    await assert.rejects(p, (e) => e.code === 'timeout');
  });

  test('eventos entrantes: event y event:<nombre>, con el jugador resuelto', async () => {
    const { env, nx } = await connected();
    const seen = [];
    nx.on('event', (n, d, from) => seen.push(['all', n, d, from.name]));
    nx.on('event:disparo', (d, from) => seen.push(['one', d, from.id]));
    env.deliver({ nexus: 1, type: 'event', name: 'disparo', data: { a: 1 }, from: 'u2' });
    same(seen, [['all', 'disparo', { a: 1 }, 'Beto'], ['one', { a: 1 }, 'u2']]);
    env.deliver({ nexus: 1, type: 'event', name: 5 });
    assert.equal(seen.length, 2, 'ignora mensajes mal formados');
    nx.leave();
  });

  test('un manejador que lanza error no impide a los demás', async () => {
    const { env, nx } = await connected();
    const orig = console.error; console.error = () => {};
    let ok = false;
    nx.on('event:x', () => { throw new Error('boom'); });
    nx.on('event:x', () => { ok = true; });
    env.deliver({ nexus: 1, type: 'event', name: 'x', data: 1, from: 'u2' });
    console.error = orig;
    assert.equal(ok, true);
    nx.leave();
  });

  test('on devuelve función para desuscribir; off y once funcionan', async () => {
    const { env, nx } = await connected();
    let n = 0; let o = 0;
    const off = nx.on('event:a', () => n++);
    nx.once('event:a', () => o++);
    const send = () => env.deliver({ nexus: 1, type: 'event', name: 'a', data: null, from: 'u2' });
    send(); send(); off(); send();
    assert.equal(n, 2); assert.equal(o, 1);
    assert.throws(() => nx.on('x'), (e) => e.code === 'bad_argument');
    nx.leave();
  });

  test('presencia: join, leave, online/offline y lista actualizada', async () => {
    const { env, nx } = await connected();
    const log = [];
    ['player:join', 'player:leave', 'player:online', 'player:offline'].forEach((n) => nx.on(n, (p) => log.push([n, p.id])));
    const l3 = [...nx.players, { id: 'u3', name: 'Caro', host: false, online: true }];
    env.deliver({ nexus: 1, type: 'players', list: l3, change: { type: 'join', id: 'u3' } });
    assert.equal(nx.players.length, 3);
    env.deliver({ nexus: 1, type: 'players', list: l3.map((p) => (p.id === 'u2' ? { ...p, online: false } : p)), change: { type: 'offline', id: 'u2' } });
    env.deliver({ nexus: 1, type: 'players', list: l3, change: { type: 'online', id: 'u2' } });
    env.deliver({ nexus: 1, type: 'players', list: l3.slice(0, 2), change: { type: 'kick', id: 'u3' } });
    same(log, [['player:join', 'u3'], ['player:offline', 'u2'], ['player:online', 'u2'], ['player:leave', 'u3']]);
    env.deliver({ nexus: 1, type: 'players', list: nx.players.filter((p) => p.id !== 'u2'), change: { type: 'leave', id: 'u2' } });
    assert.equal(nx.getStates().u2, undefined, 'al salir se olvida su estado');
    nx.leave();
  });

  test('si el anfitrión cambia, isHost se actualiza', async () => {
    const { env, nx } = await connected();
    assert.equal(nx.isHost, true);
    env.deliver({ nexus: 1, type: 'room', room: { id: 'r1', state: 'playing' }, players: [{ id: 'u1', name: 'Ana', host: false, online: true }, { id: 'u2', name: 'Beto', host: true, online: true }] });
    assert.equal(nx.isHost, false);
    assert.throws(() => nx.setShared('k', 1), (e) => e.code === 'forbidden');
    nx.leave();
  });

  test('estado de la sala: room y room:state solo cuando cambia', async () => {
    const { env, nx } = await connected();
    const st = []; let rooms = 0;
    nx.on('room:state', (s, prev) => st.push([s, prev])); nx.on('room', () => rooms++);
    env.deliver({ nexus: 1, type: 'room', room: { id: 'r1', state: 'playing' } });
    env.deliver({ nexus: 1, type: 'room', room: { id: 'r1', state: 'waiting' } });
    same(st, [['waiting', 'playing']]);
    assert.equal(rooms, 2);
    nx.leave();
  });

  test('state y shared entrantes actualizan la caché y emiten eventos', async () => {
    const { env, nx } = await connected();
    const got = [];
    nx.on('state', (id, d) => got.push(['st', id, d])); nx.on('shared', (k, v) => got.push(['sh', k, v]));
    env.deliver({ nexus: 1, type: 'state', from: 'u2', data: { x: 9 } });
    env.deliver({ nexus: 1, type: 'state', from: 'u2', data: 'no' });
    env.deliver({ nexus: 1, type: 'shared', key: 'tema', value: 'rojo' });
    env.deliver({ nexus: 1, type: 'shared', key: 'tema', value: null });
    same(got, [['st', 'u2', { x: 9 }], ['sh', 'tema', 'rojo'], ['sh', 'tema', null]]);
    same(nx.getShared(), {});
    same(nx.getStates().u2, { x: 9 });
    nx.leave();
  });

  test('send valida nombre y tamaño, y envía al panel (con destinatario opcional)', async () => {
    const { env, nx } = await connected();
    assert.equal(nx.send('hola', { a: 1 }), true);
    nx.send('privado', 5, { to: 'u2' });
    same(env.sent[0], { type: 'send', name: 'hola', data: { a: 1 }, nexus: 1 });
    assert.equal(env.sent[1].to, 'u2');
    nx.send('sin-datos');
    assert.equal(env.sent[2].data, null);
    for (const bad of ['', 'con espacios', 'x'.repeat(33), 5, null]) assert.throws(() => nx.send(bad), (e) => e.code === 'bad_event_name', String(bad));
    assert.throws(() => nx.send('x', 'y'.repeat(8000)), (e) => e.code === 'too_large');
    const circ = {}; circ.c = circ;
    assert.throws(() => nx.send('x', circ), (e) => e.code === 'bad_data');
    nx.leave();
  });

  test('setState agrupa envíos (throttle), manda siempre el último y valida', async () => {
    const { env, nx } = await connected({ stateIntervalMs: 40 });
    nx.setState({ x: 1 });
    nx.setState({ x: 2 }); nx.setState({ x: 3 }); nx.setState({ x: 4 });
    assert.equal(env.sent.length, 1, 'solo el primero sale de inmediato');
    same(env.sent[0].data, { x: 1 });
    await sleep(90);
    assert.equal(env.sent.length, 2);
    same(env.sent[1].data, { x: 4 }, 'lo último gana');
    same(nx.getStates().u1, { x: 4 }, 'el estado propio es inmediato en local');
    assert.throws(() => nx.setState('texto'), (e) => e.code === 'bad_state');
    assert.throws(() => nx.setState([1]), (e) => e.code === 'bad_state');
    assert.throws(() => nx.setState({ b: 'x'.repeat(2000) }), (e) => e.code === 'too_large');
    nx.leave();
  });

  test('setShared (anfitrión) valida clave y tamaño', async () => {
    const { env, nx } = await connected();
    nx.setShared('tema', 'azul');
    same(env.sent[0], { type: 'shared', key: 'tema', value: 'azul', nexus: 1 });
    nx.setShared('tema', undefined);
    assert.equal(env.sent[1].value, null);
    assert.throws(() => nx.setShared('mala clave', 1), (e) => e.code === 'bad_key');
    assert.throws(() => nx.setShared('k', 'z'.repeat(4000)), (e) => e.code === 'too_large');
    nx.leave();
  });

  test('ping mide la latencia y da timeout si no hay respuesta', async () => {
    const { env, nx } = await connected();
    const p = nx.ping();
    const id = env.sent.at(-1).id;
    env.deliver({ nexus: 1, type: 'pong', id, rtt: 42 });
    assert.equal(await p, 42);
    await assert.rejects(nx.ping(40), (e) => e.code === 'timeout');
    nx.leave();
  });

  test('ready, connection, error y closed', async () => {
    const { env, nx } = await connected();
    nx.ready();
    assert.equal(env.sent.at(-1).type, 'ready');
    const log = [];
    nx.on('connection', (s) => log.push(['c', s])); nx.on('error', (e) => log.push(['e', e.code]));
    nx.on('closed', (r) => log.push(['x', r]));
    env.deliver({ nexus: 1, type: 'connection', status: 'reconnecting' });
    assert.equal(nx.connected, false);
    env.deliver({ nexus: 1, type: 'connection', status: 'connected' });
    env.deliver({ nexus: 1, type: 'error', code: 'rate_limited', message: 'm' });
    env.deliver({ nexus: 1, type: 'closed', reason: 'kicked' });
    same(log, [['c', 'reconnecting'], ['c', 'connected'], ['e', 'rate_limited'], ['x', 'kicked']]);
    assert.throws(() => nx.send('x'), (e) => e.code === 'closed');
    assert.equal(env.listeners.length, 0);
  });

  test('leave avisa al panel una sola vez y deja de escuchar', async () => {
    const { env, nx } = await connected();
    nx.leave(); nx.leave();
    assert.equal(env.sent.filter((m) => m.type === 'leave').length, 1);
    assert.equal(env.listeners.length, 0);
    assert.throws(() => nx.ready(), (e) => e.code === 'closed');
  });
});
