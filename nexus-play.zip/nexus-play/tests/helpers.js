import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';
import WebSocket from 'ws';
import { createServer } from '../server/app.js';

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function until(fn, { timeout = 4000, every = 15 } = {}) {
  const t0 = Date.now();
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() - t0 > timeout) throw new Error('until: tiempo agotado');
    await sleep(every);
  }
}

export function tmpDir(prefix = 'nexus-test-') {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

/** Arranca un servidor real en un puerto libre con carpeta de datos temporal. */
export async function startServer(overrides = {}) {
  const dataDir = overrides.dataDir || tmpDir();
  const srv = await createServer({ dataDir, port: 0, host: '127.0.0.1', quiet: true, seedDemo: false, ...overrides });
  await srv.start();
  const base = srv.url();
  const api = async (method, url, { token, body, headers = {}, raw } = {}) => {
    const h = { ...headers };
    if (token) h.authorization = `Bearer ${token}`;
    let payload = raw;
    if (body !== undefined) { h['content-type'] = 'application/json'; payload = JSON.stringify(body); }
    const res = await fetch(base + url, { method, headers: h, body: payload });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* no JSON */ }
    return { status: res.status, json, text, headers: res.headers };
  };
  const user = async (name) => {
    const r = await api('POST', '/api/session', { body: { name } });
    if (r.status !== 201) throw new Error(`no se pudo crear sesión: ${r.text}`);
    return { token: r.json.token, id: r.json.user.id, name };
  };
  const close = async () => { await srv.stop(); };
  return { srv, base, dataDir, api, user, close };
}

/** Sube un archivo (HTML o ZIP) como crearía el navegador. */
export function upload(ctx, token, { filename, data, title = 'Juego de prueba', description = '', gameId, note }) {
  const qs = gameId
    ? `/api/games/${gameId}/versions?filename=${encodeURIComponent(filename)}&note=${encodeURIComponent(note || '')}`
    : `/api/games?title=${encodeURIComponent(title)}&description=${encodeURIComponent(description)}&filename=${encodeURIComponent(filename)}`;
  return ctx.api('POST', qs, { token, raw: data, headers: { 'content-type': 'application/octet-stream' } });
}

export const GAME_HTML = '<!doctype html><html><head><title>t</title></head><body><canvas></canvas><script>var player={x:1};requestAnimationFrame(function(){});</script></body></html>';

/** Crea un juego publicado y devuelve su vista. */
export async function publishedGame(ctx, token, title = 'Juego publicado') {
  const up = await upload(ctx, token, { filename: 'a.html', data: GAME_HTML, title });
  if (up.status !== 201) throw new Error(up.text);
  const pub = await ctx.api('PATCH', `/api/games/${up.json.game.id}`, { token, body: { published: true } });
  return pub.json.game;
}

// ---------- Constructor de ZIP (para fabricar archivos válidos y maliciosos) ----------
export function buildZip(entries) {
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name, 'utf8');
    const raw = Buffer.isBuffer(e.data) ? e.data : Buffer.from(e.data ?? '');
    const method = e.method === 'deflate' ? 8 : 0;
    const body = method === 8 ? zlib.deflateRawSync(raw, { level: 9 }) : raw;
    const crc = zlib.crc32(raw) >>> 0;
    const flags = e.flags ?? 0;
    const declared = e.declaredSize ?? raw.length;
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(flags, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0x21, 12); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(declared, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    locals.push(lh, name, body);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(0x031e, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(flags, 8);
    ch.writeUInt16LE(method, 10); ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0x21, 14); ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(declared, 24); ch.writeUInt16LE(name.length, 28);
    ch.writeUInt32LE(((e.mode ?? 0o100644) << 16) >>> 0, 38); ch.writeUInt32LE(offset, 42);
    centrals.push(ch, name);
    offset += lh.length + name.length + body.length;
  }
  const cd = Buffer.concat(centrals);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, end]);
}

// ---------- Cliente WebSocket de prueba ----------
export function connectWs(base, ticket, { origin, headers } = {}) {
  const url = base.replace('http', 'ws') + `/ws?t=${encodeURIComponent(ticket)}`;
  const ws = new WebSocket(url, { origin, headers });
  const c = { ws, msgs: [], closed: null };
  ws.on('message', (d) => { try { c.msgs.push(JSON.parse(d.toString())); } catch { c.msgs.push({ t: '?raw' }); } });
  c.closePromise = new Promise((res) => ws.on('close', (code, reason) => { c.closed = { code, reason: reason.toString() }; res(c.closed); }));
  c.opened = new Promise((res, rej) => { ws.on('open', res); ws.on('error', rej); });
  c.send = (obj) => ws.send(typeof obj === 'string' ? obj : JSON.stringify({ v: 1, ...obj }));
  c.waitFor = (pred, timeout = 3000) => until(() => c.msgs.find(pred), { timeout }).catch(() => { throw new Error(`mensaje esperado no llegó. Recibidos: ${JSON.stringify(c.msgs).slice(0, 400)}`); });
  c.of = (t) => c.msgs.filter((m) => m.t === t);
  c.waitClose = (timeout = 3000) => Promise.race([c.closePromise, sleep(timeout).then(() => { throw new Error('el socket no se cerró'); })]);
  return c;
}

/** Crea sala + invitado dentro, y conecta ambos por WebSocket. */
export async function roomWithPlayers(ctx, names = ['Host', 'Guest'], { max = 4 } = {}) {
  const host = await ctx.user(names[0]);
  const game = await publishedGame(ctx, host.token);
  const created = await ctx.api('POST', '/api/rooms', { token: host.token, body: { gameId: game.id, max } });
  const room = created.json.room;
  const players = [{ ...host, host: true }];
  for (const n of names.slice(1)) {
    const u = await ctx.user(n);
    const j = await ctx.api('POST', '/api/rooms/join', { token: u.token, body: { code: room.invite.code } });
    if (j.status !== 200) throw new Error(`join falló: ${j.text}`);
    players.push(u);
  }
  return { host, game, room, players, code: room.invite.code };
}

export async function ticketFor(ctx, p, roomId) {
  const r = await ctx.api('POST', `/api/rooms/${roomId}/ticket`, { token: p.token });
  if (r.status !== 200) throw new Error(`ticket falló: ${r.text}`);
  return r.json.ticket;
}

export async function wsFor(ctx, p, roomId, opts) {
  const c = connectWs(ctx.base, await ticketFor(ctx, p, roomId), opts);
  await c.opened;
  await c.waitFor((m) => m.t === 'hello');
  return c;
}
